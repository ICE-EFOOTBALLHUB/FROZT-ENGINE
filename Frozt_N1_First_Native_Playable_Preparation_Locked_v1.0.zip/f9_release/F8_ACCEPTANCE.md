# F8 Acceptance — Adaptive Sample

The bundled `fixtures_f8_sample.fzt` is the reference package for the F8 batch.

The sample deliberately keeps simulation state independent from presentation. The engine selects `compact` for a 480x900 touch environment and `expanded` for a 1280x720 mouse/keyboard environment while preserving the same game state.

Native acceptance additionally opens the `.fzt` from memory and persists a package/version-scoped save through the host.
