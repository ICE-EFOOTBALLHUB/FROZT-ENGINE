# FROZT F6 Native Backend — Batch Checkpoint

## Implemented

- Shared native Host API C boundary.
- Lifecycle: start/stop/suspend/resume/tick/resize/input.
- Bundle-loading boundary.
- QuickJS integration point (optional build feature).
- SDL integration point (optional build feature).
- Render-model consumer boundary.
- Android shell integration point.
- Windows/Linux/macOS/iOS shared-shell structure.
- TypeScript native-session adapter.
- Dependency-free native host smoke executable.
- Native CMake build.
- F6 Host API lifecycle conformance test.

## Verification in this environment

- Native CMake build: PASS.
- Native host lifecycle smoke: PASS.
- TypeScript build: PASS.
- Full engine/conformance suite: 55/55 tests PASS.
- F1 frozen fixtures: 28/28 PASS.
- F2 parser fixtures: 10/10 PASS.
- F3 semantic fixtures: 10/10 PASS.
- Runtime-policy fixtures: 8/8 PASS.
- UTF-8 boundary: 1/1 PASS.

## Hardware/toolchain gate still required

This environment does not contain QuickJS, SDL, Android NDK, Xcode, or a
Windows SDK, and the attempted esbuild installation timed out. Therefore this
checkpoint does **not** claim real-device Android/iOS or native desktop graphics
verification. Those are integration gates for the first machine that has the
corresponding toolchains.

The architecture is intentionally dependency-injected so those integrations do
not change the FROZT engine or Host API.
