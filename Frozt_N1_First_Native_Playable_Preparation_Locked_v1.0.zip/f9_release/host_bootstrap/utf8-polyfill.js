(function installFroztUtf8(global) {
  function encoder() {
    return new TextEncoderPolyfill();
  }
  function decoder(label, options) {
    if (label && String(label).toLowerCase() !== "utf-8" && String(label).toLowerCase() !== "utf8") {
      throw new RangeError("unsupported encoding: " + label);
    }
    return new TextDecoderPolyfill(options);
  }
  function TextEncoderPolyfill() { this.encoding = "utf-8"; }
  TextEncoderPolyfill.prototype.encode = function (input) {
    var s = String(input), out = [], i, c, cp;
    for (i = 0; i < s.length; i++) {
      c = s.charCodeAt(i);
      if (c >= 0xD800 && c <= 0xDBFF) {
        if (i + 1 < s.length) {
          var d = s.charCodeAt(i + 1);
          if (d >= 0xDC00 && d <= 0xDFFF) { cp = 0x10000 + ((c - 0xD800) << 10) + (d - 0xDC00); i++; }
          else cp = 0xFFFD;
        } else cp = 0xFFFD;
      } else if (c >= 0xDC00 && c <= 0xDFFF) cp = 0xFFFD;
      else cp = c;
      if (cp <= 0x7F) out.push(cp);
      else if (cp <= 0x7FF) out.push(0xC0 | (cp >> 6), 0x80 | (cp & 63));
      else if (cp <= 0xFFFF) out.push(0xE0 | (cp >> 12), 0x80 | ((cp >> 6) & 63), 0x80 | (cp & 63));
      else out.push(0xF0 | (cp >> 18), 0x80 | ((cp >> 12) & 63), 0x80 | ((cp >> 6) & 63), 0x80 | (cp & 63));
    }
    return new Uint8Array(out);
  };
  function TextDecoderPolyfill(label, options) { this.fatal = !!(options && options.fatal); this.encoding = "utf-8"; }
  TextDecoderPolyfill.prototype.decode = function (bytes) {
    var a = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes), out = "", i = 0;
    function bad() { if (this.fatal) throw new TypeError("invalid UTF-8"); return "\uFFFD"; }
    while (i < a.length) {
      var b0 = a[i++], cp, need;
      if (b0 <= 0x7F) { out += String.fromCharCode(b0); continue; }
      if (b0 >= 0xC2 && b0 <= 0xDF) { need = 1; cp = b0 & 31; }
      else if (b0 >= 0xE0 && b0 <= 0xEF) { need = 2; cp = b0 & 15; }
      else if (b0 >= 0xF0 && b0 <= 0xF4) { need = 3; cp = b0 & 7; }
      else { out += bad.call(this); continue; }
      if (i + need > a.length) { out += bad.call(this); break; }
      var first = a[i];
      if ((b0 === 0xE0 && first < 0xA0) || (b0 === 0xED && first >= 0xA0) || (b0 === 0xF0 && first < 0x90) || (b0 === 0xF4 && first > 0x8F)) { out += bad.call(this); i++; continue; }
      var valid = true;
      for (var j = 0; j < need; j++) if ((a[i + j] & 0xC0) !== 0x80) valid = false;
      if (!valid) { out += bad.call(this); i++; continue; }
      for (j = 0; j < need; j++) cp = (cp << 6) | (a[i++] & 63);
      if (cp <= 0xFFFF) out += String.fromCharCode(cp);
      else { cp -= 0x10000; out += String.fromCharCode(0xD800 | (cp >> 10), 0xDC00 | (cp & 0x3FF)); }
    }
    return out;
  };
  if (typeof global.TextEncoder === "undefined") global.TextEncoder = TextEncoderPolyfill;
  if (typeof global.TextDecoder === "undefined") global.TextDecoder = TextDecoderPolyfill;
})(typeof globalThis !== "undefined" ? globalThis : this);
