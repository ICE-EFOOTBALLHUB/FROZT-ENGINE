# FROZT F4 Runtime Core — Conformance Checkpoint

Status: COMPLETE for the implemented F4 runtime scope, with only explicitly deferred grammar/spec items left open.

## Implemented and tested

- Platform-neutral headless runtime.
- Object definitions and runtime instances.
- Per-instance value state.
- `set` and `mod` mutation execution.
- Arithmetic, comparison, boolean, grouping, unary-not expression evaluation.
- Action registration and dispatch.
- `do{ id"..." }` action dispatch and parser-compatible `do` response handling.
- Event condition evaluation and per-instance satisfying-episode singlefire behavior.
- Event reactivation after a condition becomes false.
- `repeat` and `until` execution at the validated AST/runtime layer.
- One-shot and repeating timers.
- Fixed timestep accumulator with configurable maximum steps per frame.
- Host-seeded deterministic PRNG.
- Runtime resource limits and diagnostics.
- Removal cleanup callbacks for bound audio/processes.
- Main-module failure vs fetched-module failure policy.
- Fetched module registration/execution.
- Game-controlled `canbreak` flag.
- Runtime trace and deterministic snapshots.

## Verification

- F4 runtime tests: 13/13 PASS.
- Combined parser/semantic/runtime tests: 41/41 PASS.
- Frozen F1.3 lexer fixtures: 28/28 PASS.
- Frozen F2.6 parser fixtures: 10/10 PASS.
- F3 semantic fixtures: 10/10 PASS.
- F3 runtime/host policy fixtures: 8/8 PASS.
- TypeScript build: PASS.

## Deliberately not silently locked

The F2 parser remains unchanged/frozen. In particular, the current parser's generic command-argument behavior does not yet provide a tested source-level grammar for new `repeat`/`until` command argument forms. Those runtime constructs are therefore tested against validated AST nodes rather than by changing F2 syntax during F4.

Exact dimensional algebra beyond the F3 foundation, full trigger-context rules, collective event edge semantics, package-private namespaces, and future engine/platform behavior remain outside this checkpoint.

## F4 exit rule

Only behaviors covered by the automated F4 tests are considered locked by this checkpoint. Untested behavior remains open.
