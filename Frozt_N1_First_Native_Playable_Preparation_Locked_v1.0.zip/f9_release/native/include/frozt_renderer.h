#ifndef FROZT_RENDERER_H
#define FROZT_RENDERER_H
#ifdef __cplusplus
extern "C" {
#endif

typedef struct FroztRenderTarget FroztRenderTarget;
typedef struct FroztRenderStats { unsigned sprites; unsigned face_elements; } FroztRenderStats;

/* Render-model consumer boundary. SDL/GLES/Vulkan/Skia implementations plug in
   here; the engine remains unaware of the graphics API. */
int frozt_renderer_begin(FroztRenderTarget* target, int width, int height);
int frozt_renderer_draw_model(FroztRenderTarget* target, const char* json, FroztRenderStats* stats);
void frozt_renderer_end(FroztRenderTarget* target);

#ifdef __cplusplus
}
#endif
#endif
