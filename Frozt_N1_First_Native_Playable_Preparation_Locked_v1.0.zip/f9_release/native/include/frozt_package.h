#ifndef FROZT_PACKAGE_H
#define FROZT_PACKAGE_H
#include <stddef.h>
#ifdef __cplusplus
extern "C" {
#endif

typedef struct FroztPackage FroztPackage;
typedef struct FroztPackageInfo {
  char game_name[256];
  char game_version[64];
  char frozt_version[64];
  char package_id[129];
} FroztPackageInfo;

/* F7 package profile: ZIP is read in memory; release packaging uses Store (method 0).
   Deflate (method 8) remains a host decoder extension and never extracts to disk. */
FroztPackage* frozt_package_open_memory(const unsigned char* bytes, size_t len, char* error, size_t error_len);
void frozt_package_close(FroztPackage* package);
int frozt_package_info(const FroztPackage* package, FroztPackageInfo* out);
const unsigned char* frozt_package_read(const FroztPackage* package, const char* path, size_t* out_len);
int frozt_package_has(const FroztPackage* package, const char* path);

#ifdef __cplusplus
}
#endif
#endif
