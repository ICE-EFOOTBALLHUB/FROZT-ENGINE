#ifndef FROZT_HOST_H
#define FROZT_HOST_H
#include <stdint.h>
#include <stddef.h>
#include "frozt_package.h"
#ifdef __cplusplus
extern "C" {
#endif

typedef struct FroztHost FroztHost;
typedef void (*FroztRenderFn)(FroztHost*, const char* json, size_t len, void* user);
typedef void (*FroztDiagFn)(FroztHost*, const char* code, const char* message, void* user);

typedef struct FroztHostConfig {
  const char* package_root;
  const char* save_root;
  uint64_t seed;
  FroztRenderFn render;
  FroztDiagFn diagnostic;
  void* user;
} FroztHostConfig;

FroztHost* frozt_host_create(const FroztHostConfig* config);
void frozt_host_destroy(FroztHost* host);
int frozt_host_start(FroztHost* host, const char* package_id);
void frozt_host_stop(FroztHost* host);
void frozt_host_suspend(FroztHost* host);
void frozt_host_resume(FroztHost* host);
void frozt_host_tick(FroztHost* host, double dt_ms);
void frozt_host_resize(FroztHost* host, int width, int height, double dpi);
void frozt_host_input_json(FroztHost* host, const char* json);
int frozt_host_load_bundle(FroztHost* host, const char* bundle_path);
int frozt_host_load_bundle_memory(FroztHost* host, const unsigned char* bytes, size_t len);
int frozt_host_save_put_json(FroztHost* host, const char* key, const char* json);
const char* frozt_host_save_get_json(FroztHost* host, const char* key);
int frozt_host_save_delete(FroztHost* host, const char* key);
int frozt_host_package_info(FroztHost* host, FroztPackageInfo* out);

#ifdef __cplusplus
}
#endif
#endif
