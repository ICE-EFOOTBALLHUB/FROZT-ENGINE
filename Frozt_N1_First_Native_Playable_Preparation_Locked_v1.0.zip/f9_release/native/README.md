# FROZT Native Backend (F6)

F6 establishes one native host architecture for Android, Windows, Linux, macOS,
and iOS. Android and Windows remain the first release targets, but the host API
and renderer are deliberately platform-neutral.

## Layers

`FROZT TypeScript -> Host API -> QuickJS adapter -> native host -> SDL adapter -> renderer -> platform shell`

- `host.c`: lifecycle/state boundary and package-bundle entry point.
- `quickjs_adapter.c`: optional QuickJS embedding point.
- `sdl_adapter.c`: optional SDL2/SDL3 event/audio/window integration point.
- `renderer.c`: render-model consumer boundary; GPU implementation is injected by
  the SDL/GLES/Vulkan/Skia platform build.
- `frozt_host_smoke`: dependency-free host lifecycle smoke test.

The native core builds in this repository without QuickJS/SDL so the API and
lifecycle can be continuously tested. A production platform build enables the
corresponding adapters and links the platform libraries.
