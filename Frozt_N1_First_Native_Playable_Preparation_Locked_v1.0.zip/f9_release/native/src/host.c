#include "frozt_host.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

struct FroztHost {
  FroztHostConfig cfg;
  int running, suspended;
  int width, height; double dpi;
  char* bundle_path;
  unsigned char* bundle_bytes; size_t bundle_len;
  FroztPackage* package;
  char package_id[256]; char game_version[64];
  char save_path[1024]; char save_game_version[64];
  char save_read_buffer[8192];
};
static void diag(FroztHost*h,const char*c,const char*m){if(h&&h->cfg.diagnostic)h->cfg.diagnostic(h,c,m,h->cfg.user);}
static int safe_component(const char*s){if(!s||!*s||strchr(s,'/')||strchr(s,'\\')||strstr(s,".."))return 0;for(const char*p=s;*p;p++)if(!(isalnum((unsigned char)*p)||*p=='.'||*p=='_'||*p=='-'))return 0;return 1;}
static int load_file(const char*path,unsigned char**out,size_t*len){FILE*f=fopen(path,"rb");if(!f)return 0;if(fseek(f,0,SEEK_END)){fclose(f);return 0;}long n=ftell(f);if(n<0){fclose(f);return 0;}rewind(f);unsigned char*b=(unsigned char*)malloc((size_t)n);if(!b){fclose(f);return 0;}if(n&&fread(b,1,(size_t)n,f)!=(size_t)n){free(b);fclose(f);return 0;}fclose(f);*out=b;*len=(size_t)n;return 1;}
static void hex(unsigned char out[2],unsigned char v){static const char*d="0123456789abcdef";out[0]=d[v>>4];out[1]=d[v&15];}
static int unhex(char c){if(c>='0'&&c<='9')return c-'0';if(c>='a'&&c<='f')return c-'a'+10;if(c>='A'&&c<='F')return c-'A'+10;return -1;}
static int save_key_ok(const char*k){if(!safe_component(k)||strlen(k)>128)return 0;return 1;}
static int ensure_save_path(FroztHost*h){if(!h->cfg.save_root||!safe_component(h->package_id))return 0;snprintf(h->save_path,sizeof h->save_path,"%s/%s.save",h->cfg.save_root,h->package_id);return 1;}
static int write_save(FroztHost*h,const char*text){char tmp[1060];snprintf(tmp,sizeof tmp,"%s.tmp",h->save_path);FILE*f=fopen(tmp,"wb");if(!f)return 0;size_t n=strlen(text);int ok=fwrite(text,1,n,f)==n && fflush(f)==0;fclose(f);if(!ok){remove(tmp);return 0;}remove(h->save_path);return rename(tmp,h->save_path)==0;}
static int save_matches(FroztHost*h,char**text){FILE*f=fopen(h->save_path,"rb");if(!f)return 0;if(fseek(f,0,SEEK_END)){fclose(f);return 0;}long n=ftell(f);if(n<0||n>1024*1024){fclose(f);return 0;}rewind(f);char*b=malloc((size_t)n+1);if(!b){fclose(f);return 0;}if(n&&fread(b,1,(size_t)n,f)!=(size_t)n){free(b);fclose(f);return 0;}b[n]=0;fclose(f);char header[512];snprintf(header,sizeof header,"FROZT-SAVE-1\nPACKAGE_ID=%s\nGAME_VERSION=%s\n",h->package_id,h->game_version);if(strncmp(b,header,strlen(header))!=0){free(b);return 0;}*text=b;return 1;}
FroztHost*frozt_host_create(const FroztHostConfig*c){if(!c)return NULL;FroztHost*h=calloc(1,sizeof*h);if(!h)return NULL;h->cfg=*c;h->dpi=1.0;return h;}
void frozt_host_destroy(FroztHost*h){if(!h)return;frozt_package_close(h->package);free(h->bundle_bytes);free(h->bundle_path);free(h);}
static int load_bundle_bytes(FroztHost*h,unsigned char*b,size_t n,const char*path){
  if(!h||!b||!n)return 0;
  char e[128]={0};
  FroztPackage*p=frozt_package_open_memory(b,n,e,sizeof e);
  if(!p){diag(h,"F7-BUNDLE-002",e[0]?e:"invalid game info");free(b);return 0;}
  FroztPackageInfo info;
  if(!frozt_package_info(p,&info)){frozt_package_close(p);free(b);return 0;}
  free(h->bundle_bytes); frozt_package_close(h->package); free(h->bundle_path);
  h->bundle_bytes=b; h->bundle_len=n; h->package=p;
  h->bundle_path=NULL;
  if(path){h->bundle_path=malloc(strlen(path)+1); if(h->bundle_path) strcpy(h->bundle_path,path);}
  snprintf(h->game_version,sizeof(h->game_version),"%s",info.game_version);
  return 1;
}
int frozt_host_load_bundle(FroztHost*h,const char*path){
  if(!h||!path||!*path)return 0;
  unsigned char*b=NULL;size_t n=0;
  if(!load_file(path,&b,&n)){diag(h,"F7-BUNDLE-001","game package could not be opened");return 0;}
  return load_bundle_bytes(h,b,n,path);
}
int frozt_host_load_bundle_memory(FroztHost*h,const unsigned char*bytes,size_t len){
  if(!h||!bytes||!len)return 0;
  unsigned char*b=malloc(len); if(!b)return 0;
  memcpy(b,bytes,len);
  return load_bundle_bytes(h,b,len,NULL);
}
int frozt_host_start(FroztHost*h,const char*package_id){if(!h||!package_id||!*package_id||!safe_component(package_id))return 0;if(h->package){FroztPackageInfo info;if(!frozt_package_info(h->package,&info)||strcmp(info.package_id,package_id)!=0){diag(h,"F7-PACKAGE-001","package id mismatch");return 0;}}snprintf(h->package_id,sizeof h->package_id,"%s",package_id);ensure_save_path(h);h->running=1;h->suspended=0;return 1;}
void frozt_host_stop(FroztHost*h){if(h)h->running=0;} void frozt_host_suspend(FroztHost*h){if(h&&h->running)h->suspended=1;} void frozt_host_resume(FroztHost*h){if(h&&h->running)h->suspended=0;} void frozt_host_tick(FroztHost*h,double dt){(void)h;(void)dt;} void frozt_host_resize(FroztHost*h,int w,int ht,double dpi){if(h){h->width=w;h->height=ht;h->dpi=dpi;}}
void frozt_host_input_json(FroztHost*h,const char*j){(void)h;(void)j;}
int frozt_host_package_info(FroztHost*h,FroztPackageInfo*out){return h&&h->package&&frozt_package_info(h->package,out);}
int frozt_host_save_put_json(FroztHost*h,const char*key,const char*json){if(!h||!json||!save_key_ok(key)||!ensure_save_path(h))return 0;char*old=NULL;save_matches(h,&old);size_t cap=(old?strlen(old):0)+strlen(key)*2+strlen(json)*2+1024;char*out=calloc(1,cap);if(!out){free(old);return 0;}char header[512];snprintf(header,sizeof header,"FROZT-SAVE-1\nPACKAGE_ID=%s\nGAME_VERSION=%s\n",h->package_id,h->game_version);strcat(out,header);int replaced=0; if(old){char*line=strtok(old,"\n");while(line){if(strncmp(line,"FROZT-SAVE-1",12)&&strncmp(line,"PACKAGE_ID=",11)&&strncmp(line,"GAME_VERSION=",13)){char*tab=strchr(line,'\t');if(tab){*tab=0;if(!strcmp(line,key)){strcat(out,key);strcat(out,"\t");for(const unsigned char*p=(const unsigned char*)json;*p;p++){unsigned char q[2];hex(q,*p);strncat(out,(char*)q,2);}strcat(out,"\n");replaced=1;}else{strcat(out,line);strcat(out,"\t");strcat(out,tab+1);strcat(out,"\n");}}}line=strtok(NULL,"\n");}}
if(!replaced){strcat(out,key);strcat(out,"\t");for(const unsigned char*p=(const unsigned char*)json;*p;p++){unsigned char q[2];hex(q,*p);strncat(out,(char*)q,2);}strcat(out,"\n");}int ok=write_save(h,out);free(old);free(out);return ok;}
const char*frozt_host_save_get_json(FroztHost*h,const char*key){if(!h||!save_key_ok(key)||!ensure_save_path(h))return NULL;char*old=NULL;if(!save_matches(h,&old))return NULL;h->save_read_buffer[0]=0;char*line=strtok(old,"\n");while(line){if(strncmp(line,"FROZT-SAVE-1",12)&&strncmp(line,"PACKAGE_ID=",11)&&strncmp(line,"GAME_VERSION=",13)){char*tab=strchr(line,'\t');if(tab){*tab=0;if(!strcmp(line,key)){const char*hexv=tab+1;size_t n=strlen(hexv);if(n%2||n/2>=sizeof h->save_read_buffer){free(old);return NULL;}for(size_t i=0;i<n;i+=2){int a=unhex(hexv[i]),b=unhex(hexv[i+1]);if(a<0||b<0){free(old);return NULL;}h->save_read_buffer[i/2]=(char)((a<<4)|b);}h->save_read_buffer[n/2]=0;free(old);return h->save_read_buffer;}}}line=strtok(NULL,"\n");}free(old);return NULL;}
int frozt_host_save_delete(FroztHost*h,const char*key){if(!h||!save_key_ok(key)||!ensure_save_path(h))return 0;char*old=NULL;if(!save_matches(h,&old))return 1;char header[512],*out=calloc(1,strlen(old)+512);if(!out){free(old);return 0;}snprintf(header,sizeof header,"FROZT-SAVE-1\nPACKAGE_ID=%s\nGAME_VERSION=%s\n",h->package_id,h->game_version);strcat(out,header);char*line=strtok(old,"\n");while(line){if(strncmp(line,"FROZT-SAVE-1",12)&&strncmp(line,"PACKAGE_ID=",11)&&strncmp(line,"GAME_VERSION=",13)){char*tab=strchr(line,'\t');if(tab){*tab=0;if(strcmp(line,key)){strcat(out,line);strcat(out,"\t");strcat(out,tab+1);strcat(out,"\n");}}}line=strtok(NULL,"\n");}int ok=write_save(h,out);free(old);free(out);return ok;}
