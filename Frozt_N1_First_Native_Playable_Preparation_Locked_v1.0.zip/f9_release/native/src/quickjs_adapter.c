#include "frozt_host.h"
/* Optional QuickJS adapter. Build with -DFROZT_WITH_QUICKJS and provide the
   QuickJS headers/library in the native toolchain. The core host never assumes
   QuickJS is present, keeping Linux/macOS/Windows/Android/iOS shells reusable. */
#ifdef FROZT_WITH_QUICKJS
#include "quickjs.h"
int frozt_quickjs_available(void) { return 1; }
#else
int frozt_quickjs_available(void) { return 0; }
#endif
