#include "frozt_host.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static void render(FroztHost* h,const char*json,size_t n,void*u){(void)h;(void)json;(void)n;(void)u;}
static void diag(FroztHost*h,const char*c,const char*m,void*u){(void)h;(void)u;fprintf(stderr,"%s: %s\n",c,m);}
int main(int argc,char**argv){FroztHostConfig c={0};c.render=render;c.diagnostic=diag;c.seed=1;c.save_root=argc>2?argv[2]:NULL;FroztHost*h=frozt_host_create(&c);if(!h)return 2;if(argc>1){if(!frozt_host_load_bundle(h,argv[1])){frozt_host_destroy(h);return 3;}FroztPackageInfo info;if(!frozt_host_package_info(h,&info)){frozt_host_destroy(h);return 4;}if(!frozt_host_start(h,info.package_id)){frozt_host_destroy(h);return 5;}if(c.save_root){if(!frozt_host_save_put_json(h,"smoke","42")){frozt_host_destroy(h);return 6;}const char*v=frozt_host_save_get_json(h,"smoke");if(!v||strcmp(v,"42")){frozt_host_destroy(h);return 7;}}}else if(!frozt_host_start(h,"f6.smoke")){frozt_host_destroy(h);return 8;}frozt_host_resize(h,1280,720,1.0);frozt_host_tick(h,16.6666667);frozt_host_suspend(h);frozt_host_resume(h);frozt_host_stop(h);frozt_host_destroy(h);puts("F7 native host smoke: PASS");return 0;}
