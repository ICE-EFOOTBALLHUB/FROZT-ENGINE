#include "frozt_renderer.h"
#include <string.h>
struct FroztRenderTarget { int width, height; };
int frozt_renderer_begin(FroztRenderTarget* t,int w,int h){ if(!t||w<=0||h<=0)return 0; t->width=w;t->height=h;return 1; }
int frozt_renderer_draw_model(FroztRenderTarget* t,const char* json,FroztRenderStats* s){
  if(!t||!json||!s)return 0;
  /* Transport validation only. Real GPU drawing is supplied by the SDL platform adapter. */
  if(strstr(json,"\"version\":1") == NULL || strstr(json,"\"face\"") == NULL)return 0;
  s->sprites=0; s->face_elements=0; return 1;
}
void frozt_renderer_end(FroztRenderTarget* t){(void)t;}
