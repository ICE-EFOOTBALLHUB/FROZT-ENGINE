/* Optional SDL adapter. SDL2 and SDL3 are selected by the platform build.
   The adapter owns translation of SDL events into the Host API; game code never
   sees SDL types. */
#ifdef FROZT_WITH_SDL
#include <SDL.h>
#endif
int frozt_sdl_available(void) {
#ifdef FROZT_WITH_SDL
  return 1;
#else
  return 0;
#endif
}
