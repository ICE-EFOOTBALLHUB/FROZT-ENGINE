# FROZT F7 Package Specification v1

## Container

- Extension: `.fzt`.
- Container: ZIP, read entirely in memory by the native host; no extraction is permitted.
- Required entries:
  - `metadata/meta.txt`
  - `main.frozt`
- Optional entries may include `assets/`, `scripts/`, and future engine-owned directories.
- ZIP directory entries are allowed.
- Package-relative paths must not be absolute, contain `..`, use backslashes, or escape the package root.
- The F7 release packager emits ZIP **Store** entries so the dependency-free native host can load packages everywhere. Deflate is reserved for hosts that explicitly supply a decoder; the TypeScript loader supports this through dependency injection.

## Metadata

`metadata/meta.txt` is UTF-8 `key=value` text. Required keys:

- `game_name`
- `game_version` — strict `MAJOR.MINOR.PATCH`
- `frozt_version` — strict `MAJOR.MINOR.PATCH`, must be <= the runtime version
- `package_id` — `[A-Za-z0-9][A-Za-z0-9._-]{0,127}`

Missing or invalid required metadata produces exactly `invalid game info` at the player-facing boundary.

## Saves

Saves are not part of the read-only `.fzt` package. They are keyed game-level values scoped by `package_id` and `game_version`.

The engine never receives a filesystem path. The host owns persistence and may store it in the platform's normal app-private data location. Writes use a temporary file followed by replacement. A save from another package ID or game version is ignored rather than migrated implicitly.

## Presentation

No platform-specific presentation data is required in the F7 package. Presentation is driven at runtime by an environment contract (viewport, DPI, safe area, orientation, pointer presence, and input capabilities). This deliberately keeps simulation state independent from presentation structure.
