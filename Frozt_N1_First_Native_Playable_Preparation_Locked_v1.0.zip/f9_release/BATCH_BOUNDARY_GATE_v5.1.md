# FROZT Native Boundary Batch — v5.1

## Status

F4 remains complete. The native boundary work is **partially verified**.

### Verified
- TypeScript build passes.
- Existing F1/F2/F3/F4 conformance remains green.
- Host API boundary test: PASS.
- Render model JSON round-trip test: PASS.
- Render model ordering test: PASS.
- UTF-8 fatal-decoder polyfill test: PASS.
- Static engine portability audit: no browser/Node/time/randomness dependency found in engine source outside the explicitly excluded lexer CLI.

### Not verified
- `esbuild` execution: unavailable in this environment.
- QuickJS execution: unavailable in this environment.
- Native C/Rust smoke host: not executable without QuickJS/native dependencies.
- Android/desktop end-to-end execution: not started.

## Lock rule

OQ-40 Host API and OQ-41 Render Model remain PROPOSED / NOT LOCKED until an implementation-level conformance suite is executed against the real native boundary.

The passing TypeScript contract tests verify shape and expected behavior only; they do not prove the native ABI or QuickJS bridge.

## Current gate

41/41 existing engine tests PASS.
28/28 F1 fixtures PASS.
10/10 F2.6 fixtures PASS.
10/10 F3 semantic fixtures PASS.
8/8 F3 runtime-policy fixtures PASS.
3/3 native-boundary TypeScript contract tests PASS.
1/1 UTF-8 polyfill test PASS.

Next external-environment gate: install/choose QuickJS + esbuild, produce the real bundle, then run the F4 reference game inside QuickJS through the Host API.
