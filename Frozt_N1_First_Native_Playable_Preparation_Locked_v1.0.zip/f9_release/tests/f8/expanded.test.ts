import test from 'node:test';
import assert from 'node:assert/strict';
import { LayoutEngine, InteractionRegistry, TriggerSystem, CollisionSystem, AnimationSystem, CameraSystem, SceneManager, VersionedSave, F8GameSystems, createEnvironment, faceText, SpatialRegistry } from '../../src';

test('F8 adaptive layout respects safe area, constraints and structural resize',()=>{
 const e=new LayoutEngine(); const a=e.resolve({id:'root',spec:{},children:[{id:'inventory',spec:{left:10,right:10,bottom:10,height:180},children:[]}]},{width:480,height:900},{left:0,top:24,right:0,bottom:12});
 assert.deepEqual(a.children[0].rect,{x:10,y:698,width:460,height:180});
 const b=e.resolve({id:'root',spec:{},children:[{id:'inventory',spec:{left:10,right:10,top:10,bottom:10},children:[]}]},{width:1200,height:800},{left:0,top:0,right:0,bottom:0});
 assert.equal(b.children[0].rect.width,1180); assert.equal(b.children[0].rect.height,780);
});

test('F8 interaction chooses highest z enabled target deterministically',()=>{const r=new InteractionRegistry();r.set({id:'low',rect:{x:0,y:0,width:100,height:100},z:1,enabled:true,action:'a'});r.set({id:'high',rect:{x:0,y:0,width:100,height:100},z:2,enabled:true,action:'b'});assert.deepEqual(r.hit(50,50),{id:'high',z:2});});

test('F8 collision and triggers operate on spatial state',()=>{const s=new SpatialRegistry();const a=s.add('a',{x:0,y:0});const b=s.add('b',{x:1,y:0});const c=new CollisionSystem(s);c.add({id:a,shape:'circle',radius:1,solid:true});c.add({id:b,shape:'circle',radius:1,solid:true});assert.deepEqual(c.pairs(),[[a,b]]);let entered=0;const t=new TriggerSystem(s);t.check([{id:'zone',rect:{x:-1,y:-1,width:3,height:3},onEnter:()=>entered++}]);assert.equal(entered,2);});

test('F8 animation, camera and scene transition are deterministic',()=>{const s=new SpatialRegistry();const id=s.add('player',{x:0,y:0});const a=new AnimationSystem();a.define({id:'walk',frames:['a','b'],frameDuration:0.1,loop:true});a.play(id,'walk');a.update(0.11);assert.equal(a.frameImage(id),'b');const cam=new CameraSystem(s);cam.set({target:id,followLerp:1});s.setPosition(id,{x:10,y:0});cam.update(1/60);assert.ok(cam.state.x>0);const sm=new SceneManager('one');sm.transitionTo('two',0.1);sm.update(0.1);assert.equal(sm.current,'two');});

test('F8 saves migrate schemas without exposing paths',()=>{const s=new VersionedSave('demo.game','1.0.0',2);assert.equal(s.import({schema:1,packageId:'demo.game',gameVersion:'0.9.0',values:{score:4}},[{from:1,to:2,migrate:v=>({...v,versioned:true})}]),true);assert.equal(s.get('versioned'),true);assert.equal(s.import({schema:3,packageId:'demo.game',gameVersion:'3.0.0',values:{}},[]),false);});

test('F8 sample-game acceptance composes compact and expanded presentation without changing state',()=>{const envC=createEnvironment({width:480,height:900,dpi:2,safeArea:{left:0,top:24,right:0,bottom:12},pointer:true,capabilities:new Set(['touch'])});const envE=createEnvironment({width:1280,height:720,dpi:1,safeArea:{left:0,top:0,right:0,bottom:0},pointer:true,capabilities:new Set(['mouse','keyboard'])});const gameState={inventoryOpen:false,score:12};const g=new F8GameSystems([{id:'expanded',priority:10,when:e=>e.width>=900},{id:'compact',priority:1,when:e=>e.width<900}]);g.update(1/60,envC);assert.equal(g.presentation.current().variant,'compact');g.update(1/60,envE);assert.equal(g.presentation.current().variant,'expanded');assert.deepEqual(gameState,{inventoryOpen:false,score:12});assert.deepEqual(faceText('score','12',{x:10,y:10,width:100,height:30},24,{r:1,g:1,b:1,a:1}).kind,'text');});
