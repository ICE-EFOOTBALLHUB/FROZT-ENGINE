import test from "node:test";
import assert from "node:assert/strict";
import { createNativeSession } from "../../src/native-entry";
import type { FroztHostApi, InputEvent } from "../../src/host/api";

test("F6 native session forwards the locked Host API lifecycle", () => {
  const calls:string[]=[];
  const host: FroztHostApi = {
    start:(p,s)=>calls.push(`start:${p}:${s}`), stop:()=>calls.push("stop"), suspend:()=>calls.push("suspend"), resume:()=>calls.push("resume"),
    input:(e)=>calls.push(`input:${e.type}`), tick:(d)=>calls.push(`tick:${d}`), resize:(w,h,d)=>calls.push(`resize:${w}:${h}:${d}`), presentationEnvironment:(e)=>calls.push(`environment:${e.orientation}`),
    readPackageFile:()=>undefined, saveGet:()=>undefined, savePut:()=>{}, saveDelete:()=>{}, playAudio:()=>({id:1}), pauseAudio:()=>{}, stopAudio:()=>{}, setVolume:()=>{}, render:()=>{}, diagnostic:()=>{}, sessionComplete:()=>{}
  };
  const s=createNativeSession(host); s.start("demo",42); s.resize(100,50,2); s.input({type:"key",phase:"down",key:"A",repeat:false}); s.tick(16); s.suspend(); s.resume(); s.stop();
  assert.deepEqual(calls,["start:demo:42","resize:100:50:2","input:key","tick:16","suspend","resume","stop"]);
});
