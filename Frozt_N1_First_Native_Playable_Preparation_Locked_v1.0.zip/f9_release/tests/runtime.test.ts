import assert from "node:assert/strict";
import test from "node:test";
import { FroztRuntime, SeededRandom, runHeadless } from "../src/runtime";
import { parse } from "../src/parser";

function pos(){ return {byte:0,line:0,column:0}; }
function span(){ return {start:pos(),end:pos()}; }
function num(n:number): any { return {kind:"LiteralExpr",value:String(n),tokenKind:"NUMBER",span:span()}; }
function ref(name:string): any { return {kind:"ValueRefExpr",name,span:span()}; }
function mut(op:any,name:string,n:number): any { return {kind:"MutationExpr",operator:op,left:ref(name),right:num(n),span:span()}; }
function cmd(name:string,args:any[]=[],body:any[]=[]): any { return {kind:"Command",name,args,body:body.length?{kind:"Block",body:body,span:span()}:undefined,span:span()}; }


test("executes object state, action, event episode, and mutation", () => {
  const source = `
    add{ id"player" set [health]=#1 }
    action{ id"damage" mod [health]-=#1 }
    event{ id"player" [health] > #0 then do id"damage" }
  `;
  const { runtime } = runHeadless(source, { spawns:["player"], ticks:1 });
  const snap1 = runtime.snapshot();
  assert.equal(snap1.instances[0].values.health, 0);
  assert.equal(runtime.trace.filter(x => x.event === "event").length, 1);
  runtime.tick();
  assert.equal(runtime.trace.filter(x => x.event === "event").length, 1);
});

test("event episode can fire again after condition becomes false", () => {
  const source = `add{ id"p" set [x]=#0 } action{ id"inc" mod [x]+=#1 } event{ id"p" [x] = #0 then do id"inc" }`;
  const { runtime } = runHeadless(source, { spawns:["p"], ticks:1 });
  assert.equal(runtime.getValue(1,"x"),1);
  runtime.tick();
  runtime.setValue(1,"x",0);
  runtime.tick();
  assert.equal(runtime.getValue(1,"x"),1);
  assert.equal(runtime.trace.filter(x => x.event === "event").length, 2);
});

test("do block dispatches an action using the frozen parser-compatible form", () => {
  const source = `add{ id"p" set [x]=#0 } action{ id"go" mod [x]+=#4 }`;
  const { runtime } = runHeadless(source, { spawns:["p"] });
  const parsed = parse(`do{ id"go" }`);
  const statement = parsed.ast.body[0] as any;
  assert.equal(runtime.runStatements([statement], 1), true);
  assert.equal(runtime.getValue(1,"x"),4);
});

test("valid fetched modules register and execute in the same headless runtime", () => {
  const runtime = new FroztRuntime();
  assert.equal(runtime.loadFetched(`add{ id"moduleObject" set [x]=#7 }`), true);
  const id = runtime.spawn("moduleObject")!;
  assert.equal(runtime.getValue(id,"x"),7);
});

test("action execution applies a sequence of mutations", () => {
  const source = `add{ id"p" set [x]=#0 } action{ id"go" mod [x]+=#1 mod [x]+=#2 }`;
  const { runtime } = runHeadless(source, { spawns:["p"] });
  assert.equal(runtime.runAction("go",1), true);
  assert.equal(runtime.getValue(1,"x"),3);
});

test("repeat and until execute through the validated AST runtime", () => {
  const runtime = new FroztRuntime({}, { maxRepeatIterations:10 });
  runtime.load(`add{ id"p" set [x]=#0 }`);
  const id = runtime.spawn("p")!;
  const repeat = cmd("repeat", [num(3)], [cmd("mod", [mut("+=","x",1)])]);
  assert.equal(runtime.runStatements([repeat], id), true);
  assert.equal(runtime.getValue(id,"x"),3);
  const untilCond:any = {kind:"BinaryExpr",operator:">=",left:ref("x"),right:num(5),span:span()};
  const until = cmd("until", [untilCond], [cmd("mod", [mut("+=","x",1)])]);
  assert.equal(runtime.runStatements([until], id), true);
  assert.equal(runtime.getValue(id,"x"),5);
});

test("timers count down and repeating timers reschedule", () => {
  const runtime = new FroztRuntime();
  assert.equal(runtime.startTimer("once", 0.1), true);
  assert.equal(runtime.startTimer("repeat", 0.1, true), true);
  runtime.tick(0.05);
  assert.equal(runtime.snapshot().timers.length, 2);
  runtime.tick(0.05);
  assert.equal(runtime.snapshot().timers.length, 1);
  runtime.tick(0.1);
  assert.equal(runtime.snapshot().timers.length, 1);
  assert.equal(runtime.trace.filter(x => x.event === "timer").length, 3);
});

test("fixed timestep accumulator obeys the step cap", () => {
  const runtime = new FroztRuntime({}, { maxStepCountPerFrame: 2 });
  const snap = runtime.stepFrame(1);
  assert.equal(snap.tick, 2);
  assert.equal(runtime.diagnostics.some(d => d.code === "RUN-STEP-CAP"), true);
  const snap2 = runtime.stepFrame(0);
  assert.equal(snap2.tick, 4);
});

test("seeded randomness is deterministic", () => {
  const a = new SeededRandom(12345), b = new SeededRandom(12345), c = new SeededRandom(54321);
  const av = [a.next(),a.next(),a.next(),a.next()];
  const bv = [b.next(),b.next(),b.next(),b.next()];
  const cv = [c.next(),c.next(),c.next(),c.next()];
  assert.deepEqual(av,bv);
  assert.equal(JSON.stringify(av) === JSON.stringify(cv), false);
  assert.equal(av.every(x => x >= 0 && x < 1), true);
});

test("removal performs required host cleanup", () => {
  const audio:number[] = [], processes:number[] = [];
  const runtime = new FroztRuntime({ onAudioStop:id=>audio.push(id), onProcessStop:id=>processes.push(id) });
  assert.equal(runtime.load(`add{ id"p" }`), true);
  const id = runtime.spawn("p")!;
  assert.equal(runtime.remove(id), true);
  assert.deepEqual(audio,[id]);
  assert.deepEqual(processes,[id]);
  assert.equal(runtime.snapshot().instances[0].alive, false);
});

test("resource limits produce diagnostics instead of unbounded growth", () => {
  const runtime = new FroztRuntime({}, { resourceLimits:{instances:1} });
  runtime.load(`add{ id"p" }`);
  assert.equal(typeof runtime.spawn("p"), "number");
  assert.equal(runtime.spawn("p"), undefined);
  assert.equal(runtime.diagnostics.some(d=>d.code === "RUN-RESOURCE-LIMIT"), true);
});

test("fetched module parse failure is recoverable while main failure is fatal", () => {
  const runtime = new FroztRuntime();
  assert.equal(runtime.loadFetched(`add{ id"broken"`), true);
  assert.equal(runtime.diagnostics.some(d=>d.code === "RUN-MODULE-PARSE"), true);
  const main = new FroztRuntime();
  assert.equal(main.load(`add{ id"broken"`), false);
  assert.equal(main.diagnostics.some(d=>d.code === "RUN-MAIN-PARSE"), true);
});

test("canbreak is an engine flag mechanism and can be raised by a game action", () => {
  const source = `add{ id"p" } action{ id"stop" canbreak } event{ id"p" then do id"stop" }`;
  const { runtime } = runHeadless(source, { spawns:["p"], ticks:1 });
  assert.equal(runtime.canbreak, true);
  runtime.clearCanbreak();
  assert.equal(runtime.canbreak, false);
});
