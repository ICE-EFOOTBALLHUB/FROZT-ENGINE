import test from "node:test";
import assert from "node:assert/strict";
import type { FroztHostApi, InputEvent, RenderModel, SaveValue } from "../../src/host";

class RecordingHost implements FroztHostApi {
  calls: string[] = [];
  files = new Map<string, Uint8Array>([["assets/a.bin", new Uint8Array([1,2,3])]]);
  saves = new Map<string, SaveValue>();
  nextAudio = 1;
  renders: RenderModel[] = [];
  completed = false;

  start(packageId: string, seed: number) { this.calls.push(`start:${packageId}:${seed}`); }
  stop() { this.calls.push("stop"); }
  suspend() { this.calls.push("suspend"); }
  resume() { this.calls.push("resume"); }
  input(event: InputEvent) { this.calls.push(`input:${event.type}`); }
  tick(dtMs: number) { this.calls.push(`tick:${dtMs}`); }
  resize(width: number, height: number, dpi: number) { this.calls.push(`resize:${width}:${height}:${dpi}`); }
  presentationEnvironment(environment: any) { this.calls.push(`environment:${environment.orientation}`); }
  readPackageFile(path: string) { this.calls.push(`read:${path}`); return this.files.has(path) ? { bytes: this.files.get(path)! } : undefined; }
  saveGet(key: string) { return this.saves.get(key); }
  savePut(key: string, value: SaveValue) { this.saves.set(key, value); }
  saveDelete(key: string) { this.saves.delete(key); }
  playAudio() { const id = { id: this.nextAudio++ }; this.calls.push(`audio:play:${id.id}`); return id; }
  pauseAudio(id: {id:number}) { this.calls.push(`audio:pause:${id.id}`); }
  stopAudio(id: {id:number}) { this.calls.push(`audio:stop:${id.id}`); }
  setVolume(id: {id:number}, volume: number) { this.calls.push(`audio:volume:${id.id}:${volume}`); }
  render(model: RenderModel) { this.renders.push(model); }
  diagnostic(record: {code:string}) { this.calls.push(`diag:${record.code}`); }
  sessionComplete() { this.completed = true; this.calls.push("complete"); }
}

test("Host API exercises every boundary operation", () => {
  const h = new RecordingHost();
  h.start("test.game", 123);
  h.resize(800, 600, 2);
  h.presentationEnvironment({width:800,height:600,dpi:2,safeArea:{left:0,top:0,right:0,bottom:0},orientation:"landscape",pointer:true,capabilities:new Set(["mouse"]) });
  h.input({type:"pointer", phase:"down", pointerId:7, x:10, y:20});
  h.input({type:"key", phase:"down", key:"Enter", repeat:false});
  h.input({type:"analog", control:"left_x", value:-0.5});
  h.tick(16.6667);
  h.suspend(); h.resume();
  assert.deepEqual([...h.readPackageFile("assets/a.bin")!.bytes], [1,2,3]);
  assert.equal(h.readPackageFile("../escape.bin"), undefined);
  h.savePut("score", 42); assert.equal(h.saveGet("score"), 42); h.saveDelete("score"); assert.equal(h.saveGet("score"), undefined);
  const audio = h.playAudio(); h.setVolume(audio, 0.5); h.pauseAudio(audio); h.stopAudio(audio);
  h.diagnostic({code:"TEST"});
  h.sessionComplete(); h.stop();
  assert.equal(h.completed, true);
  assert.equal(h.calls.includes("tick:16.6667"), true);
});
