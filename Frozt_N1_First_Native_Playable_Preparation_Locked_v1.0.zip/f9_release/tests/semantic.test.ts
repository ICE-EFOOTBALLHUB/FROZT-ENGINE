import assert from "node:assert/strict";
import test from "node:test";
import { parse } from "../src/parser";
import { analyze } from "../src/semantic";

test("collects declared object and action symbols",()=>{
  const p=parse('add{ id"player" } action{ id"tick" }');
  const r=analyze(p.ast,p.diagnostics);
  assert.equal(r.diagnostics.length,0);
  assert.equal(r.model.symbols.objects.has("player"),true);
  assert.equal(r.model.symbols.actions.has("tick"),true);
});

test("reports duplicate declarations",()=>{
  const p=parse('add{ id"player" } add{ id"player" }');
  const r=analyze(p.ast,p.diagnostics);
  assert.equal(r.diagnostics.some(d=>d.code==="SEM-001"),true);
});

test("checks boolean and numeric operators",()=>{
  const p=parse('eval{ #2 and !true } eval{ !true + #2 }');
  const r=analyze(p.ast,p.diagnostics);
  assert.equal(r.diagnostics.filter(d=>d.code==="SEM-007").length,1);
  assert.equal(r.diagnostics.filter(d=>d.code==="SEM-005").length,1);
});

test("allows unknown value refs without pretending their runtime type is known",()=>{
  const p=parse('eval{ [health] + #1 }');
  const r=analyze(p.ast,p.diagnostics);
  assert.equal(r.diagnostics.length,0);
  assert.equal(r.model.valueTypes.get((()=>{let found:any; const walk=(s:any)=>{if(s.kind==="ExpressionStatement"&&s.expression.kind==="BinaryExpr") found=s.expression.left; else if(s.kind==="Command") (s.body?.body??[]).forEach(walk)}; p.ast.body.forEach(walk); return found;})()),"unknown");
});


test("treats names case-insensitively within a namespace",()=>{
  const p=parse('add{ id"Player" } add{ id"player" }');
  const r=analyze(p.ast,p.diagnostics);
  assert.equal(r.diagnostics.some(d=>d.code==="SEM-001"),true);
});

test("keeps separate namespaces for different declaration kinds",()=>{
  const p=parse('add{ id"player" } action{ id"player" }');
  const r=analyze(p.ast,p.diagnostics);
  assert.equal(r.diagnostics.length,0);
  assert.equal(r.model.symbols.objects.has("player"),true);
  assert.equal(r.model.symbols.actions.has("player"),true);
});

test("does not treat dimensioned unit literals as plain numbers",()=>{
  const p=parse('eval{ #5fro + #2fro }');
  const r=analyze(p.ast,p.diagnostics);
  assert.equal(r.diagnostics.length,0);
});

test("does not create one global ownerless value symbol for repeated property names",()=>{
  const p=parse('add{ id"boss" } add{ id"player" } mod [health]=#10 mod [health]=#20');
  const r=analyze(p.ast,p.diagnostics);
  const refs=r.model.symbols.values.get("health") ?? [];
  assert.equal(refs.length,2);
  assert.equal(r.model.valueTypes.size>=2,true);
});

test("rejects mixed dimensions for addition",()=>{
  const p=parse('eval{ #5fro + %20 }');
  const r=analyze(p.ast,p.diagnostics);
  assert.equal(r.diagnostics.some(d=>d.code==="SEM-005"),true);
});

test("allows scalar multiplication of a distance",()=>{
  const p=parse('eval{ #2 * #5fro }');
  const r=analyze(p.ast,p.diagnostics);
  assert.equal(r.diagnostics.length,0);
});

test("allows same-dimension comparisons",()=>{
  const p=parse('eval{ #5fro > #2fro }');
  const r=analyze(p.ast,p.diagnostics);
  assert.equal(r.diagnostics.length,0);
});

test("rejects cross-dimension comparisons",()=>{
  const p=parse('eval{ #5fro > %20 }');
  const r=analyze(p.ast,p.diagnostics);
  assert.equal(r.diagnostics.some(d=>d.code==="SEM-006"),true);
});

test("resolves forward action references while keeping the policy provisional",()=>{
  const p=parse('do{ id"tick" } action{ id"tick" }');
  const r=analyze(p.ast,p.diagnostics);
  assert.equal(r.diagnostics.length,0);
  assert.equal(r.model.resolvedReferences.size,1);
});

test("does not collide across namespaces after case normalization",()=>{
  const p=parse('add{ id"Player" } action{ id"player" }');
  const r=analyze(p.ast,p.diagnostics);
  assert.equal(r.diagnostics.length,0);
});

test("records event binding policy and condition/response boundary",()=>{
  const p=parse('event{ id"boss" [health] > #0 then do id"tick" }');
  const r=analyze(p.ast,p.diagnostics);
  const e=p.ast.body[0] as any;
  const spec=r.model.eventBindings.get(e);
  assert.equal(!!spec,true);
  assert.equal(spec?.conditionNodes.length,2);
  assert.equal(spec?.responseNodes.length,2);
  assert.equal(spec?.singlefireEpisodePolicy,"per-satisfying-binding");
});

test("rejects ambiguous unqualified event value references",()=>{
  const p=parse('event{ [health] > #0 then do id"tick" }');
  const r=analyze(p.ast,p.diagnostics);
  assert.equal(r.diagnostics.some(d=>d.code==="SEM-008"),true);
});

test("records deterministic mutation source order",()=>{
  const p=parse('mod [a]=#1 mod [b]=#2 mod [a]+=#3');
  const r=analyze(p.ast,p.diagnostics);
  const mutations:any[]=[];
  const walk=(s:any)=>{
    if(s.kind==="Command") for(const a of s.args) if(a.kind==="MutationExpr") mutations.push(a);
    if(s.kind==="BlockStatement") for(const x of s.body) walk(x);
    if(s.kind==="Command") for(const x of s.body?.body??[]) walk(x);
  };
  p.ast.body.forEach(walk);
  assert.deepEqual(mutations.map(m=>r.model.mutationOrder.get(m)),[0,1,2]);
});

test("uses the locked numeric determinism policy",()=>{
  const p=parse('eval{ #2 + #3 }');
  const r=analyze(p.ast,p.diagnostics);
  assert.equal(r.model.numericPolicy.representation,"IEEE-754-binary64");
  assert.equal(r.model.numericPolicy.trigonometry,"not-in-first-release");
});

import { RUNTIME_HOST_POLICY, decideExe } from "../src/runtime/policy";
import { SEMANTIC_DIAGNOSTICS } from "../src/semantic/diagnostics";

test("locks fetched-module failure policy without making main-module failure recoverable",()=>{
  assert.equal(RUNTIME_HOST_POLICY.module.parseAtFetch,true);
  assert.equal(decideExe("fetched",true),"noop-with-diagnostic");
  assert.equal(decideExe("main",true),"fatal");
  assert.equal(decideExe("fetched",false),"execute");
});

test("locks removal cleanup policy",()=>{
  assert.equal(RUNTIME_HOST_POLICY.removal.stopBoundAudio,true);
  assert.equal(RUNTIME_HOST_POLICY.removal.stopBoundProcesses,true);
  assert.equal(RUNTIME_HOST_POLICY.removal.cameraRemainsValid,true);
});

test("locks deterministic randomness contract without inventing an algorithm",()=>{
  assert.equal(RUNTIME_HOST_POLICY.randomness.hostSuppliedSeed,true);
  assert.equal(RUNTIME_HOST_POLICY.randomness.deterministicGenerator,true);
  assert.equal(RUNTIME_HOST_POLICY.randomness.algorithm,"runtime-defined-deterministic-generator");
});

test("locks fixed timestep accumulator policy",()=>{
  assert.equal(RUNTIME_HOST_POLICY.timestep.accumulator,true);
  assert.equal(RUNTIME_HOST_POLICY.timestep.maxStepCountPerFrame,"configurable");
});

test("locks configurable resource-limit policy",()=>{
  assert.equal(RUNTIME_HOST_POLICY.resourceLimits.configurable,true);
  assert.equal(RUNTIME_HOST_POLICY.resourceLimits.diagnosticsOnLimit,true);
});

test("locks game-defined canbreak policy",()=>{
  assert.equal(RUNTIME_HOST_POLICY.canbreak.gameDefinedViaEvents,true);
  assert.equal(RUNTIME_HOST_POLICY.canbreak.engineFlagOnly,true);
});

test("locks prerelease version policy",()=>{
  assert.equal(RUNTIME_HOST_POLICY.languageVersion.prereleaseMajor,0);
  assert.equal(RUNTIME_HOST_POLICY.languageVersion.onePointZeroAfterF4Conformance,true);
  assert.equal(RUNTIME_HOST_POLICY.languageVersion.missingVersionComponentsReadAsZero,true);
});

test("semantic diagnostic catalogue is stable for the currently implemented codes",()=>{
  assert.equal(SEMANTIC_DIAGNOSTICS.length,8);
  assert.deepEqual(SEMANTIC_DIAGNOSTICS.map(x=>x.code),["SEM-001","SEM-002","SEM-003","SEM-004","SEM-005","SEM-006","SEM-007","SEM-008"]);
  assert.equal(SEMANTIC_DIAGNOSTICS.every(x=>x.severity==="error"),true);
});
