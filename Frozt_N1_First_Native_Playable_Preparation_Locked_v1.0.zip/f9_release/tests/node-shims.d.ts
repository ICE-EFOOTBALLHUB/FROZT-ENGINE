declare module "node:test" {
  interface TestContext {}
  type TestFn = (name: string, fn: () => void) => void;
  const test: TestFn;
  export default test;
}
declare module "node:assert/strict" {
  const assert: {
    deepEqual(actual: unknown, expected: unknown): void;
    equal(actual: unknown, expected: unknown): void;
    ok(value: unknown, message?: string): void;
    throws(fn: () => unknown): void;
    doesNotThrow(fn: () => unknown): void;
  };
  export default assert;
}
declare module "node:fs" {
  export function readFileSync(path: string): Uint8Array;
}
declare const process: {
  argv: string[];
  exit(code?: number): never;
};
