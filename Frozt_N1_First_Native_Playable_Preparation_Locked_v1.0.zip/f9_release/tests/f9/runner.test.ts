import test from 'node:test';
import assert from 'node:assert/strict';
import { EndlessRunnerGame, createEnvironment } from '../../src';

test('F9 runner supports jump, duck and light attack with deterministic state',()=>{
 const a=new EndlessRunnerGame(42), b=new EndlessRunnerGame(42);
 const env=createEnvironment({width:480,height:900,dpi:2,safeArea:{left:0,top:24,right:0,bottom:12},pointer:true,capabilities:new Set(['touch'])});
 assert.equal(a.updatePresentation(env).variant,'compact');
 for(let i=0;i<180;i++){const action=i===5?'jump':i===60?'duck':i===100?'attack':undefined;a.step(action);b.step(action);}
 assert.deepEqual(a.snapshot,b.snapshot);
 assert.ok(a.snapshot.score>0);
});

test('F9 attack destroys attack obstacles without damaging the player',()=>{
 const g=new EndlessRunnerGame(1);
 for(let i=0;i<240;i++)g.step('attack');
 assert.ok(g.snapshot.lives>=1);
});

test('F9 lives reach game over and reset restores a fresh run',()=>{
 const g=new EndlessRunnerGame(7);
 for(let i=0;i<1800 && !g.snapshot.gameOver;i++)g.step();
 assert.equal(g.snapshot.gameOver,true);
 assert.equal(g.snapshot.lives,0);
 g.reset();
 assert.deepEqual(g.snapshot,{score:0,lives:3,gameOver:false,playerY:0,playerVelocity:0,ducking:false,attacking:false,distance:0,speed:7,obstacles:[]});
});

test('F9 compact presentation exposes mobile action affordances while simulation stays unchanged',()=>{
 const g=new EndlessRunnerGame(9); const before=g.snapshot;
 const env=createEnvironment({width:480,height:900,dpi:2,safeArea:{left:0,top:24,right:0,bottom:12},pointer:true,capabilities:new Set(['touch'])});
 g.updatePresentation(env); const ids=g.face(env).map(x=>x.id); assert.deepEqual(ids.slice(-3),['jump','duck','attack']); assert.deepEqual(g.snapshot,before);
});
