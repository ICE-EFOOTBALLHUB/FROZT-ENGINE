const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const test = require('node:test');

test('UTF-8 polyfill accepts valid UTF-8 and rejects malformed bytes in fatal mode', () => {
  const src = fs.readFileSync('host_bootstrap/utf8-polyfill.js', 'utf8');
  const ctx = { Uint8Array, ArrayBuffer, TextEncoder: undefined, TextDecoder: undefined, globalThis: null };
  ctx.globalThis = ctx;
  vm.runInNewContext(src, ctx);
  const bytes = new ctx.TextEncoder().encode('FROZT ✓');
  assert.equal(new ctx.TextDecoder('utf-8', { fatal: true }).decode(bytes), 'FROZT ✓');
  assert.throws(() => new ctx.TextDecoder('utf-8', { fatal: true }).decode(new Uint8Array([0xC0, 0x80])), /invalid UTF-8/);
});
