import assert from "node:assert/strict";
import test from "node:test";
import { parse } from "../src/parser";

test("combines an adjacent number and unit into one semantic literal",()=>{
  const p=parse('eval{ #5fro + #2fro }');
  assert.equal(p.diagnostics.length,0);
  const body=p.ast.body[0];
  assert.equal(body.kind,"Command");
  if(body.kind!=="Command" || !body.body) return;
  const expr=body.body.body.find(s=>s.kind==="ExpressionStatement");
  assert.equal(!!expr && expr.kind==="ExpressionStatement",true);
  if(!expr || expr.kind!=="ExpressionStatement") return;
  assert.equal(expr.expression.kind,"BinaryExpr");
  if(expr.expression.kind!=="BinaryExpr") return;
  assert.equal(expr.expression.left.kind,"LiteralExpr");
  if(expr.expression.left.kind!=="LiteralExpr") return;
  assert.equal(expr.expression.left.tokenKind,"UNIT");
  assert.equal(expr.expression.left.value,"5fro");
});

test("parses do blocks containing action references without a lexer change",()=>{
  const p=parse('do{ id"tick" }');
  assert.equal(p.diagnostics.length,0);
  const cmd=p.ast.body[0];
  assert.equal(cmd.kind,"Command");
  if(cmd.kind!=="Command") return;
  assert.equal(!!cmd.body,true);
  assert.equal(cmd.body?.body[0]?.kind,"ExpressionStatement");
});
