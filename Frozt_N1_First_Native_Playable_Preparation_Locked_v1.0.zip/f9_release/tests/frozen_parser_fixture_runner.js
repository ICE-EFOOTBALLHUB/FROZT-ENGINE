const fs=require('fs'), path=require('path'), {parse}=require('../dist/src/parser');
const dir=path.join(__dirname,'..','fixtures_frozen_regression','f2_6'); const manifest=JSON.parse(fs.readFileSync(path.join(dir,'manifest.json'),'utf8'));
let pass=0;
for(const file of manifest.fixtures){const f=JSON.parse(fs.readFileSync(path.join(dir,file),'utf8')); const r=parse(f.source); const got=r.diagnostics.length; if(got!==f.expected.diagnosticCount){console.error(`${file}: expected ${f.expected.diagnosticCount}, got ${got}`); process.exitCode=1;} else pass++;}
console.log(`F2.6 parser fixture conformance: ${pass}/${manifest.fixtures.length} passed`);
if(pass!==manifest.fixtures.length) process.exitCode=1;
