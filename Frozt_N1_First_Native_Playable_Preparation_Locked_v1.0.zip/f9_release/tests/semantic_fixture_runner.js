const fs=require('fs'),path=require('path');
const {parse}=require('../dist/src/parser');
const {analyze}=require('../dist/src/semantic');
const dir=path.join(__dirname,'..','fixtures','f3_1');
let pass=0,total=0;
for(const f of fs.readdirSync(dir).filter(x=>x.endsWith('.json')).sort()){
  const x=JSON.parse(fs.readFileSync(path.join(dir,f),'utf8')); total++;
  const p=parse(x.source); const r=analyze(p.ast,p.diagnostics);
  const got=r.diagnostics.map(d=>d.code);
  const ok=JSON.stringify(got)===JSON.stringify(x.expectedDiagnostics);
  console.log(`${ok?'PASS':'FAIL'} ${f}: got [${got.join(', ')}], expected [${x.expectedDiagnostics.join(', ')}]`);
  if(!ok) process.exitCode=1; else pass++;
}
console.log(`${pass}/${total} semantic fixtures passed`);
if(pass!==total) process.exitCode=1;
