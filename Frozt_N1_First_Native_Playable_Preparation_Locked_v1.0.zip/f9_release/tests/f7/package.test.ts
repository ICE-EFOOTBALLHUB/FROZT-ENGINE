import test from 'node:test';
import assert from 'node:assert/strict';
import { loadFzt, INVALID_GAME_INFO } from '../../src/package/loader';
import { GameSaveStore } from '../../src/package/save-store';

function crc32(bytes: Uint8Array): number { let c=0xffffffff; for(const b of bytes){c^=b;for(let k=0;k<8;k++)c=(c>>>1)^((c&1)?0xedb88320:0);} return (c^0xffffffff)>>>0; }
function u16(n:number){return [n&255,n>>>8&255];} function u32(n:number){return [n&255,n>>>8&255,n>>>16&255,n>>>24&255];}
function zipStored(files: Record<string,string>): Uint8Array {
  const enc=new TextEncoder(), chunks:number[][]=[], central:number[][]=[]; let offset=0;
  for(const [name,text] of Object.entries(files)){
    const n=enc.encode(name), d=enc.encode(text), h=[...u32(0x04034b50),...u16(20),...u16(0),...u16(0),...u16(0),...u16(0),...u32(crc32(d)),...u32(d.length),...u32(d.length),...u16(n.length),...u16(0),...n,...d];
    chunks.push(h); central.push([...u32(0x02014b50),...u16(20),...u16(20),...u16(0),...u16(0),...u16(0),...u16(0),...u32(crc32(d)),...u32(d.length),...u32(d.length),...u16(n.length),...u16(0),...u16(0),...u16(0),...u16(0),...u32(0),...u32(offset),...n]); offset += h.length;
  }
  const cd=central.flat(), body=chunks.flat(), e=[...u32(0x06054b50),...u16(0),...u16(0),...u16(Object.keys(files).length),...u16(Object.keys(files).length),...u32(cd.length),...u32(body.length),...u16(0)]; return new Uint8Array([...body,...cd,...e]);
}

test('F7 loads a valid .fzt and exposes package-relative files',()=>{
  const bytes=zipStored({'metadata/meta.txt':'game_name=Test\ngame_version=1.0.0\nfrozt_version=0.7.0\npackage_id=test.game\n','main.frozt':'hello','assets/a.txt':'asset'});
  const p=loadFzt(bytes); assert.equal(p.meta.package_id,'test.game'); assert.equal(new TextDecoder().decode(p.mainSource),'hello'); assert.equal(new TextDecoder().decode(p.read('assets/a.txt')!), 'asset'); assert.equal(p.read('../x'),undefined);
});

test('F7 rejects missing or invalid game info with exact player-safe message',()=>{
  const expectInvalid=(bytes:Uint8Array)=>{let message=''; try{loadFzt(bytes);}catch(e){message=e instanceof Error?e.message:String(e);} assert.equal(message,INVALID_GAME_INFO);};
  expectInvalid(zipStored({'main.frozt':'x'}));
  expectInvalid(zipStored({'metadata/meta.txt':'game_name=x\ngame_version=bad\nfrozt_version=0.7.0\npackage_id=x\n','main.frozt':'x'}));
});

test('F7 rejects traversal and absolute package paths',()=>{
  const bytes=zipStored({'metadata/meta.txt':'game_name=x\ngame_version=1.0.0\nfrozt_version=0.7.0\npackage_id=x\n','main.frozt':'x','../escape':'x'}); assert.throws(()=>loadFzt(bytes));
});

test('F7 save envelope is package/version scoped and deterministic',()=>{
  const s=new GameSaveStore('test.game','1.0.0'); s.put('score',42); s.put('name','ICE'); const e=s.exportEnvelope(); assert.deepEqual(Object.keys(e.values),['name','score']); const same=new GameSaveStore('test.game','1.0.0'); assert.equal(same.importEnvelope(e),true); assert.equal(same.get('score'),42); const wrong=new GameSaveStore('test.game','2.0.0'); assert.equal(wrong.importEnvelope(e),false);
});
