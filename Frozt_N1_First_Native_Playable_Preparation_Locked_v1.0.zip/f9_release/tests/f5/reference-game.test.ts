declare const require: (id:string)=>any;
import test from "node:test";
import assert from "node:assert/strict";
import { F5CoreEngine, NavigationController } from "../../src/engine/f5";
import { assertSerializableRenderModel } from "../../src/host/render-model";

function run(renderDts:number[]): {position:{x:number;y:number}; render:string; random:string} {
  const engine=new F5CoreEngine({readPackageFile:()=>undefined},12345,{viewport:{width:320,height:180,dpi:1}});
  engine.layers.declare("Actors",10); engine.renderModel.setLayers(engine.layers.ordered());
  const id=engine.spatial.add("player",{x:0,y:0},"Actors");
  engine.navigation.addNode("start",{x:0,y:0}); engine.navigation.addNode("mid",{x:5,y:0}); engine.navigation.addNode("goal",{x:10,y:0});
  engine.navigation.addEdge("start","mid",1,["walk"]); engine.navigation.addEdge("mid","goal",1,["walk"]);
  const nav=new NavigationController(engine.navigation,engine.spatial); nav.setCapabilities(id,["walk"]); assert.equal(nav.navigate({objectId:id,target:{x:10,y:0},speed:5}).status,"moving");
  engine.renderModel.addSprite("Actors",{imageId:"player",x:10,y:0,scaleX:1,scaleY:1,rotation:0,mirrorX:false,mirrorY:false,opacity:1,visible:true});
  for(const dt of renderDts) engine.frame(dt,()=>{nav.step(1/60);});
  const model=engine.renderModel.build(); assertSerializableRenderModel(model);
  const random=Array.from({length:3},()=>engine.random.next()).map(x=>x.toFixed(12)).join(",");
  return {position:engine.spatial.get(id)!.position,render:JSON.stringify(model),random};
}

test("F5 reference game is deterministic across render rates",()=>{
  const a=run(Array.from({length:60},()=>1/30));
  const b=run(Array.from({length:120},()=>1/60));
  assert.deepEqual(a.position,b.position);
  assert.equal(a.render,b.render);
  assert.equal(a.random,b.random);
  assert.deepEqual(a.position,{x:10,y:0});
  assert.equal(a.random,"0.979728267761,0.306752264500,0.484205421526");
  assert.equal(a.render,requireGolden());
});

function requireGolden():string {
  return JSON.stringify({version:1,viewport:{width:320,height:180,dpi:1},clearColor:{r:0,g:0,b:0,a:1},camera:{x:0,y:0,zoom:1,rotation:0},worldLayers:[{id:"World",order:0,sprites:[]},{id:"Actors",order:10,sprites:[{kind:"sprite",imageId:"player",x:10,y:0,scaleX:1,scaleY:1,rotation:0,mirrorX:false,mirrorY:false,opacity:1,visible:true}]}],face:{id:"Face",elements:[]}});
}
