import test from "node:test";
import assert from "node:assert/strict";
import { SpatialRegistry, boundaryDistance, rangeof, LayerRegistry, NavigationGraph, NavigationController, InputState, InputMapper, FixedStepper, AssetStore, RenderModelBuilder } from "../../src/engine/f5";
import { assertSerializableRenderModel } from "../../src/host/render-model";
import { SeededRandom } from "../../src/runtime/runtime";

const close=(a:number,b:number)=>assert.ok(Math.abs(a-b)<1e-9,`${a} != ${b}`);

test("F5.1 spatial registry uses world x/y and foot anchor",()=>{
  const s=new SpatialRegistry(); const a=s.add("player",{x:10,y:20},"World",{x:0,y:-2}); const b=s.add("npc",{x:13,y:24});
  assert.deepEqual(s.worldFoot(a),{x:10,y:18}); close(s.distance(a,b)!,Math.hypot(3,6));
  assert.equal(s.move(a,{x:2,y:3}),true); assert.deepEqual(s.get(a)?.position,{x:12,y:23});
  assert.equal(s.remove(a),true); assert.equal(s.get(a),undefined);
});

test("F5.2 boundary distance is minimum boundary-to-boundary and contact is zero",()=>{
  close(rangeof({kind:"circle",x:0,y:0,radius:2},{kind:"circle",x:7,y:0,radius:1}),4);
  close(rangeof({kind:"circle",x:0,y:0,radius:2},{kind:"circle",x:3,y:0,radius:1}),0);
  close(boundaryDistance({kind:"rect",x:0,y:0,width:2,height:2},{kind:"rect",x:5,y:4,width:2,height:2}),Math.hypot(3,2));
  close(boundaryDistance({kind:"circle",x:5,y:0,radius:1},{kind:"rect",x:0,y:0,width:2,height:2}),3);
});

test("F5.3 layers are game-declared; Face is fixed and same-layer interaction only",()=>{
  const l=new LayerRegistry(); l.declare("Back",-10); l.declare("Actors",10);
  assert.equal(l.get("Face")?.kind,"face"); assert.equal(l.interactionAllowed("Actors","Actors"),true); assert.equal(l.interactionAllowed("Actors","Back"),false); assert.deepEqual(l.ordered().map(x=>x.id),["Back","World","Actors","Face"]);
  assert.throws(()=>l.declare("Face",0,"world"));
});

test("F5.4 navigation respects capabilities, is interruptible, and relinquishes on no route",()=>{
  const g=new NavigationGraph(); g.addNode("a",{x:0,y:0}); g.addNode("b",{x:10,y:0}); g.addNode("c",{x:20,y:0});
  g.addEdge("a","b",1,["walk"]); g.addEdge("b","c",1,["walk"]);
  const s=new SpatialRegistry(); const id=s.add("actor",{x:0,y:0}); const n=new NavigationController(g,s); n.setCapabilities(id,["walk"]);
  assert.equal(n.navigate({objectId:id,target:{x:20,y:0},speed:10}).status,"moving");
  n.step(1.5); assert.deepEqual(s.get(id)?.position,{x:15,y:0});
  n.step(0.5); assert.deepEqual(s.get(id)?.position,{x:20,y:0});
  assert.equal(n.navigate({objectId:id,target:{x:20,y:0},requiredCapabilities:["fly"],speed:10}).status,"no-route");
  assert.equal(n.interrupt(id).status,"interrupted");
  s.setPosition(id,{x:0,y:0}); n.setCapabilities(id,[]); assert.equal(n.navigate({objectId:id,target:{x:20,y:0},speed:10}).status,"no-route");
});

test("F5.5 input has pressed/held/released and independent mappings with multitouch",()=>{
  const i=new InputState(); i.consume({type:"key",phase:"down",key:"A",repeat:false}); i.consume({type:"pointer",phase:"down",pointerId:2,x:4,y:5});
  assert.equal(i.pressed("key:A"),true); assert.equal(i.held("key:A"),true); assert.equal(i.held("pointer:2"),true); assert.deepEqual(i.pointer(2),{x:4,y:5,pressure:0,down:true});
  const m=new InputMapper(); m.bind("move",["key:A","key:D"]); assert.equal(m.active("move",i,"pressed"),true);
  i.beginFrame(); assert.equal(i.pressed("key:A"),false); assert.equal(i.held("key:A"),true); i.consume({type:"key",phase:"up",key:"A",repeat:false}); assert.equal(i.released("key:A"),true); assert.equal(i.held("key:A"),false);
});

test("F5.6 fixed timing is 60Hz and render rate is independent",()=>{
  const f=new FixedStepper(); let ticks=0; assert.equal(f.advance(1/30,()=>ticks++),2); assert.equal(ticks,2); assert.equal(f.tick,2); assert.equal(f.advance(1/120,()=>ticks++),0); assert.equal(f.advance(1/120,()=>ticks++),1); assert.equal(ticks,3);
});

test("F5.7 seeded PRNG is deterministic",()=>{
  const a=new SeededRandom(12345), b=new SeededRandom(12345);
  for(let i=0;i<8;i++) close(a.next(),b.next());
});

test("F5.8 assets are package-relative, copied, and missing assets are safe",()=>{
  const calls:string[]=[]; const host={readPackageFile:(p:string)=>{calls.push(p);return p==="assets/a.bin"?{bytes:new Uint8Array([1,2,3])}:undefined}};
  const diagnostics:string[]=[]; const a=new AssetStore(host,m=>diagnostics.push(m));
  assert.deepEqual([...a.read("assets/a.bin").bytes!],[1,2,3]); assert.equal(a.read("missing.bin").missing,true); assert.equal(a.read("../escape").missing,true); assert.deepEqual(calls,["assets/a.bin","missing.bin"]); assert.equal(diagnostics.length,2);
});

test("F5.9 render model is deterministic, ordered, Face-relative and JSON golden-safe",()=>{
  const b=new RenderModelBuilder(); b.setViewport(800,600,2); b.setLayers([{id:"Z",order:20,kind:"world"},{id:"A",order:10,kind:"world"},{id:"Face",order:999,kind:"face"}]);
  b.addSprite("Z",{imageId:"hero",x:2,y:3,scaleX:1,scaleY:1,rotation:0,mirrorX:false,mirrorY:false,opacity:1,visible:true});
  b.addSprite("A",{imageId:"bg",x:0,y:0,scaleX:1,scaleY:1,rotation:0,mirrorX:false,mirrorY:false,opacity:1,visible:true});
  b.setFace([{kind:"text",id:"score",x:5,y:5,text:"7",size:16,color:{r:1,g:1,b:1,a:1},opacity:1,visible:true}]);
  const m=b.build(); assert.deepEqual(m.worldLayers.map(x=>x.id),["A","Z"]); assert.equal(m.face.id,"Face"); assert.equal(JSON.stringify(m),JSON.stringify(b.build())); assert.doesNotThrow(()=>assertSerializableRenderModel(m));
});
