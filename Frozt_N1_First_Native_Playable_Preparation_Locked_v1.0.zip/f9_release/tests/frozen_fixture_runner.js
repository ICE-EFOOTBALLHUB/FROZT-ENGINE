
const fs = require("node:fs");
const path = require("node:path");
const { Lexer } = require("../dist/src/lexer/lexer");

const dir = path.join(__dirname, "..", "fixtures_frozen_regression", "f1_3");
const files = fs.readdirSync(dir).filter(f => f.endsWith(".json") && f !== "manifest.json").sort();

function projectToken(t) {
  const out = {kind:t.kind, raw:t.raw};
  if (t.value !== undefined) out.value = t.value;
  return out;
}
function projectTrivia(t) {
  const out = {kind:t.kind, raw:t.raw};
  if (t.value !== undefined) out.value = t.value;
  return out;
}
function projectDiag(d) {
  return {
    code:d.code, severity:d.severity,
    startByte:d.start.byte, endByte:d.end.byte
  };
}
function assertEq(a,b,label) {
  const aj = JSON.stringify(a), bj = JSON.stringify(b);
  if (aj !== bj) throw new Error(`${label}\nexpected: ${bj}\nactual:   ${aj}`);
}

let passed = 0;
for (const file of files) {
  const fx = JSON.parse(fs.readFileSync(path.join(dir,file), "utf8"));
  const r = new Lexer(fx.source).lex();

  assertEq(r.tokens.map(projectToken), fx.expected.tokens, `${fx.id}: tokens`);
  assertEq(r.trivia.map(projectTrivia), fx.expected.trivia, `${fx.id}: trivia`);
  assertEq(r.diagnostics.map(projectDiag), fx.expected.diagnostics, `${fx.id}: diagnostics`);

  if (fx.locationChecks) {
    for (const c of fx.locationChecks) {
      const t = r.tokens.find(x => x.kind === c.kind && (c.raw === undefined || x.raw === c.raw));
      if (!t) throw new Error(`${fx.id}: location target not found ${c.kind}/${c.raw ?? ""}`);
      assertEq(
        {startByte:t.start.byte,endByte:t.end.byte,line:t.start.line,column:t.start.column},
        {startByte:c.startByte,endByte:c.endByte,line:c.line,column:c.column},
        `${fx.id}: location ${c.kind}/${c.raw}`
      );
    }
  }
  passed++;
}
console.log(`F1.3 fixture conformance: ${passed}/${files.length} passed`);
