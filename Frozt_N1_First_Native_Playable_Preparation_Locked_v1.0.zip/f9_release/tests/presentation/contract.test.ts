import test from 'node:test';
import assert from 'node:assert/strict';
import { createEnvironment, PresentationController, selectVariant } from '../../src/presentation';

test('adaptive presentation is driven by environment, not platform identity',()=>{
  const env=createEnvironment({width:480,height:900,dpi:2,safeArea:{left:0,top:24,right:0,bottom:12},pointer:true,capabilities:new Set(['touch'])});
  const id=selectVariant(env,[{id:'expanded',priority:10,when:e=>e.width>=900},{id:'compact',priority:1,when:e=>e.orientation==='portrait'}]); assert.equal(id,'compact');
});

test('presentation changes do not mutate simulation state',()=>{
  const c=new PresentationController(); const variants=[{id:'compact',priority:1,when:(e:any)=>e.orientation==='portrait'},{id:'expanded',priority:1,when:(e:any)=>e.orientation==='landscape'}];
  const a=c.update(createEnvironment({width:400,height:800,dpi:1,safeArea:{left:0,top:0,right:0,bottom:0},pointer:true,capabilities:new Set(['touch'])}),variants); const b=c.update(createEnvironment({width:1200,height:800,dpi:1,safeArea:{left:0,top:0,right:0,bottom:0},pointer:true,capabilities:new Set(['mouse','keyboard'])}),variants); assert.equal(a.variant,'compact'); assert.equal(b.variant,'expanded'); assert.equal(a.revision+1,b.revision);
});
