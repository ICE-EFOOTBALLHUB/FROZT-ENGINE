const fs=require('fs'),path=require('path'),assert=require('node:assert/strict');
const {RUNTIME_HOST_POLICY,decideExe}=require('../dist/src/runtime/policy');
const dir=path.join(__dirname,'..','fixtures','f3_2');
let pass=0,total=0;
for(const f of fs.readdirSync(dir).filter(x=>/^\d+_.*\.json$/.test(x)).sort()){
  const x=JSON.parse(fs.readFileSync(path.join(dir,f),'utf8')); total++;
  let got;
  if(f.startsWith('001_')) got=decideExe('fetched',true);
  else if(f.startsWith('002_')) got=decideExe('main',true);
  else if(f.startsWith('003_')) got=decideExe('fetched',false);
  else if(f.startsWith('004_')) got=RUNTIME_HOST_POLICY.removal;
  else if(f.startsWith('005_')) got=RUNTIME_HOST_POLICY.randomness;
  else if(f.startsWith('006_')) got=RUNTIME_HOST_POLICY.timestep;
  else if(f.startsWith('007_')) got=RUNTIME_HOST_POLICY.canbreak;
  else got=RUNTIME_HOST_POLICY.languageVersion;
  try { assert.deepEqual(got,x.expected ?? x); console.log(`PASS ${f}`); pass++; }
  catch(e){ console.log(`FAIL ${f}:`,e.message); process.exitCode=1; }
}
console.log(`${pass}/${total} runtime/host policy fixtures passed`);
if(pass!==total) process.exitCode=1;
