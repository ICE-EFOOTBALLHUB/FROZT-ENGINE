const fs = require('node:fs');
const path = require('node:path');
const { parse } = require('../dist/src/parser');
const dir = path.join(__dirname, '..', 'fixtures_frozen_regression', 'f2_6');
const manifest = JSON.parse(fs.readFileSync(path.join(dir, 'manifest.json'), 'utf8'));
let passed = 0;
for (const file of manifest.fixtures) {
  const fx = JSON.parse(fs.readFileSync(path.join(dir, file), 'utf8'));
  const r = parse(fx.source);
  if (r.diagnostics.length !== fx.expected.diagnosticCount) {
    throw new Error(`${fx.id}: expected ${fx.expected.diagnosticCount} diagnostics, got ${r.diagnostics.length}`);
  }
  console.log(`PASS ${fx.id}: diagnostics=${r.diagnostics.length}`);
  passed++;
}
console.log(`F2.6 parser fixture conformance: ${passed}/${manifest.fixtures.length} passed`);
