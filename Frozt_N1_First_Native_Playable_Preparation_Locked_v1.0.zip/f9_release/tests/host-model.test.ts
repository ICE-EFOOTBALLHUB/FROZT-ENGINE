import test from "node:test";
import assert from "node:assert/strict";
import { assertSerializableRenderModel, type RenderModel } from "../src/host";

test("render model is JSON-serializable and round-trips", () => {
  const model: RenderModel = {
    version: 1,
    viewport: { width: 1280, height: 720, dpi: 1 },
    clearColor: { r: 0, g: 0, b: 0, a: 1 },
    camera: { x: 0, y: 0, zoom: 1, rotation: 0 },
    worldLayers: [{ id: "world", order: 0, sprites: [{ kind: "sprite", imageId: "player", x: 1, y: 2, scaleX: 1, scaleY: 1, rotation: 0, mirrorX: false, mirrorY: false, opacity: 1, visible: true, animation: { animationId: "idle", frame: 2, frameTime: 0.1 } }] }],
    face: { id: "Face", elements: [{ kind: "text", id: "score", x: 10, y: 10, text: "0", size: 24, color: { r: 1, g: 1, b: 1, a: 1 }, opacity: 1, visible: true }] }
  };
  assertSerializableRenderModel(model);
  const encoded = JSON.stringify(model);
  assert.equal(Boolean(encoded), true);
  assert.deepEqual(JSON.parse(encoded!), model);
});

test("render model preserves declared layer and Face element order", () => {
  const model: RenderModel = {
    version: 1, viewport: {width:1,height:1,dpi:1}, clearColor:{r:0,g:0,b:0,a:1}, camera:{x:0,y:0,zoom:1,rotation:0},
    worldLayers: [
      {id:"back",order:0,sprites:[]},
      {id:"front",order:1,sprites:[{kind:"sprite",imageId:"b",x:0,y:0,scaleX:1,scaleY:1,rotation:0,mirrorX:false,mirrorY:false,opacity:1,visible:true},{kind:"sprite",imageId:"a",x:0,y:0,scaleX:1,scaleY:1,rotation:0,mirrorX:false,mirrorY:false,opacity:1,visible:true}] }
    ],
    face:{id:"Face",elements:[{kind:"text",id:"a",x:0,y:0,text:"A",size:1,color:{r:1,g:1,b:1,a:1},opacity:1,visible:true},{kind:"text",id:"b",x:0,y:0,text:"B",size:1,color:{r:1,g:1,b:1,a:1},opacity:1,visible:true}]}
  };
  const roundTrip = JSON.parse(JSON.stringify(model)) as RenderModel;
  assert.deepEqual(roundTrip.worldLayers.map(x=>x.id), ["back","front"]);
  assert.deepEqual(roundTrip.worldLayers[1].sprites.map(x=>x.imageId), ["b","a"]);
  assert.deepEqual(roundTrip.face.elements.map(x=>x.id), ["a","b"]);
});
