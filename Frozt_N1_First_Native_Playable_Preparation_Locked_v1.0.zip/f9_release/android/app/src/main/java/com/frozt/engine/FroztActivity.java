package com.frozt.engine;

/** Thin shell marker; SDL's Activity integration owns the native lifecycle. */
public final class FroztActivity { private FroztActivity() {} }
