package com.frozt.runner;

import android.content.Context;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

/** Thin Android lifecycle/input shell. Rendering and simulation stay behind the native host. */
final class FroztRunnerView extends SurfaceView implements SurfaceHolder.Callback {
    static { System.loadLibrary("frozt_android"); }
    private long lastNs;
    FroztRunnerView(Context c) { super(c); getHolder().addCallback(this); setFocusable(true); }
    @Override public boolean onTouchEvent(MotionEvent e) {
        if (e.getActionMasked() != MotionEvent.ACTION_DOWN && e.getActionMasked() != MotionEvent.ACTION_MOVE && e.getActionMasked() != MotionEvent.ACTION_UP) return true;
        int action = e.getActionMasked() == MotionEvent.ACTION_UP ? 3 : (e.getY() < getHeight() * .55 ? 1 : 2);
        if (e.getActionMasked() == MotionEvent.ACTION_DOWN) action = e.getX() > getWidth() * .68 ? 3 : (e.getY() < getHeight() * .55 ? 1 : 2);
        nativeInput(action, e.getX(), e.getY(), e.getActionMasked());
        return true;
    }
    @Override public void surfaceCreated(SurfaceHolder h) { lastNs=System.nanoTime(); nativeStart(getWidth(),getHeight(),getResources().getDisplayMetrics().density); }
    @Override public void surfaceChanged(SurfaceHolder h,int f,int w,int ht) { nativeResize(w,ht,getResources().getDisplayMetrics().density); }
    @Override public void surfaceDestroyed(SurfaceHolder h) { nativeStop(); }
    void suspend(){ nativeSuspend(); }
    void resume(){ nativeResume(); }
    private native void nativeStart(int w,int h,float dpi);
    private native void nativeResize(int w,int h,float dpi);
    private native void nativeInput(int action,float x,float y,int phase);
    private native void nativeSuspend(); private native void nativeResume(); private native void nativeStop();
}
