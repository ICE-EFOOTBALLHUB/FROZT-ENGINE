package com.frozt.runner;

import android.app.Activity;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;

public final class MainActivity extends Activity {
    private FroztRunnerView view;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        view = new FroztRunnerView(this);
        setContentView(view);
    }
    @Override protected void onPause() { super.onPause(); if (view != null) view.suspend(); }
    @Override protected void onResume() { super.onResume(); if (view != null) view.resume(); }
}
