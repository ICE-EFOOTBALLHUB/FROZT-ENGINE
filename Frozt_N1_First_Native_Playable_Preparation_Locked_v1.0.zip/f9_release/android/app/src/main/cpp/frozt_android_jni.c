#include <jni.h>
#include <android/asset_manager.h>
#include <android/asset_manager_jni.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "frozt_host.h"
static FroztHost* g_host;
static JavaVM* g_vm;
JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM* vm, void* reserved){(void)reserved;g_vm=vm;return JNI_VERSION_1_6;}
static void ensure_host(void){ if(g_host)return; FroztHostConfig c={0}; c.seed=0xF7057; g_host=frozt_host_create(&c); }
JNIEXPORT void JNICALL Java_com_frozt_runner_FroztRunnerView_nativeStart(JNIEnv* env,jobject thiz,jint w,jint h,jfloat dpi){
 (void)thiz; ensure_host(); AAssetManager* am=NULL; jclass cls=(*env)->GetObjectClass(env,thiz); (void)cls;
 /* Asset loading is intentionally isolated here; a production shell supplies the manager via its Activity. */
 frozt_host_resize(g_host,w,h,dpi); frozt_host_start(g_host,"frozt.runner");
}
JNIEXPORT void JNICALL Java_com_frozt_runner_FroztRunnerView_nativeResize(JNIEnv* e,jobject o,jint w,jint h,jfloat d){(void)e;(void)o;if(g_host)frozt_host_resize(g_host,w,h,d);}
JNIEXPORT void JNICALL Java_com_frozt_runner_FroztRunnerView_nativeInput(JNIEnv* e,jobject o,jint a,jfloat x,jfloat y,jint p){(void)e;(void)o;(void)x;(void)y;(void)p;if(g_host){char b[128];snprintf(b,sizeof b,"{\"action\":%d}",a);frozt_host_input_json(g_host,b);}}
JNIEXPORT void JNICALL Java_com_frozt_runner_FroztRunnerView_nativeSuspend(JNIEnv* e,jobject o){(void)e;(void)o;if(g_host)frozt_host_suspend(g_host);}
JNIEXPORT void JNICALL Java_com_frozt_runner_FroztRunnerView_nativeResume(JNIEnv* e,jobject o){(void)e;(void)o;if(g_host)frozt_host_resume(g_host);}
JNIEXPORT void JNICALL Java_com_frozt_runner_FroztRunnerView_nativeStop(JNIEnv* e,jobject o){(void)e;(void)o;if(g_host){frozt_host_stop(g_host);frozt_host_destroy(g_host);g_host=NULL;}}
