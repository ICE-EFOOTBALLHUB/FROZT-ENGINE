// Android entry integration point. SDL Activity + NDK build supplies the actual
// platform lifecycle and event translation; no Android types cross the engine API.
extern "C" int frozt_android_shell_version() { return 1; }
