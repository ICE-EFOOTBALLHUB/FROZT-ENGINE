# FROZT Android N1 shell

This is the first native-playable integration shell for the F9 Runner.

## Locked responsibilities

- Android owns Activity/window/lifecycle/touch delivery.
- Native FROZT owns package/runtime/save boundaries.
- The `.fzt` bundle is shipped in `app/src/main/assets/game.fzt`.
- Game code never receives Android paths or Java objects.
- The engine remains platform-neutral.

## Toolchain gate

A real APK requires Android SDK/NDK + Gradle, and production rendering/runtime requires the configured QuickJS and SDL implementations. The current development environment does not contain those dependencies, so this checkpoint deliberately does **not** claim an APK build or device test.

Once the Android toolchain is installed, the expected command is:

    gradle :app:assembleDebug

Then install the resulting debug APK on a device and verify the N1 checklist in `N1_STATUS.md`.
