#!/usr/bin/env python3
"""Build a FROZT .fzt package without extracting or relying on platform tools."""
from pathlib import Path
import argparse, zipfile

REQUIRED = ("game_name", "game_version", "frozt_version", "package_id")

def parse_meta(path: Path):
    values = {}
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if "=" not in line:
            raise SystemExit("invalid game info")
        k, v = line.split("=", 1)
        values[k.strip()] = v.strip()
    if any(not values.get(k) for k in REQUIRED):
        raise SystemExit("invalid game info")
    return values

def safe(name: str):
    p = name.replace("\\", "/")
    return p and not p.startswith("/") and ".." not in p.split("/") and ":" not in p.split("/")[0]

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("source")
    ap.add_argument("output")
    args = ap.parse_args()
    root = Path(args.source).resolve()
    meta = root / "metadata" / "meta.txt"
    main_file = root / "main.frozt"
    if not meta.is_file() or not main_file.is_file():
        raise SystemExit("invalid game info")
    parse_meta(meta)
    with zipfile.ZipFile(args.output, "w", compression=zipfile.ZIP_STORED) as z:
        for path in sorted(root.rglob("*")):
            if path.is_dir():
                continue
            rel = path.relative_to(root).as_posix()
            if not safe(rel):
                raise SystemExit("invalid .fzt path")
            z.write(path, rel)
    print(args.output)

if __name__ == "__main__":
    main()
