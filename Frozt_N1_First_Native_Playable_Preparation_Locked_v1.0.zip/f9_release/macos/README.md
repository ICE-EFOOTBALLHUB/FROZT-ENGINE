# FROZT macos native shell

Uses the shared native Host API and renderer boundary. Platform code translates
window/touch/keyboard/lifecycle events into the same host calls used by Android.
No game source receives OS APIs.
