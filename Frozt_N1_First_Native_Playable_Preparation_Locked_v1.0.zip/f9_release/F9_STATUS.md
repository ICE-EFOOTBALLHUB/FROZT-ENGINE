# FROZT F9 — First Real Game Integration + Engine Hardening

Status: LOCKED v1.0

## Game target
- Android-first endless runner.
- Player remains in a stable world position while the road/obstacles move left to communicate forward motion.
- Player actions: jump, duck, light attack.
- Obstacles are classified as jump, duck, or attack targets.
- Three lives; collision removes a life; zero lives ends the run.
- Score increases deterministically with distance survived.
- Restart/reset returns the simulation to its exact initial state.
- Compact presentation exposes touch action affordances; simulation state remains presentation-independent.

## F9 engineering rule
The first game is a vertical slice and diagnostic instrument. Do not add engine features merely because they seem generally useful. Classify failures as game bug, language/runtime bug, engine bug, missing capability, API/design problem, or platform boundary problem before changing the engine.

## Acceptance
- Deterministic seeded runner simulation.
- Jump, duck and light attack exercised.
- Lives/game-over/reset exercised.
- Compact Android-oriented presentation exercised without simulation mutation.
- Real `.fzt` package produced using the locked F7 format.
- Full F0-F8 regression remains green.
- Native CMake build remains green.
