# FROZT F7 — Package, Lifecycle, Saves & Adaptive Presentation Foundation

## Locked decisions

- `.fzt` is a ZIP container read in memory; it is never extracted.
- `metadata/meta.txt` and `main.frozt` are mandatory.
- Invalid required metadata yields exactly `invalid game info` at the player-facing boundary.
- Package paths cannot escape the package root.
- Read-only package data and mutable saves are separate.
- Saves are scoped by package ID and game version.
- Native save writes are atomic replacement writes.
- The host owns platform-specific save locations; game code never sees filesystem paths.
- Presentation is environment-driven, not platform-name-driven.
- Simulation state is independent of presentation state.
- Presentation can change structure/visibility/interaction model while preserving game state.
- F6 Host API now carries the presentation environment.

## Implemented

- TypeScript in-memory ZIP package reader with Store support and injected Deflate support.
- Metadata parser and runtime-version gate.
- Package-relative safe path handling.
- Game-level save envelope with deterministic export and package/version validation.
- Native C in-memory package reader for the dependency-free F7 baseline.
- Native package-ID validation.
- Native persistent JSON-value save bridge with atomic replacement.
- Adaptive presentation environment, constraints, deterministic variants, and controller foundation.
- FROZT `.fzt` packager using Python standard library and ZIP Store mode.
- F7 focused tests and native smoke path.

## Verification

- Full TypeScript/conformance suite: **61/61 tests PASS**.
- F1 frozen fixtures: 28/28 PASS.
- F2 parser fixtures: 10/10 PASS.
- F3 semantic fixtures: 10/10 PASS.
- Runtime policy fixtures: 8/8 PASS.
- UTF-8 boundary: 1/1 PASS.
- Native CMake build: PASS.
- Native package + persistent-save smoke: PASS.

## Remaining hardware/toolchain gate

This environment still does not provide Android NDK, Xcode/iOS SDK, Windows SDK, QuickJS, SDL, or a production GPU backend. Therefore this checkpoint does not falsely claim signed APK/EXE or real-device graphics verification. Those remain integration gates on the corresponding development machines.
