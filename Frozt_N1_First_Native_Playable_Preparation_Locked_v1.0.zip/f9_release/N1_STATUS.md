# N1 — First Native Playable

## Completed in this batch

- Android application project/shell created.
- F9 Runner `.fzt` copied into Android assets.
- Android lifecycle hooks: create/pause/resume/destroy.
- Touch input bridge skeleton.
- Native host memory-loading API added for asset-backed packages.
- Native host remains the only package/save boundary.
- Portrait-first Android shell selected for the first device validation.

## Environment gate

NOT BUILT HERE: this environment has no Android SDK/NDK, Gradle, SDL, or QuickJS installation. Therefore no APK, device rendering, or device performance result is claimed.

## Device acceptance checklist

1. APK launches and loads `game.fzt`.
2. Runner renders actual world + HUD.
3. Jump/duck/attack respond to touch.
4. Lives decrease on missed obstacles.
5. Score increases during a run.
6. Game-over appears at zero lives.
7. Reset starts a new run.
8. Portrait safe area is respected.
9. Background/resume preserves or deliberately resets state according to lifecycle policy.
10. No package file is written to app storage.
11. Save survives restart where the game uses persistence.
12. No visible frame pacing or input-latency regression at normal device load.
