# FROZT F5 — Core Engine Completion Checkpoint v1.0

Status: **COMPLETE / TESTED**
Date: 2026-10-03

## Scope

F5 implements the platform-neutral core-engine systems required before native backend work:

1. Spatial registry: world x/y coordinates, Y-up convention, foot anchors, object lifecycle.
2. Boundaries and `rangeof`: rectangle/circle geometry; minimum boundary-to-boundary distance; contact/overlap is `#0fro` / numeric zero.
3. Layers: game-declared world layers plus fixed viewport-relative `Face`; world interaction is same-layer only.
4. Navigation: capability-gated graph traversal, interruptible navigation, deterministic movement, and no-route relinquishment.
5. Input: pressed/held/released edges, multi-touch pointer identity, analog values, and mappings separated from input state.
6. Timing: 60 Hz fixed-step simulation independent of host render cadence.
7. Seeded PRNG: deterministic Mulberry32-compatible algorithm using host seed; no platform RNG dependency.
8. Asset access: package-relative reads only through the host boundary; traversal/absolute paths rejected; missing assets return safe fallback state and diagnostics.
9. Render model: plain JSON-serializable frame data containing viewport, camera, ordered world layers, sprites/animation state, and fixed Face elements.

## Determinism contract

For a fixed package, seed, and input/tick stream, F5 state and render-model output must be deterministic. Simulation uses IEEE-754 binary64 numbers and a 60 Hz fixed timestep.

### PRNG vectors

The algorithm is the Mulberry32 family used by `SeededRandom` in `src/runtime/runtime.ts`.

| Seed | First four outputs |
|---|---|
| 0 | 0.000329745701, 0.223272027448, 0.146202147938, 0.467327822931 |
| 1 | 0.627073940588, 0.002735721180, 0.527447039960, 0.981050967472 |
| 12345 | 0.979728267761, 0.306752264500, 0.484205421526, 0.817934412509 |
| 4294967295 | 0.896422614111, 0.189478256740, 0.715652678162, 0.944059909321 |

## Tests

### F5-specific
- **10/10 PASS** — F5 core subsystem and reference-game tests.
- Includes exact geometry cases, layer policy, capability/no-route navigation, interruptibility, multi-touch input, fixed-step timing, seeded randomness, package asset safety, render-model serialization/order, and deterministic reference-game golden output.

### Regression
- **41/41 PASS** — existing parser/semantic/runtime test suite.
- **28/28 PASS** — frozen F1 lexer fixtures.
- **10/10 PASS** — frozen F2 parser fixtures.
- **10/10 PASS** — F3 semantic fixtures.
- **8/8 PASS** — runtime/host policy fixtures.
- **3/3 PASS** — host/render boundary tests.
- **1/1 PASS** — UTF-8 fatal-decoder test.
- TypeScript build: **PASS**.

## Boundary status

F5 does not introduce browser, Node, filesystem, graphics, audio, or network dependencies into the engine source. Platform access remains behind the Host API.

The Render Model v1 is now stable for F6 backend consumption.

The broader Host API OQ-40 remains a separate contract and is not falsely marked locked by this checkpoint; its native ABI and remaining validation belong to the F6 boundary work.

## Tooling note

The existing `bundle` script was invoked during verification but this environment does not contain an `esbuild` executable (`sh: esbuild: not found`). No F5 source or test depends on esbuild. QuickJS/native execution therefore remains an F6 environment validation gate.

## Exit decision

**F5 is complete and may hand off to F6.**

Next phase: **F6 — Native Backend + Embedding**.
