# FROZT Render Model v1 — Draft

Status: LOCKED FOR F6 CONSUMPTION (F5 v1.0)

The engine produces a plain data render model and never draws. Backends consume the model and turn it into platform-specific pixels.

## Frame

- version
- viewport: width, height, dpi
- clear color
- camera: x, y, zoom, rotation
- ordered world layers
- fixed Face layer

## World layers

Each layer has an ID, deterministic order, and an ordered sprite list.

Sprites contain image ID, world position, X/Y scale, rotation, mirror flags, opacity, visibility, and optional animation frame state.

## Face layer

The Face layer is viewport-relative and contains data-only Bar, text, and image elements.

## Conformance

Every render-model fixture must:
1. be JSON-serializable;
2. round-trip through JSON without semantic loss;
3. have deterministic ordering;
4. contain no host/platform objects;
5. be compared as a golden fixture in headless tests.
