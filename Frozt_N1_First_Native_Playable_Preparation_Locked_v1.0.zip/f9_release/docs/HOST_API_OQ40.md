# FROZT Host API — OQ-40 Draft

Status: PROPOSED / NOT LOCKED

The native host is the only platform bridge. The engine must not call browser, Node, OS, filesystem, graphics, audio, or network APIs directly.

## Host -> Engine

- `start(packageId, seed)`
- `stop()`
- `suspend()`
- `resume()`
- `input(event)` — pointer down/move/up with pointer ID; key down/up; analog values
- `tick(dtMs)` — host-driven time input; engine advances its 60 Hz fixed-step simulation
- `resize(width, height, dpi)`

## Engine -> Host

- `readPackageFile(path)` — package-relative only; traversal/absolute paths rejected
- `saveGet(key)` / `savePut(key, value)` / `saveDelete(key)`
- `playAudio` / `pauseAudio` / `stopAudio` / `setVolume` using instance IDs
- `render(model)`
- `diagnostic(record)` — developer runtime
- `sessionComplete()` — game signals completion; host chooses the next lifecycle action

## Open contract points before lock

1. Exact numeric ranges and validation for resize, input, volume, opacity, and seed.
2. Byte ownership/lifetime for package reads.
3. Save value limits and serialization/canonicalization.
4. Audio asset path validation and instance lifetime.
5. Lifecycle call ordering and repeated-call behavior.
6. Whether render-model delivery is copy, borrow, or transfer semantics at the native bridge.
7. Fatal vs recoverable host failures.
8. C/Rust ABI representation.

A Host API conformance suite must exercise these before OQ-40 is locked.
