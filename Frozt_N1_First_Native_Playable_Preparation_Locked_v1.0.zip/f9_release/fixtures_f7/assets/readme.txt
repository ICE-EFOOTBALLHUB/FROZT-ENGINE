FROZT F7 asset
