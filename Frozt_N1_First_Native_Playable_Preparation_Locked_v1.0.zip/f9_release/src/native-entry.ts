import type { FroztHostApi } from "./host/api";
import type { PresentationEnvironment } from "./presentation";

/** Stable native bootstrap surface. The native shell supplies the Host API;
 * this module intentionally contains no DOM, Node, filesystem, timer, or OS use. */
export interface NativeEngineSession {
  start(packageId: string, seed: number): void;
  stop(): void;
  suspend(): void;
  resume(): void;
  input(event: Parameters<FroztHostApi["input"]>[0]): void;
  tick(dtMs: number): void;
  resize(width: number, height: number, dpi: number): void;
  presentationEnvironment(environment: PresentationEnvironment): void;
}

export function createNativeSession(host: FroztHostApi): NativeEngineSession {
  let active = false;
  return {
    start(packageId, seed) { host.start(packageId, seed); active = true; },
    stop() { host.stop(); active = false; },
    suspend() { if (active) host.suspend(); },
    resume() { if (active) host.resume(); },
    input(event) { if (active) host.input(event); },
    tick(dtMs) { if (active) host.tick(dtMs); },
    resize(width, height, dpi) { host.resize(width, height, dpi); },
    presentationEnvironment(environment) { host.presentationEnvironment(environment); },
  };
}
