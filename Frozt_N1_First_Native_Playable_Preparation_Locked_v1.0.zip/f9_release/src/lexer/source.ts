
export class SourceCursor {
  readonly bytes: Uint8Array;
  private index = 0;
  private line = 0;
  private column = 0;
  private readonly text: string;

  constructor(input: Uint8Array | string) {
    this.bytes = typeof input === "string" ? new TextEncoder().encode(input) : input;
    this.text = new TextDecoder("utf-8", { fatal: true, ignoreBOM: true }).decode(this.bytes);
  }

  get sourceText(): string { return this.text; }
  get byteIndex(): number { return this.index; }
  get lineNumber(): number { return this.line; }
  get columnNumber(): number { return this.column; }
  get eof(): boolean { return this.index >= this.bytes.length; }

  position() {
    return { byte: this.index, line: this.line, column: this.column };
  }

  // Advance one Unicode code point while preserving UTF-8 byte offsets.
  advanceCodePoint(): string {
    if (this.eof) return "";
    const cp = this.text.codePointAt(this.codePointIndex())!;
    const ch = String.fromCodePoint(cp);
    const n = new TextEncoder().encode(ch).length;
    this.index += n;
    this.column += 1;
    return ch;
  }

  private codePointIndex(): number {
    // This prototype deliberately scans from the beginning for source-position
    // correctness. F1.2 optimizes only after conformance is established.
    let b = 0, i = 0;
    while (b < this.index) {
      const cp = this.text.codePointAt(i)!;
      b += new TextEncoder().encode(String.fromCodePoint(cp)).length;
      i += cp > 0xFFFF ? 2 : 1;
    }
    return i;
  }

  sliceBytes(start: number, end: number): string {
    return new TextDecoder("utf-8", { fatal: true }).decode(this.bytes.slice(start, end));
  }

  peekByte(offset = 0): number | undefined {
    return this.bytes[this.index + offset];
  }

  peekChar(offset = 0): string {
    let b = this.index;
    let i = this.codePointIndex();
    for (let k = 0; k < offset; k++) {
      const cp = this.text.codePointAt(i)!;
      b += new TextEncoder().encode(String.fromCodePoint(cp)).length;
      i += cp > 0xFFFF ? 2 : 1;
    }
    if (b >= this.bytes.length) return "";
    const cp = this.text.codePointAt(i)!;
    return String.fromCodePoint(cp);
  }

  consumeNewline(): string {
    const start = this.index;
    const c = this.peekChar();
    if (c === "\r") {
      this.advanceCodePoint();
      if (this.peekChar() === "\n") this.advanceCodePoint();
    } else if (c === "\n") {
      this.advanceCodePoint();
    }
    this.line += 1;
    this.column = 0;
    return this.sliceBytes(start, this.index);
  }

  resetPositionAfterConsumedNewline(): void {
    // Kept for explicitness; consumeNewline already updates position.
  }
}
