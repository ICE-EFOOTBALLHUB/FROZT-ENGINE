
import { Diagnostic, LexDiagnosticCode } from "./diagnostic";
import { SourceCursor } from "./source";
import { Token, TokenKind, Trivia, SourcePosition } from "./token";

const ASCII_LETTER = /^[A-Za-z]$/;
const ASCII_DIGIT = /^[0-9]$/;
const HEX = /^[0-9A-Fa-f]$/;

function isLetter(c: string): boolean { return ASCII_LETTER.test(c); }
function isDigit(c: string): boolean { return ASCII_DIGIT.test(c); }
function isHex(c: string): boolean { return HEX.test(c); }

function clonePos(p: SourcePosition): SourcePosition {
  return { byte: p.byte, line: p.line, column: p.column };
}

export interface LexResult {
  tokens: Token[];
  trivia: Trivia[];
  diagnostics: Diagnostic[];
}

export class Lexer {
  private readonly c: SourceCursor;
  private readonly tokens: Token[] = [];
  private readonly trivia: Trivia[] = [];
  private readonly diagnostics: Diagnostic[] = [];

  constructor(input: Uint8Array | string) {
    this.c = new SourceCursor(input);
  }

  lex(): LexResult {
    // UTF-8 BOM at beginning is accepted and ignored as source trivia.
    if (this.c.peekByte(0) === 0xEF && this.c.peekByte(1) === 0xBB && this.c.peekByte(2) === 0xBF) {
      this.consumeBytes(3);
    }

    while (!this.c.eof) {
      this.scanTrivia();
      if (this.c.eof) break;

      const before = this.c.position();
      const beforeByte = this.c.byteIndex;
      if (this.scanComment()) continue;
      if (this.scanWhitespace()) continue;
      if (this.scanBoolean()) continue;
      if (this.scanPrefixedQuoted()) continue;
      if (this.scanNumber()) continue;
      if (this.scanPercent()) continue;
      if (this.scanColor()) continue;
      if (this.scanText()) continue;
      if (this.scanValueRef()) continue;
      if (this.scanOperatorOrPunctuation()) continue;
      if (this.scanWord()) continue;

      if (!this.c.eof) this.c.advanceCodePoint();
      this.errorSpan("LEX-001", "Invalid or unsupported character.", before, this.c.position());
      this.tokens.push({
        kind: "ERROR",
        raw: this.c.sliceBytes(beforeByte, this.c.byteIndex),
        start: before,
        end: clonePos(this.c.position())
      });
    }

    const p = this.c.position();
    this.tokens.push({ kind: "EOF", raw: "", start: clonePos(p), end: clonePos(p) });
    return { tokens: this.tokens, trivia: this.trivia, diagnostics: this.diagnostics };
  }

  private scanTrivia(): void {
    // Trivia scanner is intentionally separate from syntax scanner.
    while (!this.c.eof) {
      if (this.scanComment()) continue;
      if (this.scanWhitespace()) continue;
      break;
    }
  }

  private scanWhitespace(): boolean {
    const first = this.c.peekChar();
    if (first !== " " && first !== "\t" && first !== "\r" && first !== "\n") return false;
    const start = this.c.position();
    const byteStart = this.c.byteIndex;
    while (!this.c.eof) {
      const ch = this.c.peekChar();
      if (ch === " " || ch === "\t") this.c.advanceCodePoint();
      else if (ch === "\r" || ch === "\n") this.c.consumeNewline();
      else break;
    }
    this.trivia.push({
      kind: "WHITESPACE",
      raw: this.c.sliceBytes(byteStart, this.c.byteIndex),
      start,
      end: clonePos(this.c.position())
    });
    return true;
  }

  private scanComment(): boolean {
    if (this.c.peekChar() !== "@") return false;
    const start = this.c.position();
    const byteStart = this.c.byteIndex;
    this.c.advanceCodePoint();
    let value = "";
    while (!this.c.eof) {
      if (this.c.peekChar() === "/" && this.c.peekChar(1) === "@") {
        this.c.advanceCodePoint(); this.c.advanceCodePoint();
        this.trivia.push({ kind: "COMMENT", raw: this.c.sliceBytes(byteStart, this.c.byteIndex),
          value, start, end: clonePos(this.c.position()) });
        return true;
      }
      if (this.c.peekChar() === "_" && this.c.peekChar(1) === "@") {
        this.c.advanceCodePoint(); this.c.advanceCodePoint(); value += "@"; continue;
      }
      if (this.c.peekChar() === "_" && this.c.peekChar(1) === "/") {
        this.c.advanceCodePoint(); this.c.advanceCodePoint(); value += "/"; continue;
      }
      if (this.c.peekChar() === "_" && this.c.peekChar(1) === "_") {
        this.c.advanceCodePoint(); this.c.advanceCodePoint(); value += "_"; continue;
      }
      value += this.c.advanceCodePoint();
    }
    this.errorSpan("LEX-007", "Unterminated comment.", start, this.c.position());
    this.tokens.push({ kind: "ERROR", raw: this.c.sliceBytes(byteStart, this.c.byteIndex),
      value, start, end: clonePos(this.c.position()) });
    return true;
  }

  private scanBoolean(): boolean {
    const s = this.c.sourceText.slice(this.codePointIndex(), this.codePointIndex() + 9);
    if (!s.startsWith("!")) return false;
    if (s.startsWith("!true") && !this.isWordChar(s[5] ?? "")) {
      return this.emitSimple("BOOL", 5, "true");
    }
    if (s.startsWith("!false") && !this.isWordChar(s[6] ?? "")) {
      return this.emitSimple("BOOL", 6, "false");
    }
    const start = this.c.position();
    const b = this.c.byteIndex;
    if (s.startsWith("!")) {
      this.c.advanceCodePoint(); // !
      while (!this.c.eof && this.isWordChar(this.c.peekChar())) this.c.advanceCodePoint();
      this.error("LEX-003", "Invalid Boolean literal.", b, this.c.byteIndex);
      this.tokens.push({ kind: "ERROR", raw: this.c.sliceBytes(b, this.c.byteIndex),
        start, end: clonePos(this.c.position()) });
      return true;
    }
    return false;
  }

  private scanPrefixedQuoted(): boolean {
    for (const [prefix, kind] of [["id", "ID_LIT"], ["type", "TYPE_LIT"], ["path", "PATH_LIT"]] as const) {
      if (this.c.sourceText.slice(this.codePointIndex(), this.codePointIndex() + prefix.length + 1) !== prefix + '"') continue;
      const start = this.c.position(), b = this.c.byteIndex;
      for (let i=0;i<prefix.length;i++) this.c.advanceCodePoint();
      const decoded = this.scanQuotedContent(start, b);
      if (decoded === null) return true;
      this.tokens.push({ kind, raw: this.c.sliceBytes(b, this.c.byteIndex), value: decoded,
        start, end: clonePos(this.c.position()) });
      return true;
    }
    return false;
  }

  private scanQuotedContent(start: SourcePosition, byteStart: number): string | null {
    if (this.c.peekChar() !== '"') return null;
    this.c.advanceCodePoint();
    let value = "";
    while (!this.c.eof) {
      const ch = this.c.peekChar();
      if (ch === '"') {
        this.c.advanceCodePoint();
        return value;
      }
      if (ch === "_") {
        const n = this.c.peekChar(1);
        if (n === '"' || n === "_") {
          this.c.advanceCodePoint(); this.c.advanceCodePoint(); value += n; continue;
        }
        const s = this.c.position(); this.c.advanceCodePoint();
        this.errorSpan("LEX-004", "Invalid escape sequence.", s, this.c.position());
        this.tokens.push({ kind: "ERROR", raw: this.c.sliceBytes(byteStart, this.c.byteIndex),
          start, end: clonePos(this.c.position()) });
        return null;
      }
      value += this.c.advanceCodePoint();
    }
    this.errorSpan("LEX-005", "Unterminated quoted literal.", start, this.c.position());
    this.tokens.push({ kind: "ERROR", raw: this.c.sliceBytes(byteStart, this.c.byteIndex),
      start, end: clonePos(this.c.position()) });
    return null;
  }

  private scanNumber(): boolean {
    const ch = this.c.peekChar();
    if (ch !== "#") return false;
    const start = this.c.position(), b = this.c.byteIndex;
    let raw = "#";
    this.c.advanceCodePoint();
    if (this.c.peekChar() === "+") {
      this.c.advanceCodePoint();
      return this.invalidNumber(start, b, "LEX-002");
    }
    if (this.c.peekChar() === "-") { raw += "-"; this.c.advanceCodePoint(); }
    if (!isDigit(this.c.peekChar())) return this.invalidNumber(start, b, "LEX-002");
    if (this.c.peekChar() === "0") this.c.advanceCodePoint();
    else { while (isDigit(this.c.peekChar())) this.c.advanceCodePoint(); }
    if (this.c.peekChar() === ".") {
      this.c.advanceCodePoint();
      if (!isDigit(this.c.peekChar())) return this.invalidNumber(start, b, "LEX-002");
      while (isDigit(this.c.peekChar())) this.c.advanceCodePoint();
    }
    const rawNum = this.c.sliceBytes(b, this.c.byteIndex);
    this.tokens.push({ kind: "NUMBER", raw: rawNum, value: rawNum.slice(1),
      start, end: clonePos(this.c.position()) });
    // Immediate alphabetic suffix is a UNIT token, not a WORD.
    if (isLetter(this.c.peekChar())) {
      const us = this.c.position(), ub = this.c.byteIndex;
      this.c.advanceCodePoint();
      while (isLetter(this.c.peekChar())) this.c.advanceCodePoint();
      const uraw = this.c.sliceBytes(ub, this.c.byteIndex);
      this.tokens.push({ kind: "UNIT", raw: uraw, value: uraw, start: us, end: clonePos(this.c.position()) });
    }
    return true;
  }

  private invalidNumber(start: SourcePosition, b: number, code: LexDiagnosticCode): boolean {
    while (!this.c.eof) {
      const ch = this.c.peekChar();
      if (isLetter(ch) || isDigit(ch) || ch === "." || ch === "+" || ch === "-" || ch === "_") this.c.advanceCodePoint();
      else break;
    }
    this.error(code, "Invalid numeric literal.", b, this.c.byteIndex);
    this.tokens.push({ kind: "ERROR", raw: this.c.sliceBytes(b, this.c.byteIndex),
      start, end: clonePos(this.c.position()) });
    return true;
  }

  private scanPercent(): boolean {
    if (this.c.peekChar() !== "%") return false;
    const start = this.c.position(), b = this.c.byteIndex;
    this.c.advanceCodePoint();
    if (!isDigit(this.c.peekChar())) {
      this.error("LEX-008", "Invalid percent literal boundary.", b, this.c.byteIndex);
      this.tokens.push({ kind: "ERROR", raw: this.c.sliceBytes(b, this.c.byteIndex), start, end: clonePos(this.c.position()) });
      return true;
    }
    while (isDigit(this.c.peekChar())) this.c.advanceCodePoint();
    if (this.c.peekChar() === ".") {
      this.c.advanceCodePoint();
      if (!isDigit(this.c.peekChar())) {
        return this.invalidBoundaryAfter(start, b);
      }
      while (isDigit(this.c.peekChar())) this.c.advanceCodePoint();
    }
    this.tokens.push({ kind: "PERCENT", raw: this.c.sliceBytes(b, this.c.byteIndex),
      value: this.c.sliceBytes(b, this.c.byteIndex).slice(1), start, end: clonePos(this.c.position()) });
    return true;
  }

  private scanColor(): boolean {
    if (this.c.peekChar() !== "$" || this.c.peekChar(1) !== "$") return false;
    const start = this.c.position(), b = this.c.byteIndex;
    this.c.advanceCodePoint(); this.c.advanceCodePoint();
    let n = 0;
    while (isHex(this.c.peekChar()) && n < 8) { this.c.advanceCodePoint(); n++; }
    const next = this.c.peekChar();
    if ((n !== 6 && n !== 8) || isHex(next)) {
      while (isHex(this.c.peekChar())) this.c.advanceCodePoint();
      this.error("LEX-008", "Invalid color literal boundary.", b, this.c.byteIndex);
      this.tokens.push({ kind: "ERROR", raw: this.c.sliceBytes(b, this.c.byteIndex), start, end: clonePos(this.c.position()) });
      return true;
    }
    this.tokens.push({ kind: "COLOR", raw: this.c.sliceBytes(b, this.c.byteIndex),
      value: this.c.sliceBytes(b + 2, this.c.byteIndex), start, end: clonePos(this.c.position()) });
    return true;
  }

  private scanText(): boolean {
    if (this.c.peekChar() !== ".") return false;
    const start = this.c.position(), b = this.c.byteIndex;
    this.c.advanceCodePoint();
    let value = "";
    while (!this.c.eof) {
      if (this.c.peekChar() === "/" && this.c.peekChar(1) === ".") {
        this.c.advanceCodePoint(); this.c.advanceCodePoint();
        this.tokens.push({ kind: "TEXT", raw: this.c.sliceBytes(b, this.c.byteIndex), value,
          start, end: clonePos(this.c.position()) });
        return true;
      }
      if (this.c.peekChar() === "_") {
        const n = this.c.peekChar(1);
        if (n === "." || n === "/" || n === "[" || n === "_") {
          this.c.advanceCodePoint(); this.c.advanceCodePoint(); value += n; continue;
        }
        const s = this.c.position(); this.c.advanceCodePoint();
        this.errorSpan("LEX-004", "Invalid escape sequence.", s, this.c.position());
        this.tokens.push({ kind: "ERROR", raw: this.c.sliceBytes(b, this.c.byteIndex), start, end: clonePos(this.c.position()) });
        return true;
      }
      value += this.c.advanceCodePoint();
    }
    this.errorSpan("LEX-006", "Unterminated text literal.", start, this.c.position());
    this.tokens.push({ kind: "ERROR", raw: this.c.sliceBytes(b, this.c.byteIndex), value, start, end: clonePos(this.c.position()) });
    return true;
  }

  private scanValueRef(): boolean {
    if (this.c.peekChar() !== "[") return false;
    const start = this.c.position(), b = this.c.byteIndex;
    this.c.advanceCodePoint();
    const nameStart = this.c.byteIndex;
    if (!isLetter(this.c.peekChar())) return this.invalidValueRef(start, b);
    this.c.advanceCodePoint();
    while (this.isValueNameChar(this.c.peekChar())) this.c.advanceCodePoint();
    if (this.c.peekChar() !== "]") return this.invalidValueRef(start, b);
    this.c.advanceCodePoint();
    const raw = this.c.sliceBytes(b, this.c.byteIndex);
    this.tokens.push({ kind: "VALUE_REF", raw, value: raw.slice(1, -1),
      start, end: clonePos(this.c.position()) });
    return true;
  }

  private invalidValueRef(start: SourcePosition, b: number): boolean {
    while (!this.c.eof && !"] \t\r\n{}()".includes(this.c.peekChar())) this.c.advanceCodePoint();
    if (this.c.peekChar() === "]") this.c.advanceCodePoint();
    this.error("LEX-008", "Invalid value-reference boundary.", b, this.c.byteIndex);
    this.tokens.push({ kind: "ERROR", raw: this.c.sliceBytes(b, this.c.byteIndex), start, end: clonePos(this.c.position()) });
    return true;
  }

  private scanOperatorOrPunctuation(): boolean {
    const ch = this.c.peekChar(), n = this.c.peekChar(1);
    const two = ch + n;
    const compound = new Set(["+=", "-=", "*=", "/=", "<=", ">="]);
    if (compound.has(two)) {
      const start=this.c.position(), b=this.c.byteIndex;
      this.c.advanceCodePoint(); this.c.advanceCodePoint();
      this.tokens.push({kind:"OP", raw:two, value:two, start, end:clonePos(this.c.position())});
      return true;
    }
    if ("+-*/=<>".includes(ch)) {
      const start=this.c.position(), b=this.c.byteIndex;
      this.c.advanceCodePoint();
      this.tokens.push({kind:"OP", raw:ch, value:ch, start, end:clonePos(this.c.position())});
      return true;
    }
    if ("(){}".includes(ch)) {
      const start=this.c.position();
      this.c.advanceCodePoint();
      this.tokens.push({kind:"PUNCT", raw:ch, value:ch, start, end:clonePos(this.c.position())});
      return true;
    }
    return false;
  }

  private scanWord(): boolean {
    if (!isLetter(this.c.peekChar())) return false;
    const start=this.c.position(), b=this.c.byteIndex;
    this.c.advanceCodePoint();
    while (this.isWordChar(this.c.peekChar())) this.c.advanceCodePoint();
    const raw=this.c.sliceBytes(b,this.c.byteIndex);
    // Generic WORD; if immediately after a NUMBER, NUMBER scanner will separately
    // emit UNIT on a subsequent pass only if this method is reached after NUMBER.
    this.tokens.push({kind:"WORD", raw, value:raw, start, end:clonePos(this.c.position())});
    return true;
  }

  private isWordChar(c: string): boolean { return isLetter(c) || isDigit(c) || c === "_"; }
  private isValueNameChar(c: string): boolean { return isLetter(c) || isDigit(c) || c === "_" || c === "." || c === "-"; }

  private codePointIndex(): number {
    let b=0, i=0;
    while (b < this.c.byteIndex) {
      const cp=this.c.sourceText.codePointAt(i)!;
      b += new TextEncoder().encode(String.fromCodePoint(cp)).length;
      i += cp > 0xFFFF ? 2 : 1;
    }
    return i;
  }

  private emitSimple(kind: TokenKind, cpCount: number, value: string): boolean {
    const start=this.c.position(), b=this.c.byteIndex;
    for(let i=0;i<cpCount;i++) this.c.advanceCodePoint();
    this.tokens.push({kind, raw:this.c.sliceBytes(b,this.c.byteIndex), value, start, end:clonePos(this.c.position())});
    return true;
  }

  private invalidBoundaryAfter(start: SourcePosition, b: number): boolean {
    this.error("LEX-008","Invalid lexical boundary.",b,this.c.byteIndex);
    this.tokens.push({kind:"ERROR",raw:this.c.sliceBytes(b,this.c.byteIndex),start,end:clonePos(this.c.position())});
    return true;
  }

  private consumeBytes(n: number): void {
    for (let i=0;i<n;i++) {
      // BOM bytes are consumed without changing line/column.
      (this.c as any).index += 1;
    }
  }

  private error(code: LexDiagnosticCode, message: string, b: number, end: number): void {
    const start = this.positionAtByte(b);
    const finish = this.positionAtByte(end);
    this.diagnostics.push({code, severity:"error", message, start, end:finish});
  }

  private errorSpan(code: LexDiagnosticCode, message: string, start: SourcePosition, end: SourcePosition): void {
    this.diagnostics.push({code, severity:"error", message, start, end:clonePos(end)});
  }

  private positionAtByte(byte: number): SourcePosition {
    const bytes = this.c.bytes;
    let i=0, b=0, line=0, col=0;
    while (b<byte) {
      const cp = this.c.sourceText.codePointAt(i)!;
      const ch = String.fromCodePoint(cp);
      const n = new TextEncoder().encode(ch).length;
      if (ch === "\r") {
        b += n;
        if (b < byte && this.c.sourceText.codePointAt(i + 1) === 10) {
          const nl = "\n"; b += 1; i += 1;
        }
        line++; col=0; i += cp>0xFFFF?2:1;
      } else if (ch === "\n") {
        b += n; line++; col=0; i += cp>0xFFFF?2:1;
      } else {
        b += n; col++; i += cp>0xFFFF?2:1;
      }
    }
    return {byte, line, column:col};
  }
}
