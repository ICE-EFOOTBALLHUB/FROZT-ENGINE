
import { Lexer } from "./lexer";
import { readFileSync } from "node:fs";

const file = process.argv[2];
if (!file) {
  console.error("Usage: npm run lex -- <file>");
  process.exit(2);
}
const bytes = new Uint8Array(readFileSync(file));
const result = new Lexer(bytes).lex();
console.log(JSON.stringify(result, null, 2));
