
import { SourcePosition } from "./token";

export type LexDiagnosticCode =
  | "LEX-001" | "LEX-002" | "LEX-003" | "LEX-004"
  | "LEX-005" | "LEX-006" | "LEX-007" | "LEX-008";

export interface Diagnostic {
  code: LexDiagnosticCode;
  severity: "error";
  message: string;
  start: SourcePosition;
  end: SourcePosition;
}
