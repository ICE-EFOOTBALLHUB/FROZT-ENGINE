
export type TokenKind =
  | "WORD" | "NUMBER" | "UNIT" | "PERCENT" | "COLOR" | "BOOL"
  | "ID_LIT" | "TYPE_LIT" | "PATH_LIT" | "TEXT" | "VALUE_REF"
  | "OP" | "PUNCT" | "ERROR" | "EOF";

export interface SourcePosition {
  byte: number;
  line: number;
  column: number; // Unicode code-point column, zero-based.
}

export interface Token {
  kind: TokenKind;
  raw: string;
  value?: unknown;
  start: SourcePosition;
  end: SourcePosition;
}

export type TriviaKind = "WHITESPACE" | "COMMENT";

export interface Trivia {
  kind: TriviaKind;
  raw: string;
  value?: string;
  start: SourcePosition;
  end: SourcePosition;
}
