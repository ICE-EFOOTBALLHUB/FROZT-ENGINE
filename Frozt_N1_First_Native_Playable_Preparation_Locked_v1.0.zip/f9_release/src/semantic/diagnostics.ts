export interface SemanticDiagnosticSpec {
  code: string;
  meaning: string;
  severity: "error";
}

export const SEMANTIC_DIAGNOSTICS: readonly SemanticDiagnosticSpec[] = [
  { code:"SEM-001", meaning:"duplicate declaration within one semantic namespace", severity:"error" },
  { code:"SEM-002", meaning:"unresolved required semantic reference", severity:"error" },
  { code:"SEM-003", meaning:"invalid fetch reference cardinality", severity:"error" },
  { code:"SEM-004", meaning:"invalid mutation target", severity:"error" },
  { code:"SEM-005", meaning:"incompatible arithmetic or mutation operands", severity:"error" },
  { code:"SEM-006", meaning:"incomparable operands", severity:"error" },
  { code:"SEM-007", meaning:"invalid boolean operand", severity:"error" },
  { code:"SEM-008", meaning:"ambiguous event value reference", severity:"error" }
];
