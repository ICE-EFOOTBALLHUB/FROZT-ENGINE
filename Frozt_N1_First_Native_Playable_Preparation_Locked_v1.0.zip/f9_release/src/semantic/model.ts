import { SourcePosition } from "../lexer/token";
import * as A from "../parser/ast";

export interface SemanticSpan { start: SourcePosition; end: SourcePosition; }
export type SymbolKind = "object" | "media" | "timer" | "action" | "module" | "value";
export type ValueType = "number" | "boolean" | "text" | "duration" | "percentage" | "distance" | "position" | "boundary" | "object_reference" | "media_resource_reference" | "unset" | "unknown";
export interface Symbol { kind: SymbolKind; name: string; span: SemanticSpan; node: A.Node; valueType?: ValueType; }
export interface SymbolTable { objects: Map<string, Symbol>; media: Map<string, Symbol>; timers: Map<string, Symbol>; actions: Map<string, Symbol>; modules: Map<string, Symbol>; values: Map<string, Symbol[]>; }
export interface SemanticDiagnostic { code: string; severity: "error" | "warning" | "info"; message: string; start: SourcePosition; end: SourcePosition; }
export interface SemanticResult { model: SemanticModel; diagnostics: SemanticDiagnostic[]; }
export interface EventBindingSpec {
  node: A.CommandNode;
  conditionNodes: A.Statement[];
  responseNodes: A.Statement[];
  triggerReferences: A.ReferenceExpr[];
  singlefireEpisodePolicy: "per-satisfying-binding";
}
export interface SemanticModel {
  symbols: SymbolTable;
  resolvedReferences: Map<A.ReferenceExpr, Symbol>;
  valueTypes: Map<A.ValueRefExpr, ValueType>;
  valueOwners: Map<A.ValueRefExpr, string | undefined>;
  eventBindings: Map<A.CommandNode, EventBindingSpec>;
  mutationOrder: Map<A.MutationExpr, number>;
  numericPolicy: { representation: "IEEE-754-binary64"; trigonometry: "not-in-first-release" };
}
