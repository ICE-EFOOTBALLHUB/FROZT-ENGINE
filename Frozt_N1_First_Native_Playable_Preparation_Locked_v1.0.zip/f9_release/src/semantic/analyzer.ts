import * as A from "../parser/ast";
import { ParserDiagnostic } from "../parser/diagnostic";
import { SemanticDiagnostic, SemanticModel, SemanticResult, Symbol, SymbolTable, ValueType } from "./model";

interface AnalysisContext {
  ownerKind?: "object" | "action";
  ownerName?: string;
  triggerContext?: boolean;
}

export class SemanticAnalyzer {
  private diagnostics: SemanticDiagnostic[] = [];
  private symbols: SymbolTable = { objects:new Map(), media:new Map(), timers:new Map(), actions:new Map(), modules:new Map(), values:new Map() };
  private resolvedReferences = new Map<A.ReferenceExpr, Symbol>();
  private valueTypes = new Map<A.ValueRefExpr, ValueType>();
  private valueOwners = new Map<A.ValueRefExpr, string | undefined>();
  private eventBindings = new Map<A.CommandNode, import("./model").EventBindingSpec>();
  private mutationOrder = new Map<A.MutationExpr, number>();
  private mutationCounter = 0;

  analyze(ast: A.Program, parserDiagnostics: ParserDiagnostic[] = []): SemanticResult {
    this.diagnostics = [];
    this.symbols = { objects:new Map(), media:new Map(), timers:new Map(), actions:new Map(), modules:new Map(), values:new Map() };
    this.resolvedReferences = new Map();
    this.valueTypes = new Map();
    this.valueOwners = new Map();
    this.eventBindings = new Map();
    this.mutationOrder = new Map();
    this.mutationCounter = 0;

    for (const d of parserDiagnostics) {
      this.diagnostics.push({ code:d.code, severity:d.severity, message:d.message, start:d.start, end:d.end });
    }

    // Declaration collection is intentionally separated from validation. The implementation
    // can resolve a forward declaration, but that behavior remains provisional until the
    // forward-reference rule is formally locked by the F3 decision record.
    this.collect(ast.body);
    this.checkStatements(ast.body, {});

    this.diagnostics.sort((a,b)=>a.start.byte-b.start.byte || a.end.byte-b.end.byte || a.code.localeCompare(b.code));
    return {
      model:{symbols:this.symbols,resolvedReferences:this.resolvedReferences,valueTypes:this.valueTypes,valueOwners:this.valueOwners,eventBindings:this.eventBindings,mutationOrder:this.mutationOrder,numericPolicy:{representation:"IEEE-754-binary64",trigonometry:"not-in-first-release"}},
      diagnostics:this.diagnostics
    };
  }

  private collect(stmts:A.Statement[]) {
    for (const s of stmts) {
      if (s.kind === "Command") {
        if (s.name === "add") this.declareFromCommand(s, "object");
        else if (s.name === "action") this.declareFromCommand(s, "action");
        else if (s.name === "fetch") this.declareFetch(s);
        this.collect(s.body?.body ?? []);
      } else if (s.kind === "BlockStatement") this.collect(s.body);
    }
  }

  private declareFromCommand(c:A.CommandNode, kind:"object"|"action") {
    const r = c.args.find(x=>x.kind === "ReferenceExpr" && x.referenceKind === "id") as A.ReferenceExpr|undefined
      ?? this.firstIdInBlock(c.body);
    if (!r) return;
    const table = kind === "object" ? this.symbols.objects : this.symbols.actions;
    const key = this.key(r.value);
    if (table.has(key)) {
      this.diag("SEM-001", `Duplicate ${kind} declaration: ${r.value}.`, r);
      return;
    }
    table.set(key, {kind,name:r.value,span:r.span,node:r});
  }

  private firstIdInBlock(block?:A.Block): A.ReferenceExpr|undefined {
    if (!block) return undefined;
    for (const s of block.body) {
      if (s.kind === "ExpressionStatement" && s.expression.kind === "ReferenceExpr" && s.expression.referenceKind === "id") return s.expression;
      if (s.kind === "Command") {
        const r = s.args.find(x=>x.kind === "ReferenceExpr" && x.referenceKind === "id") as A.ReferenceExpr|undefined;
        if (r) return r;
      }
    }
    return undefined;
  }

  private declareFetch(c:A.CommandNode) {
    const id = c.args.find(x=>x.kind === "ReferenceExpr" && x.referenceKind === "id") as A.ReferenceExpr|undefined;
    if (!id) return;
    const key = this.key(id.value);
    if (this.symbols.media.has(key)) {
      this.diag("SEM-001", `Duplicate media declaration: ${id.value}.`, id);
      return;
    }
    this.symbols.media.set(key,{kind:"media",name:id.value,span:id.span,node:id});
  }

  private checkStatements(stmts:A.Statement[], context:AnalysisContext) {
    for (const s of stmts) {
      if (s.kind === "Command") this.checkCommand(s, context);
      else if (s.kind === "BlockStatement") this.checkStatements(s.body, context);
      else if (s.kind === "ExpressionStatement") this.checkExpression(s.expression, context);
    }
  }

  private checkCommand(c:A.CommandNode, context:AnalysisContext) {
    if (c.name === "do") this.checkDo(c);
    if (c.name === "event") this.checkEvent(c, context);
    if (c.name === "spawn") this.checkSpawn(c);
    if (c.name === "set" || c.name === "mod") this.checkMutationCommand(c, context);
    if (c.name === "fetch") this.checkFetch(c);

    for (const a of c.args) this.checkExpression(a, context);

    let childContext = context;
    if (c.name === "add") {
      const r = this.firstIdInBlock(c.body);
      childContext = r ? {ownerKind:"object", ownerName:r.value} : context;
    } else if (c.name === "action") {
      const r = this.firstIdInBlock(c.body);
      childContext = r ? {ownerKind:"action", ownerName:r.value} : context;
    } else if (c.name === "event") {
      childContext = {...context, triggerContext:true};
    } else if (c.name === "spawn") {
      const r = c.args.find(x=>x.kind === "ReferenceExpr" && x.referenceKind === "id") as A.ReferenceExpr|undefined;
      childContext = r ? {ownerKind:"object", ownerName:r.value} : context;
    }

    if (c.body) this.checkStatements(c.body.body, childContext);
  }


  private checkEvent(c:A.CommandNode, context:AnalysisContext) {
    const body = c.body?.body ?? [];
    const thenIndex = body.findIndex(s => s.kind === "Command" && s.name === "then");
    const conditionNodes = thenIndex < 0 ? body : body.slice(0, thenIndex);
    const responseNodes = thenIndex < 0 ? [] : body.slice(thenIndex + 1);
    const triggerReferences:A.ReferenceExpr[] = [];

    for (const s of conditionNodes) {
      if (s.kind === "ExpressionStatement") this.collectIdReferences(s.expression, triggerReferences);
      if (s.kind === "Command") for (const a of s.args) this.collectIdReferences(a, triggerReferences);
    }

    const conditionValueRefs:A.ValueRefExpr[] = [];
    for (const s of conditionNodes) {
      this.collectValueRefs(s, conditionValueRefs);
    }

    // The baseline makes ambiguity an analyzer diagnostic. A value reference in an event
    // condition is therefore not silently assigned to an arbitrary object when no explicit
    // target or trigger owner can be established.
    if (conditionValueRefs.length && triggerReferences.length === 0 && !context.ownerName) {
      for (const v of conditionValueRefs) {
        this.diag("SEM-008", `Ambiguous event value reference: [${v.name}].`, v);
      }
    }

    this.eventBindings.set(c, {
      node:c, conditionNodes, responseNodes, triggerReferences,
      singlefireEpisodePolicy:"per-satisfying-binding"
    });
  }

  private collectIdReferences(e:A.Expression, out:A.ReferenceExpr[]) {
    switch(e.kind) {
      case "ReferenceExpr": if(e.referenceKind === "id") out.push(e); break;
      case "BinaryExpr": this.collectIdReferences(e.left,out); this.collectIdReferences(e.right,out); break;
      case "UnaryExpr": this.collectIdReferences(e.operand,out); break;
      case "GroupedExpr": this.collectIdReferences(e.expression,out); break;
      case "MutationExpr": this.collectIdReferences(e.left,out); this.collectIdReferences(e.right,out); break;
    }
  }

  private collectValueRefs(s:A.Statement, out:A.ValueRefExpr[]) {
    if(s.kind === "ExpressionStatement") this.collectValueRefsExpr(s.expression,out);
    else if(s.kind === "Command") {
      for(const a of s.args) this.collectValueRefsExpr(a,out);
      for(const child of s.body?.body ?? []) this.collectValueRefs(child,out);
    }
  }

  private collectValueRefsExpr(e:A.Expression,out:A.ValueRefExpr[]) {
    switch(e.kind) {
      case "ValueRefExpr": out.push(e); break;
      case "BinaryExpr": this.collectValueRefsExpr(e.left,out); this.collectValueRefsExpr(e.right,out); break;
      case "UnaryExpr": this.collectValueRefsExpr(e.operand,out); break;
      case "GroupedExpr": this.collectValueRefsExpr(e.expression,out); break;
      case "MutationExpr": this.collectValueRefsExpr(e.left,out); this.collectValueRefsExpr(e.right,out); break;
    }
  }

  private checkDo(c:A.CommandNode) {
    for (const a of c.args) if (a.kind === "ReferenceExpr" && a.referenceKind === "id") this.resolveAction(a);
    if (c.body) {
      for (const s of c.body.body) {
        if (s.kind === "ExpressionStatement" && s.expression.kind === "ReferenceExpr" && s.expression.referenceKind === "id") this.resolveAction(s.expression);
      }
    }
  }

  private resolveAction(r:A.ReferenceExpr) {
    const s=this.symbols.actions.get(this.key(r.value));
    if (!s) { this.diag("SEM-002", `Undefined action reference: ${r.value}.`, r); return; }
    this.resolvedReferences.set(r,s);
  }

  private checkSpawn(c:A.CommandNode) {
    for (const a of c.args) if (a.kind === "ReferenceExpr" && a.referenceKind === "id") {
      const s=this.symbols.objects.get(this.key(a.value));
      if (!s) this.diag("SEM-002", `Undefined object type reference: ${a.value}.`, a);
      else this.resolvedReferences.set(a,s);
    }
  }

  private checkFetch(c:A.CommandNode) {
    const paths=c.args.filter(x=>x.kind === "ReferenceExpr" && x.referenceKind === "path");
    if (paths.length>1) this.diag("SEM-003", "fetch accepts at most one path reference.", paths[1]);
    const ids=c.args.filter(x=>x.kind === "ReferenceExpr" && x.referenceKind === "id");
    if (ids.length>1) this.diag("SEM-003", "fetch accepts at most one id reference.", ids[1]);
  }

  private checkMutationCommand(c:A.CommandNode, context:AnalysisContext) {
    const m=c.args[0];
    if (m?.kind !== "MutationExpr") return;
    this.mutationOrder.set(m, this.mutationCounter++);
    if (m.left.kind !== "ValueRefExpr") {
      this.diag("SEM-004", `${c.name} mutation target must be a value reference.`, m.left);
    } else {
      const rightType = this.checkExpression(m.right, context);
      this.registerValue(m.left, rightType, context);
      this.checkAssignmentCompatibility(m.operator, rightType, m.left, c.name);
    }
    this.checkExpression(m.left, context);
    this.checkExpression(m.right, context);
  }

  private registerValue(v:A.ValueRefExpr, t:ValueType, context:AnalysisContext) {
    const key=this.key(v.name);
    const refs=this.symbols.values.get(key) ?? [];
    refs.push({kind:"value",name:v.name,span:v.span,node:v,valueType:t});
    this.symbols.values.set(key,refs);
    this.valueTypes.set(v,t);
    this.valueOwners.set(v, context.ownerName);
  }

  private checkExpression(e:A.Expression, context:AnalysisContext={}):ValueType {
    switch(e.kind) {
      case "LiteralExpr": return this.literalType(e.tokenKind, e.value);
      case "ValueRefExpr": {
        // A value reference has no statically knowable runtime type unless it has been
        // established by a semantic declaration in the same analysis context.
        if (!this.valueTypes.has(e)) this.valueTypes.set(e,"unknown");
        this.valueOwners.set(e, context.ownerName);
        return this.valueTypes.get(e) ?? "unknown";
      }
      case "ReferenceExpr": return e.referenceKind === "id" ? "object_reference" : "media_resource_reference";
      case "GroupedExpr": return this.checkExpression(e.expression, context);
      case "ErrorExpr": return "unknown";
      case "UnaryExpr": {
        const t=this.checkExpression(e.operand, context);
        if(t!=="boolean" && t!=="unknown") this.diag("SEM-007", "not requires a boolean-compatible operand.", e.operand);
        return "boolean";
      }
      case "MutationExpr": {
        const l=this.checkExpression(e.left, context), r=this.checkExpression(e.right, context);
        if(e.operator!=="=" && !this.compatibleForArithmetic(e.operator,l,r) && l!=="unknown" && r!=="unknown")
          this.diag("SEM-005", `Operator ${e.operator} requires compatible numeric operands.`, e);
        return r;
      }
      case "BinaryExpr": return this.binaryType(e, context);
    }
  }

  private binaryType(e:A.BinaryExpr, context:AnalysisContext):ValueType {
    const l=this.checkExpression(e.left, context), r=this.checkExpression(e.right, context);
    if (["+","-","*","/"].includes(e.operator)) {
      if (!this.compatibleForArithmetic(e.operator,l,r) && l!=="unknown" && r!=="unknown")
        this.diag("SEM-005", `Operator ${e.operator} requires compatible numeric operands.`, e);
      return this.arithmeticResult(e.operator,l,r);
    }
    if (["=","not =","<",">","<=",">="].includes(e.operator)) {
      if (!this.comparable(l,r) && l!=="unknown" && r!=="unknown")
        this.diag("SEM-006", `Operator ${e.operator} requires comparable operands.`, e);
      return "boolean";
    }
    if (["and","nand","or","nor"].includes(e.operator)) {
      if ((l!=="boolean"||r!=="boolean") && l!=="unknown" && r!=="unknown")
        this.diag("SEM-007", `Operator ${e.operator} requires boolean-compatible operands.`, e);
      return "boolean";
    }
    return "unknown";
  }

  private checkAssignmentCompatibility(operator:string, right:ValueType, left:A.ValueRefExpr, command:string) {
    if (operator === "=") return;
    const existing = this.valueTypes.get(left);
    if (existing && existing !== "unknown" && right !== "unknown" && !this.compatibleForArithmetic(operator, existing, right))
      this.diag("SEM-005", `Operator ${operator} requires compatible numeric operands.`, left);
    if (command === "mod" && operator !== "=" && existing === "unknown" && right !== "unknown") return;
  }

  private compatibleForArithmetic(op:string,l:ValueType,r:ValueType):boolean {
    if (l === "number" && r === "number") return true;
    if (op === "*" || op === "/") {
      if (l === "number" && this.isDimensioned(r)) return true;
      if (r === "number" && this.isDimensioned(l)) return true;
    }
    if (op === "+" || op === "-") return this.sameDimension(l,r);
    return false;
  }

  private arithmeticResult(op:string,l:ValueType,r:ValueType):ValueType {
    if (op === "+" || op === "-") return this.sameDimension(l,r) ? l : "unknown";
    if ((l === "number" && this.isDimensioned(r)) || (r === "number" && this.isDimensioned(l))) return this.isDimensioned(l) ? l : r;
    return "number";
  }

  private sameDimension(l:ValueType,r:ValueType):boolean {
    return l === r && (l === "number" || this.isDimensioned(l));
  }

  private isDimensioned(t:ValueType):boolean { return t === "duration" || t === "percentage" || t === "distance"; }

  private comparable(l:ValueType,r:ValueType):boolean {
    if (l === r) return true;
    return (l === "number" && r === "number") || this.sameDimension(l,r);
  }

  private literalType(k:string, value:unknown):ValueType {
    if (k === "NUMBER") return "number";
    if (k === "PERCENT") return "percentage";
    if (k === "BOOL") return "boolean";
    if (k === "TEXT") return "text";
    if (k === "UNIT") {
      const raw=String(value ?? "").toLowerCase();
      if (raw.endsWith("fro")) return "distance";
      // Other units are intentionally not guessed here; their semantic family is a
      // later explicit decision rather than a lexer-token shortcut.
      return "unknown";
    }
    if (k === "COLOR") return "media_resource_reference";
    return "unknown";
  }

  private key(name:string){ return name.normalize("NFC").toLowerCase(); }
  private diag(code:string,message:string,n:A.Node){ this.diagnostics.push({code,severity:"error",message,start:n.span.start,end:n.span.end}); }
}

export function analyze(ast:A.Program,parserDiagnostics:ParserDiagnostic[]=[]){ return new SemanticAnalyzer().analyze(ast,parserDiagnostics); }
