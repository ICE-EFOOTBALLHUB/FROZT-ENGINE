import type { SaveValue, FroztHostApi, AudioInstanceId } from '../host/api';
import type { RenderColor, RenderModel, FaceElement } from '../host/render-model';
import { PresentationController, type PresentationEnvironment, type PresentationVariant } from '../presentation';
import { SpatialRegistry, type Vec2 } from './f5';

export interface Rect { x:number; y:number; width:number; height:number; }
export interface LayoutSpec {
  width?: number; height?: number; minWidth?: number; minHeight?: number; maxWidth?: number; maxHeight?: number;
  left?: number; right?: number; top?: number; bottom?: number;
  padding?: {left:number;top:number;right:number;bottom:number};
  visible?: boolean;
}
export interface LayoutNode { id:string; spec:LayoutSpec; children:LayoutNode[]; }
export interface ResolvedLayout { id:string; rect:Rect; visible:boolean; children:ResolvedLayout[]; }

const finite=(n:number,l:string)=>{if(!Number.isFinite(n))throw new Error(`${l} must be finite`);return n;};
const nonneg=(n:number,l:string)=>{finite(n,l);if(n<0)throw new Error(`${l} must be non-negative`);return n;};
const inset=(p= {left:0,top:0,right:0,bottom:0})=>({left:nonneg(p.left,'padding.left'),top:nonneg(p.top,'padding.top'),right:nonneg(p.right,'padding.right'),bottom:nonneg(p.bottom,'padding.bottom')});

export class LayoutEngine {
  resolve(root:LayoutNode, viewport:{width:number;height:number}, safeArea:{left:number;top:number;right:number;bottom:number}): ResolvedLayout {
    finite(viewport.width,'viewport.width'); finite(viewport.height,'viewport.height');
    const area={x:safeArea.left,y:safeArea.top,width:viewport.width-safeArea.left-safeArea.right,height:viewport.height-safeArea.top-safeArea.bottom};
    if(area.width<0||area.height<0)throw new Error('safe area exceeds viewport');
    const solve=(n:LayoutNode,parent:Rect):ResolvedLayout=>{
      const s=n.spec,p=inset(s.padding); let x=parent.x+(s.left??0), y=parent.y+(s.top??0);
      let w=s.width ?? (s.left!==undefined&&s.right!==undefined?parent.width-s.left-s.right:parent.width);
      let h=s.height ?? (s.top!==undefined&&s.bottom!==undefined?parent.height-s.top-s.bottom:parent.height);
      if(s.right!==undefined&&s.width===undefined) w=parent.width-(s.left??0)-s.right;
      if(s.bottom!==undefined&&s.height===undefined) h=parent.height-(s.top??0)-s.bottom;
      w=Math.max(s.minWidth??0,Math.min(s.maxWidth??Infinity,w)); h=Math.max(s.minHeight??0,Math.min(s.maxHeight??Infinity,h));
      if(s.right!==undefined && s.left===undefined) x=parent.x+parent.width-s.right-w;
      if(s.bottom!==undefined && s.top===undefined) y=parent.y+parent.height-s.bottom-h;
      const rect={x,y,width:Math.max(0,w),height:Math.max(0,h)};
      const content={x:x+p.left,y:y+p.top,width:Math.max(0,rect.width-p.left-p.right),height:Math.max(0,rect.height-p.top-p.bottom)};
      return {id:n.id,rect,visible:s.visible!==false,children:n.children.map(c=>solve(c,content))};
    };
    return solve(root,area);
  }
}

export type HitTestResult={id:string;z:number};
export interface InteractiveRegion { id:string; rect:Rect; z:number; enabled:boolean; action:string; }
export class InteractionRegistry {
  private regions=new Map<string,InteractiveRegion>();
  set(region:InteractiveRegion){this.regions.set(region.id,{...region,rect:{...region.rect}});}
  remove(id:string){this.regions.delete(id);}
  hit(x:number,y:number):HitTestResult|undefined {
    return [...this.regions.values()].filter(r=>r.enabled&&x>=r.rect.x&&y>=r.rect.y&&x<=r.rect.x+r.rect.width&&y<=r.rect.y+r.rect.height)
      .sort((a,b)=>b.z-a.z||a.id.localeCompare(b.id))[0] && (()=>{const r=[...this.regions.values()].filter(r=>r.enabled&&x>=r.rect.x&&y>=r.rect.y&&x<=r.rect.x+r.rect.width&&y<=r.rect.y+r.rect.height).sort((a,b)=>b.z-a.z||a.id.localeCompare(b.id))[0];return {id:r.id,z:r.z};})();
  }
  all(){return [...this.regions.values()].map(r=>({...r,rect:{...r.rect}}));}
}

export interface Trigger { id:string; rect:Rect; onEnter?:(objectId:number)=>void; onExit?:(objectId:number)=>void; }
export class TriggerSystem {
  private previous=new Map<string,Set<number>>();
  constructor(private readonly spatial:SpatialRegistry){}
  check(triggers:readonly Trigger[]):void {
    for(const t of triggers){const inside=new Set<number>();for(const o of this.spatial.all()){const p=this.spatial.worldFoot(o.id)!;if(p.x>=t.rect.x&&p.x<=t.rect.x+t.rect.width&&p.y>=t.rect.y&&p.y<=t.rect.y+t.rect.height)inside.add(o.id);}
      const old=this.previous.get(t.id)??new Set<number>(); for(const id of inside)if(!old.has(id))t.onEnter?.(id);for(const id of old)if(!inside.has(id))t.onExit?.(id);this.previous.set(t.id,inside);}
  }
}

export interface Collider { id:number; shape:'circle'|'rect'; radius?:number; width?:number; height?:number; solid:boolean; }
export class CollisionSystem {
  private colliders=new Map<number,Collider>();
  constructor(private readonly spatial:SpatialRegistry){}
  add(c:Collider){this.colliders.set(c.id,{...c});}
  remove(id:number){this.colliders.delete(id);}
  overlaps(a:Collider,b:Collider):boolean {const pa=this.spatial.worldFoot(a.id),pb=this.spatial.worldFoot(b.id);if(!pa||!pb)return false;if(a.shape==='circle'&&b.shape==='circle')return Math.hypot(pa.x-pb.x,pa.y-pb.y)<=(a.radius??0)+(b.radius??0);const rect=(c:Collider,p:Vec2)=>({x:p.x-(c.width??0)/2,y:p.y-(c.height??0)/2,w:c.width??0,h:c.height??0});if(a.shape==='rect'&&b.shape==='rect'){const A=rect(a,pa),B=rect(b,pb);return A.x<=B.x+B.w&&A.x+A.w>=B.x&&A.y<=B.y+B.h&&A.y+A.h>=B.y;}const circle=a.shape==='circle'?a:b,cr=a.shape==='circle'?pa:pb,r=a.shape==='rect'?a:b,rp=a.shape==='rect'?pa:pb;const R=rect(r,rp);const qx=Math.max(R.x,Math.min(cr.x,R.x+R.w)),qy=Math.max(R.y,Math.min(cr.y,R.y+R.h));return Math.hypot(cr.x-qx,cr.y-qy)<= (circle.radius??0);}
  pairs():Array<[number,number]>{const c=[...this.colliders.values()].filter(x=>x.solid),out:Array<[number,number]>=[];for(let i=0;i<c.length;i++)for(let j=i+1;j<c.length;j++)if(this.overlaps(c[i],c[j]))out.push([c[i].id,c[j].id]);return out;}
}

export interface AnimationClip { id:string; frames:readonly string[]; frameDuration:number; loop:boolean; }
export interface AnimationState { clip:string; frame:number; elapsed:number; playing:boolean; }
export class AnimationSystem {
  private clips=new Map<string,AnimationClip>(); private states=new Map<number,AnimationState>();
  define(c:AnimationClip){if(!c.frames.length||c.frameDuration<=0)throw new Error('invalid animation clip');this.clips.set(c.id,{...c,frames:[...c.frames]});}
  play(id:number,clip:string,reset=true){if(!this.clips.has(clip))throw new Error(`unknown animation: ${clip}`);const s=this.states.get(id);if(!s||reset||s.clip!==clip)this.states.set(id,{clip,frame:0,elapsed:0,playing:true});else s.playing=true;}
  stop(id:number){const s=this.states.get(id);if(s)s.playing=false;}
  update(dt:number){nonneg(dt,'dt');for(const s of this.states.values()){if(!s.playing)continue;const c=this.clips.get(s.clip)!;s.elapsed+=dt;while(s.elapsed>=c.frameDuration){s.elapsed-=c.frameDuration;s.frame++;if(s.frame>=c.frames.length){if(c.loop)s.frame=0;else{s.frame=c.frames.length-1;s.playing=false;break;}}}}}
  state(id:number){const s=this.states.get(id);return s?{...s}:undefined;}
  frameImage(id:number){const s=this.states.get(id),c=s&&this.clips.get(s.clip);return s&&c?c.frames[s.frame]:undefined;}
}

export interface CameraState {x:number;y:number;zoom:number;rotation:number;target?:number;followLerp:number;}
export class CameraSystem {
  state:CameraState={x:0,y:0,zoom:1,rotation:0,followLerp:1};
  constructor(private readonly spatial:SpatialRegistry){}
  set(v:Partial<CameraState>){this.state={...this.state,...v};}
  update(dt:number){if(this.state.target===undefined)return;const p=this.spatial.worldFoot(this.state.target);if(!p)return;const a=Math.max(0,Math.min(1,this.state.followLerp));this.state.x+=(p.x-this.state.x)*Math.min(1,a*dt*60);this.state.y+=(p.y-this.state.y)*Math.min(1,a*dt*60);}
}

export interface SceneTransition {id:string;from:string;to:string;duration:number;elapsed:number;phase:'running'|'complete';}
export class SceneManager {
  current:string; private transition?:SceneTransition;
  constructor(initial='main'){this.current=initial;}
  transitionTo(to:string,duration:number,id=`transition:${this.current}:${to}`){nonneg(duration,'duration');this.transition={id,from:this.current,to,duration,elapsed:0,phase:duration===0?'complete':'running'};if(duration===0)this.current=to;}
  update(dt:number){if(!this.transition||this.transition.phase==='complete')return;this.transition.elapsed+=dt;if(this.transition.elapsed>=this.transition.duration){this.current=this.transition.to;this.transition.phase='complete';}}
  get activeTransition(){return this.transition?{...this.transition}:undefined;}
}

export class AudioSystem {
  private instances=new Map<number,AudioInstanceId>(); private next=1;
  constructor(private readonly host:Pick<FroztHostApi,'playAudio'|'pauseAudio'|'stopAudio'|'setVolume'>){}
  play(assetPath:string,loop=false,volume=1){const id=this.host.playAudio({assetPath,loop,volume});const local=this.next++;this.instances.set(local,id);return local;}
  pause(id:number){const x=this.instances.get(id);if(x)this.host.pauseAudio(x);}
  stop(id:number){const x=this.instances.get(id);if(x){this.host.stopAudio(x);this.instances.delete(id);}}
  volume(id:number,v:number){const x=this.instances.get(id);if(x)this.host.setVolume(x,v);}
  stopAll(){for(const id of [...this.instances.keys()])this.stop(id);}
}

export interface SaveMigration {from:number;to:number;migrate:(values:Record<string,SaveValue>)=>Record<string,SaveValue>;}
export class VersionedSave {
  private values:Record<string,SaveValue>={};
  constructor(readonly packageId:string,readonly gameVersion:string,readonly schema=1){}
  set(k:string,v:SaveValue){if(!k||k.includes('/')||k.includes('\\'))throw new Error('invalid save key');this.values[k]=v;}
  get(k:string){return this.values[k];}
  delete(k:string){delete this.values[k];}
  export(){return {schema:this.schema,packageId:this.packageId,gameVersion:this.gameVersion,values:{...this.values}};}
  import(data:unknown,migrations:readonly SaveMigration[]=[]):boolean {if(!data||typeof data!=='object')return false;const d=data as any;if(d.packageId!==this.packageId||typeof d.schema!=='number'||!d.values||typeof d.values!=='object')return false;let values={...d.values} as Record<string,SaveValue>;let schema=d.schema;if(schema>this.schema)return false;while(schema<this.schema){const m=migrations.find(x=>x.from===schema);if(!m)return false;values=m.migrate(values);schema=m.to;}if(schema!==this.schema)return false;this.values=values;return true;}
}

export interface F8Config { variants?:readonly PresentationVariant[]; }
export class F8GameSystems {
  readonly layout=new LayoutEngine(); readonly interactions=new InteractionRegistry(); readonly spatial=new SpatialRegistry();
  readonly triggers=new TriggerSystem(this.spatial); readonly collisions=new CollisionSystem(this.spatial); readonly animations=new AnimationSystem(); readonly camera=new CameraSystem(this.spatial); readonly scenes=new SceneManager();
  readonly presentation=new PresentationController(); private variants:readonly PresentationVariant[]=[];
  constructor(variants:readonly PresentationVariant[]=[]){this.variants=variants;}
  update(dt:number,env:PresentationEnvironment){this.animations.update(dt);this.camera.update(dt);this.scenes.update(dt);this.triggers.check([]);this.presentation.update(env,this.variants);}
  applyPresentationVariants(variants:readonly PresentationVariant[]){this.variants=variants;}
}

export function faceText(id:string,text:string,r:Rect,size:number,color:RenderColor,visible=true):FaceElement{return {kind:'text',id,x:r.x,y:r.y,text,size,color,opacity:1,visible};}
