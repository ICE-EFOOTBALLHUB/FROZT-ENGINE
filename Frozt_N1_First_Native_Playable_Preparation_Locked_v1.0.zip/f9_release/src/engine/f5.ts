import type { FroztHostApi, InputEvent, PackageBytes } from "../host/api";
import type { RenderColor, RenderModel, RenderSprite, RenderWorldLayer, FaceElement } from "../host/render-model";
import { SeededRandom } from "../runtime/runtime";

export interface Vec2 { x: number; y: number; }
export interface FootAnchor { x: number; y: number; }
export interface SpatialObject { id: number; type: string; position: Vec2; foot: FootAnchor; layer: string; radius?: number; alive: boolean; }

export interface RectBoundary { kind: "rect"; x: number; y: number; width: number; height: number; }
export interface CircleBoundary { kind: "circle"; x: number; y: number; radius: number; }
export type Boundary = RectBoundary | CircleBoundary;

export type LayerKind = "world" | "face";
export interface EngineLayer { id: string; order: number; kind: LayerKind; }

export interface NavEdge { from: string; to: string; cost?: number; requires?: string[]; }
export interface NavNode { id: string; position: Vec2; edges: NavEdge[]; }
export interface NavigationCapabilities { capabilities: Set<string>; }
export interface NavigationRequest { objectId: number; target: Vec2; requiredCapabilities?: string[]; speed: number; }
export interface NavigationResult { status: "complete" | "moving" | "no-route" | "interrupted"; path: Vec2[]; next?: Vec2; }

export interface InputSnapshot {
  pressed: Set<string>; held: Set<string>; released: Set<string>;
  pointers: Map<number, { x: number; y: number; pressure: number; down: boolean }>;
  analog: Map<string, number>;
}
export interface InputMapping { action: string; controls: string[]; }

export interface AssetResult { path: string; bytes?: Uint8Array; missing: boolean; }

export interface F5EngineConfig {
  viewport?: { width: number; height: number; dpi: number };
  clearColor?: RenderColor;
  maxFixedStepsPerFrame?: number;
}

const EPS = 1e-9;
function finite(n: number, label: string): number { if (!Number.isFinite(n)) throw new Error(`${label} must be finite`); return n; }
function nonNegative(n: number, label: string): number { finite(n, label); if (n < 0) throw new Error(`${label} must be non-negative`); return n; }
function norm(s: string): string { return s.normalize("NFC").toLowerCase(); }
function cloneVec(v: Vec2): Vec2 { return { x: v.x, y: v.y }; }
function color(c: RenderColor): RenderColor { return { r:c.r,g:c.g,b:c.b,a:c.a }; }

/** Exact minimum boundary-to-boundary distance. Overlap/contact returns #0fro. */
export function boundaryDistance(a: Boundary, b: Boundary): number {
  if (a.kind === "circle" && b.kind === "circle") return Math.max(0, Math.hypot(a.x-b.x, a.y-b.y) - a.radius - b.radius);
  if (a.kind === "rect" && b.kind === "rect") {
    const dx = Math.max(Math.abs(a.x-b.x) - (a.width+b.width)/2, 0);
    const dy = Math.max(Math.abs(a.y-b.y) - (a.height+b.height)/2, 0);
    return Math.hypot(dx, dy);
  }
  const c = a.kind === "circle" ? a : b as CircleBoundary;
  const r = a.kind === "rect" ? a : b as RectBoundary;
  const qx = Math.max(r.x-r.width/2, Math.min(c.x, r.x+r.width/2));
  const qy = Math.max(r.y-r.height/2, Math.min(c.y, r.y+r.height/2));
  return Math.max(0, Math.hypot(c.x-qx, c.y-qy) - c.radius);
}

export function rangeof(a: Boundary, b: Boundary): number { return boundaryDistance(a, b); }

export class SpatialRegistry {
  private readonly objects = new Map<number, SpatialObject>();
  private nextId = 1;
  add(type: string, position: Vec2, layer = "World", foot: FootAnchor = {x:0,y:0}, radius?: number): number {
    finite(position.x,"x"); finite(position.y,"y"); finite(foot.x,"foot.x"); finite(foot.y,"foot.y");
    if (radius !== undefined) nonNegative(radius,"radius");
    const id = this.nextId++;
    this.objects.set(id, { id, type, position: cloneVec(position), foot: cloneVec(foot), layer, radius, alive: true });
    return id;
  }
  remove(id:number): boolean { const o=this.objects.get(id); if(!o) return false; o.alive=false; this.objects.delete(id); return true; }
  get(id:number): SpatialObject | undefined { const o=this.objects.get(id); return o ? {...o, position:cloneVec(o.position), foot:cloneVec(o.foot)} : undefined; }
  setPosition(id:number, p:Vec2): boolean { const o=this.objects.get(id); if(!o) return false; finite(p.x,"x"); finite(p.y,"y"); o.position=cloneVec(p); return true; }
  move(id:number, delta:Vec2): boolean { const o=this.objects.get(id); if(!o) return false; return this.setPosition(id,{x:o.position.x+delta.x,y:o.position.y+delta.y}); }
  worldFoot(id:number): Vec2 | undefined { const o=this.objects.get(id); return o ? {x:o.position.x+o.foot.x,y:o.position.y+o.foot.y} : undefined; }
  all(): SpatialObject[] { return [...this.objects.values()].map(o=>({...o,position:cloneVec(o.position),foot:cloneVec(o.foot)})); }
  distance(idA:number,idB:number): number | undefined {
    const a=this.objects.get(idA), b=this.objects.get(idB); if(!a||!b) return undefined;
    const pa=this.worldFoot(idA)!, pb=this.worldFoot(idB)!; return Math.hypot(pa.x-pb.x,pa.y-pb.y);
  }
}

export class LayerRegistry {
  private layers = new Map<string, EngineLayer>();
  constructor() { this.declare("World", 0, "world"); this.declare("Face", Number.MAX_SAFE_INTEGER, "face"); }
  declare(id:string, order:number, kind:LayerKind="world"): void {
    if (!id || !Number.isInteger(order)) throw new Error("invalid layer");
    if (kind === "face" && id !== "Face") throw new Error("Face is reserved");
    if (id === "Face" && kind !== "face") throw new Error("Face must be the fixed Face layer");
    this.layers.set(norm(id), {id,order,kind});
  }
  get(id:string): EngineLayer | undefined { const l=this.layers.get(norm(id)); return l ? {...l} : undefined; }
  ordered(): EngineLayer[] { return [...this.layers.values()].sort((a,b)=>a.order-b.order || a.id.localeCompare(b.id)); }
  interactionAllowed(a:string,b:string): boolean { const x=this.get(a),y=this.get(b); return !!x&&!!y&&x.kind==="world"&&y.kind==="world"&&x.id===y.id; }
}

export class NavigationGraph {
  private nodes = new Map<string,NavNode>();
  addNode(id:string, position:Vec2): void { this.nodes.set(norm(id),{id,position:cloneVec(position),edges:[]}); }
  addEdge(from:string,to:string,cost=1,requires:string[]=[]): void { const a=this.nodes.get(norm(from)), b=this.nodes.get(norm(to)); if(!a||!b) throw new Error("navigation edge references unknown node"); if(!(cost>0)||!Number.isFinite(cost)) throw new Error("edge cost must be positive"); a.edges.push({from:a.id,to:b.id,cost,requires:[...requires].map(norm)}); }
  findPath(start:Vec2,target:Vec2,caps:Set<string>,required:string[]=[]): Vec2[] | undefined {
    const allowed=[...this.nodes.values()];
    if(!allowed.length) return undefined;
    const nearest=(p:Vec2)=>allowed.reduce((best,n)=>Math.hypot(n.position.x-p.x,n.position.y-p.y)<Math.hypot(best.position.x-p.x,best.position.y-p.y)?n:best,allowed[0]);
    const s=nearest(start), goal=nearest(target), need=required.map(norm); const dist=new Map<string,number>([[norm(s.id),0]]), prev=new Map<string,string>(); const open=[s.id];
    while(open.length){ open.sort((a,b)=>(dist.get(a)!)-(dist.get(b)!)); const id=open.shift()!; if(norm(id)===norm(goal.id)) break; const n=this.nodes.get(norm(id))!;
      for(const e of n.edges){ if(!(e.requires ?? []).every(c=>caps.has(norm(c)))||!need.every(c=>caps.has(c))) continue; const nd=dist.get(norm(id))!+(e.cost??1); if(nd < (dist.get(norm(e.to)) ?? Infinity)){dist.set(norm(e.to),nd);prev.set(norm(e.to),id);open.push(e.to);} }
    }
    if(!dist.has(norm(goal.id))) return undefined; const rev:string[]=[]; let cur=goal.id; while(true){rev.push(cur); const p=prev.get(norm(cur)); if(!p) break; cur=p;} rev.reverse(); return rev.map(id=>cloneVec(this.nodes.get(norm(id))!.position)).concat([cloneVec(target)]);
  }
}

export class NavigationController {
  private active = new Map<number,{path:Vec2[]; index:number; speed:number}>();
  constructor(private readonly graph:NavigationGraph, private readonly spatial:SpatialRegistry, private readonly capabilities=new Map<number,Set<string>>()) {}
  setCapabilities(id:number,caps:string[]):void { this.capabilities.set(id,new Set(caps.map(norm))); }
  navigate(req:NavigationRequest): NavigationResult {
    const caps=this.capabilities.get(req.objectId)??new Set<string>();
    if ((req.requiredCapabilities??[]).some(c=>!caps.has(norm(c)))) { this.active.delete(req.objectId); return {status:"no-route",path:[]}; }
    const path=this.graph.findPath(this.spatial.get(req.objectId)?.position??req.target,req.target,caps,req.requiredCapabilities??[]);
    if(!path) { this.active.delete(req.objectId); return {status:"no-route",path:[]}; }
    this.active.set(req.objectId,{path,index:1,speed:nonNegative(req.speed,"speed")}); return {status:path.length<=1?"complete":"moving",path,next:path[1]};
  }
  interrupt(id:number): NavigationResult { const a=this.active.get(id); if(!a) return {status:"interrupted",path:[]}; this.active.delete(id); return {status:"interrupted",path:a.path.slice(a.index)}; }
  step(dt:number): NavigationResult[] {
    nonNegative(dt,"dt"); const out:NavigationResult[]=[];
    for(const [id,a] of this.active){
      let o=this.spatial.get(id); if(!o){this.active.delete(id);continue;}
      let left=a.speed*dt;
      while(left>EPS&&a.index<a.path.length){
        const t=a.path[a.index], dx=t.x-o.position.x, dy=t.y-o.position.y, d=Math.hypot(dx,dy);
        if(d<=left+EPS){ this.spatial.setPosition(id,t); left-=d; a.index++; o=this.spatial.get(id)!; }
        else { this.spatial.setPosition(id,{x:o.position.x+dx/d*left,y:o.position.y+dy/d*left}); left=0; o=this.spatial.get(id)!; }
      }
      if(a.index>=a.path.length)this.active.delete(id);
      out.push({status:a.index>=a.path.length?"complete":"moving",path:a.path.slice(a.index),next:a.path[a.index]});
    }
    return out;
  }
}

export class InputState {
  private p=new Set<string>(); private h=new Set<string>(); private r=new Set<string>();
  private pointers=new Map<number,{x:number;y:number;pressure:number;down:boolean}>(); private analog=new Map<string,number>();
  beginFrame():void { this.p.clear(); this.r.clear(); }
  consume(e:InputEvent):void { if(e.type==="pointer"){this.pointers.set(e.pointerId,{x:e.x,y:e.y,pressure:e.pressure??0,down:e.phase!=="up"}); const k=`pointer:${e.pointerId}`; if(e.phase==="down"){this.p.add(k);this.h.add(k)} else if(e.phase==="up"){this.r.add(k);this.h.delete(k);} } else if(e.type==="key"){const k=`key:${e.key}`; if(e.phase==="down"){if(!this.h.has(k))this.p.add(k);this.h.add(k)}else{this.h.delete(k);this.r.add(k);} } else this.analog.set(e.control,e.value); }
  pressed(k:string):boolean{return this.p.has(k)} held(k:string):boolean{return this.h.has(k)} released(k:string):boolean{return this.r.has(k)}
  pointer(id:number){const p=this.pointers.get(id);return p?{...p}:undefined} analogValue(k:string):number{return this.analog.get(k)??0}
  snapshot():InputSnapshot{return {pressed:new Set(this.p),held:new Set(this.h),released:new Set(this.r),pointers:new Map([...this.pointers].map(([k,v])=>[k,{...v}])),analog:new Map(this.analog)}}
}

export class InputMapper {
  private maps=new Map<string,InputMapping>();
  bind(action:string,controls:string[]):void {this.maps.set(norm(action),{action,controls:[...controls]})}
  active(action:string,input:InputState,edge:"pressed"|"held"|"released"="held"):boolean {const m=this.maps.get(norm(action));if(!m)return false;return m.controls.some(c=>edge==="pressed"?input.pressed(c):edge==="released"?input.released(c):input.held(c));}
}

export class FixedStepper {
  readonly hz=60; readonly dt=1/60; accumulator=0; tick=0;
  constructor(private readonly maxSteps=8) {if(!Number.isInteger(maxSteps)||maxSteps<1)throw new Error("maxSteps must be positive integer");}
  advance(frameDt:number,step:()=>void):number {nonNegative(frameDt,"frameDt");this.accumulator+=frameDt;let n=0;while(this.accumulator+EPS>=this.dt&&n<this.maxSteps){step();this.accumulator-=this.dt;n++;this.tick++;}return n;}
}

export class AssetStore {
  constructor(private readonly host:Pick<FroztHostApi,"readPackageFile">, private readonly diagnostic?:(message:string)=>void){}
  read(path:string):AssetResult {if(!path||path.startsWith("/")||path.split("/").includes("..")){this.diagnostic?.(`rejected asset path: ${path}`);return {path,missing:true};} const p=this.host.readPackageFile(path);if(!p){this.diagnostic?.(`missing asset: ${path}`);return {path,missing:true};} return {path,bytes:new Uint8Array(p.bytes),missing:false};}
}

export class RenderModelBuilder {
  private viewport={width:1,height:1,dpi:1}; private clear:RenderColor={r:0,g:0,b:0,a:1}; private camera={x:0,y:0,zoom:1,rotation:0};
  private layers=new Map<string,RenderWorldLayer>(); private face:FaceElement[]=[];
  setViewport(width:number,height:number,dpi:number){this.viewport={width:finite(width,"width"),height:finite(height,"height"),dpi:finite(dpi,"dpi")};}
  setClearColor(c:RenderColor){this.clear=color(c)} setCamera(c:{x:number;y:number;zoom:number;rotation:number}){this.camera={...c}}
  setLayers(layers:EngineLayer[]){this.layers.clear();for(const l of layers.filter(x=>x.kind==="world"))this.layers.set(norm(l.id),{id:l.id,order:l.order,sprites:[]});}
  addSprite(layer:string,s:Omit<RenderSprite,"kind">){const l=this.layers.get(norm(layer));if(!l)throw new Error(`unknown render layer: ${layer}`);l.sprites.push({kind:"sprite",...s});}
  setFace(elements:FaceElement[]){this.face=elements.map(e=>({...e} as FaceElement));}
  build():RenderModel{return {version:1,viewport:{...this.viewport},clearColor:color(this.clear),camera:{...this.camera},worldLayers:[...this.layers.values()].sort((a,b)=>a.order-b.order||a.id.localeCompare(b.id)).map(l=>({...l,sprites:l.sprites.map(s=>({...s,animation:s.animation?{...s.animation}:undefined}))})),face:{id:"Face",elements:this.face.map(e=>({...e} as FaceElement))}}}
}

export class F5CoreEngine {
  readonly spatial=new SpatialRegistry(); readonly layers=new LayerRegistry(); readonly navigation=new NavigationGraph(); readonly input=new InputState(); readonly mappings=new InputMapper(); readonly stepper:FixedStepper; readonly random:SeededRandom; readonly assets:AssetStore; readonly renderModel=new RenderModelBuilder();
  private renderHook?: (m:RenderModel)=>void;
  constructor(host:Pick<FroztHostApi,"readPackageFile">, seed:number|bigint=0, config:F5EngineConfig={}){this.stepper=new FixedStepper(config.maxFixedStepsPerFrame??8);this.random=new SeededRandom(seed);this.assets=new AssetStore(host);this.renderModel.setViewport(config.viewport?.width??1,config.viewport?.height??1,config.viewport?.dpi??1);this.renderModel.setClearColor(config.clearColor??{r:0,g:0,b:0,a:1});this.renderModel.setLayers(this.layers.ordered());}
  onRender(cb:(m:RenderModel)=>void){this.renderHook=cb;}
  frame(dt:number,simulation:()=>void):number {const n=this.stepper.advance(dt,simulation);this.renderHook?.(this.renderModel.build());return n;}
}
