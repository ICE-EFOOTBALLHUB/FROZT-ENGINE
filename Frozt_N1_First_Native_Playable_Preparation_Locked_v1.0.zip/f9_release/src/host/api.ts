import type { RenderModel } from "./render-model";
import type { PresentationEnvironment } from "../presentation/contract";

export interface PackageBytes { readonly bytes: Uint8Array; }
export type SaveValue = null | boolean | number | string | SaveValue[] | { [key: string]: SaveValue };

export type InputEvent =
  | { type: "pointer"; phase: "down" | "move" | "up"; pointerId: number; x: number; y: number; pressure?: number }
  | { type: "key"; phase: "down" | "up"; key: string; repeat: boolean }
  | { type: "analog"; control: string; value: number };

export interface HostDiagnostic { code: string; severity: "info" | "warning" | "error"; message: string; detail?: string; }
export interface AudioInstanceId { readonly id: number; }
export interface AudioPlayRequest { assetPath: string; loop: boolean; volume: number; }

/** OQ-40 draft: implementation contract is NOT locked until host conformance tests pass. */
export interface FroztHostApi {
  start(packageId: string, seed: number): void;
  stop(): void;
  suspend(): void;
  resume(): void;
  input(event: InputEvent): void;
  tick(dtMs: number): void;
  resize(width: number, height: number, dpi: number): void;
  presentationEnvironment(environment: PresentationEnvironment): void;

  readPackageFile(path: string): PackageBytes | undefined;
  saveGet(key: string): SaveValue | undefined;
  savePut(key: string, value: SaveValue): void;
  saveDelete(key: string): void;

  playAudio(request: AudioPlayRequest): AudioInstanceId;
  pauseAudio(id: AudioInstanceId): void;
  stopAudio(id: AudioInstanceId): void;
  setVolume(id: AudioInstanceId, volume: number): void;

  render(model: RenderModel): void;
  diagnostic(record: HostDiagnostic): void;
  sessionComplete(): void;
}
