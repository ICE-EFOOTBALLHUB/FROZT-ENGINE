/**
 * FROZT render-model draft for OQ-40.
 * Plain data only: no DOM, canvas, GPU, SDL, Node, or platform objects.
 * JSON serialization is part of the F5 conformance gate.
 */
export interface RenderColor { r: number; g: number; b: number; a: number; }
export interface RenderCamera { x: number; y: number; zoom: number; rotation: number; }
export interface RenderViewport { width: number; height: number; dpi: number; }
export interface RenderSprite {
  kind: "sprite";
  imageId: string;
  x: number; y: number;
  scaleX: number; scaleY: number;
  rotation: number;
  mirrorX: boolean; mirrorY: boolean;
  opacity: number;
  visible: boolean;
  animation?: { animationId: string; frame: number; frameTime: number };
}
export interface FaceBarElement {
  kind: "bar";
  id: string;
  x: number; y: number; width: number; height: number;
  value: number; min: number; max: number;
  fill: RenderColor; background: RenderColor;
  visible: boolean;
}
export interface FaceTextElement {
  kind: "text";
  id: string;
  x: number; y: number;
  text: string;
  size: number;
  color: RenderColor;
  opacity: number;
  visible: boolean;
}
export interface FaceImageElement {
  kind: "image";
  id: string;
  imageId: string;
  x: number; y: number;
  width: number; height: number;
  opacity: number;
  visible: boolean;
}
export type FaceElement = FaceBarElement | FaceTextElement | FaceImageElement;
export interface RenderWorldLayer { id: string; order: number; sprites: RenderSprite[]; }
export interface RenderFaceLayer { id: "Face"; elements: FaceElement[]; }
export interface RenderModel {
  version: 1;
  viewport: RenderViewport;
  clearColor: RenderColor;
  camera: RenderCamera;
  worldLayers: RenderWorldLayer[];
  face: RenderFaceLayer;
}

export function assertSerializableRenderModel(model: RenderModel): void {
  const encoded = JSON.stringify(model);
  if (encoded === undefined) throw new Error("render model is not JSON-serializable");
  const decoded = JSON.parse(encoded) as RenderModel;
  if (decoded.version !== 1 || decoded.face?.id !== "Face") {
    throw new Error("render model round-trip failed");
  }
}
