import { InputMapper, InputState } from '../engine/f5';
import { PresentationController, type PresentationEnvironment, type PresentationVariant } from '../presentation';
import type { FaceElement } from '../host/render-model';

export type RunnerObstacleKind = 'jump' | 'duck' | 'attack';
export type RunnerAction = 'jump' | 'duck' | 'attack';
export interface RunnerObstacle { id:number; kind:RunnerObstacleKind; x:number; y:number; width:number; height:number; alive:boolean; }
export interface RunnerState { score:number; lives:number; gameOver:boolean; playerY:number; playerVelocity:number; ducking:boolean; attacking:boolean; distance:number; speed:number; obstacles:RunnerObstacle[]; beamX?:number; }

const DT=1/60;
const PLAYER_X=0;
const GROUND=0;

/** F9 vertical slice: deterministic endless runner simulation with platform-neutral actions. */
export class EndlessRunnerGame {
  readonly input=new InputState();
  readonly mappings=new InputMapper();
  readonly presentation=new PresentationController();
  private nextObstacle=1;
  private spawnTimer=0;
  private rng=0x9e3779b9;
  private state:RunnerState={score:0,lives:3,gameOver:false,playerY:GROUND,playerVelocity:0,ducking:false,attacking:false,distance:0,speed:7,obstacles:[]};
  private variants:readonly PresentationVariant[]=[];
  constructor(seed=1){
    this.rng=seed|0;
    this.mappings.bind('jump',['key:ArrowUp','key:Space','action:jump']);
    this.mappings.bind('duck',['key:ArrowDown','action:duck']);
    this.mappings.bind('attack',['key:KeyX','key:Enter','action:attack']);
    this.variants=[
      {id:'compact',priority:10,when:e=>e.width<900 || e.orientation==='portrait'},
      {id:'expanded',priority:1,when:e=>true}
    ];
  }
  get snapshot():RunnerState{return {...this.state,obstacles:this.state.obstacles.map(o=>({...o}))};}
  updatePresentation(env:PresentationEnvironment){return this.presentation.update(env,this.variants);}
  private rand(){let x=this.rng|0;x^=x<<13;x^=x>>>17;x^=x<<5;this.rng=x|0;return ((x>>>0)%1000000)/1000000;}
  private spawn(){const r=this.rand();const kind:runnersKind = r<0.34?'jump':r<0.67?'duck':'attack';this.state.obstacles.push({id:this.nextObstacle++,kind,x:13+this.rand()*3,y:kind==='duck'?2:0,width:1.2,height:kind==='duck'?2.5:1.5,alive:true});}
  private collide(o:RunnerObstacle){const px=PLAYER_X, py=this.state.playerY;const horizontal=Math.abs(o.x-px)<=(o.width+1)/2;if(!horizontal)return false;if(o.kind==='jump')return py<1.2 && !this.state.attacking;if(o.kind==='duck')return !this.state.ducking;return !this.state.attacking;}
  private damage(){this.state.lives--;if(this.state.lives<=0)this.state.gameOver=true;}
  step(action?:RunnerAction){
    if(this.state.gameOver)return;
    this.input.beginFrame();
    this.state.ducking=action==='duck';
    this.state.attacking=action==='attack';
    if(action==='jump' && this.state.playerY===GROUND)this.state.playerVelocity=9.5;
    this.state.playerVelocity-=22*DT;
    this.state.playerY=Math.max(GROUND,this.state.playerY+this.state.playerVelocity*DT);
    if(this.state.playerY===GROUND)this.state.playerVelocity=0;
    this.state.distance+=this.state.speed*DT;
    this.state.score=Math.floor(this.state.distance*10);
    this.spawnTimer-=DT;
    if(this.spawnTimer<=0){this.spawn();this.spawnTimer=1.15+this.rand()*0.9;}
    const beamStart=PLAYER_X+1.2;
    for(const o of this.state.obstacles){o.x-=this.state.speed*DT;if(o.kind==='attack'&&this.state.attacking&&o.x<beamStart+8&&o.x>beamStart){o.alive=false;}}
    for(const o of this.state.obstacles){if(o.alive&&o.x>-1.5&&this.collide(o)){o.alive=false;this.damage();break;}}
    this.state.obstacles=this.state.obstacles.filter(o=>o.alive&&o.x>-5);
    this.state.beamX=this.state.attacking?beamStart+8:undefined;
  }
  reset(){this.state={score:0,lives:3,gameOver:false,playerY:GROUND,playerVelocity:0,ducking:false,attacking:false,distance:0,speed:7,obstacles:[]};this.spawnTimer=0;this.nextObstacle=1;}
  face(env:PresentationEnvironment):FaceElement[]{
    const compact=this.presentation.current().variant==='compact';
    const safe=env.safeArea;
    const w=env.width,h=env.height;
    const elements:FaceElement[]=[
      {kind:'text',id:'score',x:safe.left+16,y:safe.top+16,text:`SCORE ${this.state.score}`,size:compact?22:28,color:{r:1,g:1,b:1,a:1},opacity:1,visible:true},
      {kind:'text',id:'lives',x:w-safe.right-(compact?110:150),y:safe.top+16,text:`LIVES ${this.state.lives}`,size:compact?20:26,color:{r:1,g:1,b:1,a:1},opacity:1,visible:true},
    ];
    if(compact){elements.push(
      {kind:'text',id:'jump',x:safe.left+24,y:h-safe.bottom-80,text:'JUMP',size:18,color:{r:1,g:1,b:1,a:1},opacity:1,visible:true},
      {kind:'text',id:'duck',x:w/2-35,y:h-safe.bottom-80,text:'DUCK',size:18,color:{r:1,g:1,b:1,a:1},opacity:1,visible:true},
      {kind:'text',id:'attack',x:w-safe.right-90,y:h-safe.bottom-80,text:'LIGHT',size:18,color:{r:1,g:1,b:1,a:1},opacity:1,visible:true}
    );}
    if(this.state.gameOver)elements.push({kind:'text',id:'gameover',x:w/2-100,y:h/2,text:'GAME OVER',size:36,color:{r:1,g:1,b:1,a:1},opacity:1,visible:true});
    return elements;
  }
}
type runnersKind=RunnerObstacleKind;
