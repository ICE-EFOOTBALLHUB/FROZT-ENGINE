export type Orientation = 'portrait' | 'landscape' | 'square';
export type LayoutVariant = string;
export type InputCapability = 'touch' | 'mouse' | 'keyboard' | 'gamepad' | 'pointer';

export interface SafeArea { left: number; top: number; right: number; bottom: number; }
export interface PresentationEnvironment {
  width: number; height: number; dpi: number; safeArea: SafeArea; orientation: Orientation;
  pointer: boolean; capabilities: ReadonlySet<InputCapability>;
}
export interface SizeConstraint { min?: number; max?: number; }
export interface Insets { top: number; right: number; bottom: number; left: number; }
export interface LayoutConstraints { width?: SizeConstraint; height?: SizeConstraint; margin?: Insets; padding?: Insets; }
export type PresentationCondition = (env: PresentationEnvironment) => boolean;
export interface PresentationVariant { id: LayoutVariant; priority: number; when: PresentationCondition; }

export function orientation(width: number, height: number): Orientation {
  return width === height ? 'square' : width < height ? 'portrait' : 'landscape';
}
export function createEnvironment(input: Omit<PresentationEnvironment, 'orientation'> & { orientation?: Orientation }): PresentationEnvironment {
  if (!(input.width > 0) || !(input.height > 0) || !(input.dpi > 0)) throw new Error('invalid presentation environment');
  const safeArea = input.safeArea;
  for (const n of [safeArea.left,safeArea.top,safeArea.right,safeArea.bottom]) if (n < 0 || !Number.isFinite(n)) throw new Error('invalid safe area');
  return { ...input, orientation: input.orientation ?? orientation(input.width, input.height), capabilities: new Set(input.capabilities) };
}

export function selectVariant(env: PresentationEnvironment, variants: readonly PresentationVariant[], fallback = 'default'): string {
  return [...variants].sort((a,b)=>b.priority-a.priority || a.id.localeCompare(b.id)).find(v=>v.when(env))?.id ?? fallback;
}

/** Logical presentation state is separate from simulation state. */
export interface PresentationState { variant: string; revision: number; }
export class PresentationController {
  private state: PresentationState = { variant: 'default', revision: 0 };
  update(env: PresentationEnvironment, variants: readonly PresentationVariant[]): PresentationState {
    const next = selectVariant(env, variants, 'default');
    if (next !== this.state.variant) this.state = { variant: next, revision: this.state.revision + 1 };
    return { ...this.state };
  }
  current(): PresentationState { return { ...this.state }; }
}
