import { SourcePosition } from "../lexer/token";

export interface SourceSpan { start: SourcePosition; end: SourcePosition; }
export interface Node { kind: string; span: SourceSpan; }
export interface Program extends Node { kind: "Program"; header?: FroztMarker; footer?: FroztMarker; body: Statement[]; }
export interface FroztMarker extends Node { kind: "FroztHeader" | "FroztFooter"; }
export interface Block extends Node { kind: "Block"; body: Statement[]; }
export interface ErrorNode extends Node { kind: "ErrorNode"; message: string; }
export type Statement = CommandNode | BlockStatement | ExpressionStatement | ErrorNode;
export interface BlockStatement extends Node { kind: "BlockStatement"; name: string; body: Statement[]; args: Expression[]; }
export interface ExpressionStatement extends Node { kind: "ExpressionStatement"; expression: Expression; }
export interface CommandNode extends Node { kind: "Command"; name: string; args: Expression[]; body?: Block; fields?: FieldNode[]; }
export interface FieldNode extends Node { kind: "Field"; name: string; value: Expression; }
export type Expression = LiteralExpr | ValueRefExpr | ReferenceExpr | UnaryExpr | BinaryExpr | MutationExpr | GroupedExpr | ErrorExpr;
export interface LiteralExpr extends Node { kind: "LiteralExpr"; value: unknown; tokenKind: string; }
export interface ValueRefExpr extends Node { kind: "ValueRefExpr"; name: string; }
export interface ReferenceExpr extends Node { kind: "ReferenceExpr"; referenceKind: "id" | "type" | "path"; value: string; instance?: number; }
export interface UnaryExpr extends Node { kind: "UnaryExpr"; operator: "not"; operand: Expression; }
export interface BinaryExpr extends Node { kind: "BinaryExpr"; operator: string; left: Expression; right: Expression; }
export interface MutationExpr extends Node { kind: "MutationExpr"; operator: "=" | "+=" | "-=" | "*=" | "/="; left: Expression; right: Expression; }
export interface GroupedExpr extends Node { kind: "GroupedExpr"; expression: Expression; }
export interface ErrorExpr extends Node { kind: "ErrorExpr"; message: string; }
