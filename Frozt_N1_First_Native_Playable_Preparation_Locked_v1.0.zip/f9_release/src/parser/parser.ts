import { Lexer } from "../lexer/lexer";
import { Token } from "../lexer/token";
import { ParserDiagnostic } from "./diagnostic";
import * as A from "./ast";

export interface ParseResult { ast: A.Program; diagnostics: ParserDiagnostic[]; }

const commandNames = new Set(["add","set","spawn","mod","eval","event","action","do","fetch"]);

export class Parser {
  private i=0;
  private readonly diagnostics: ParserDiagnostic[]=[];
  constructor(private readonly tokens: Token[]) {}
  static fromSource(source: string): ParseResult {
    const lex = new Lexer(new TextEncoder().encode(source)).lex();
    const p = new Parser(lex.tokens);
    const r=p.parse();
    return { ast:r.ast, diagnostics:[...lex.diagnostics.map(d=>({code:d.code.replace(/^LEX-/,"PAR-LEX-"),severity:"error" as const,message:d.message,start:d.start,end:d.end})),...r.diagnostics] };
  }
  parse(): ParseResult {
    const start=this.peek().start; let header:A.FroztMarker|undefined, footer:A.FroztMarker|undefined;
    if(this.isMarker("FROZT")){ const t=this.take(); header={kind:"FroztHeader",span:{start:t.start,end:t.end}}; }
    const body:A.Statement[]=[];
    while(!this.at("EOF")){
      if(this.isMarker("/FROZT")){ if(footer)this.error("PAR-002","Duplicate /FROZT footer.",this.peek()); else {const s=this.take(), e=this.take(); footer={kind:"FroztFooter",span:{start:s.start,end:e.end}};} if(!this.at("EOF")) this.recoverTop(); continue; }
      body.push(this.parseStatement());
    }
    if(header && !footer) this.error("PAR-003","FROZT header requires a matching /FROZT footer.",this.peek());
    if(!header && footer) this.error("PAR-003","/FROZT footer requires a matching FROZT header.",this.peek());
    const end=this.peek().end;
    return {ast:{kind:"Program",span:{start,end},header,footer,body},diagnostics:this.diagnostics};
  }
  private parseStatement():A.Statement {
    if(this.at("ERROR")){const t=this.take(); return this.errorNode("Lexical error token.",t);}
    if(this.atPunct("}")){return this.errorNode("Unexpected closing block delimiter.",this.peek());}
    if(this.at("WORD")){const name=String(this.peek().value??this.peek().raw); return this.parseCommand(name);}
    if(this.canStartExpression()) { const e=this.parseExpression(); return {kind:"ExpressionStatement",expression:e,span:e.span}; }
    return this.errorNode("Expected a statement.",this.peek());
  }
  private parseCommand(name:string):A.CommandNode|A.BlockStatement|A.ErrorNode {
    const first=this.take(); const args:A.Expression[]=[]; const fields:A.FieldNode[]=[]; let block:A.Block|undefined;
    if(this.atPunct("{")) block=this.parseBlock();
    else if(name==="set" || name==="mod") {
      const left=this.parseUnary();
      const op=this.peek().raw;
      if(["=","+=","-=","*=","/="].includes(op)) {
        this.take(); const right=this.parseExpression(0);
        const m:A.MutationExpr={kind:"MutationExpr",operator:op as any,left,right,span:{start:left.span.start,end:right.span.end}};
        args.push(m);
      } else { this.error("PAR-002",`Expected mutation operator after ${name}.`,this.peek()); args.push(left); }
      if(this.atPunct("{")) block=this.parseBlock();
    } else {
      while(!this.at("EOF")&&!this.atPunct("}")&&!this.startsStatement()) {
        if(this.at("WORD") && this.peek(1).kind==="PUNCT" && this.peek(1).raw==="{" ) break;
        const e=this.parseExpression(); if(e.kind==="ErrorExpr" && this.peek()===this.tokens[this.i]) {this.take(); break;} args.push(e);
      }
      if(this.atPunct("{")) block=this.parseBlock();
    }
    const span={start:first.start,end:(block?.span.end ?? (args.at(-1)?.span.end ?? first.end))};
    if(block) return {kind:"Command",name,args,body:block,fields:fields.length?fields:undefined,span};
    if(commandNames.has(name)) return {kind:"Command",name,args,span};
    return {kind:"Command",name,args,span};
  }
  private parseBlock():A.Block {
    const open=this.expectPunct("{"); const body:A.Statement[]=[];
    while(!this.at("EOF")&&!this.atPunct("}")) body.push(this.parseStatement());
    if(this.atPunct("}")){const close=this.take(); return {kind:"Block",span:{start:open.start,end:close.end},body};}
    this.error("PAR-004","Unterminated block; expected }.",this.peek());
    return {kind:"Block",span:{start:open.start,end:this.peek().end},body};
  }
  private parseExpression(min=0):A.Expression {
    let left=this.parseUnary();
    const prec=(op:string)=>({"*":60,"/":60,"+":50,"-":50,"=":40,"not =":40,"<":40,">":40,"<=":40,">=":40,"and":30,"nand":20,"or":10,"nor":10}[op]??-1);
    while(true){let op=this.operator(); if(!op) break; const p=prec(op); if(p<min) break; this.takeOp(op); const right=this.parseExpression(p+1); left={kind:"BinaryExpr",operator:op,left,right,span:{start:left.span.start,end:right.span.end}};}
    return left;
  }
  private parseUnary():A.Expression {
    if(this.at("WORD") && this.peek().raw==="not" && this.peek(1).raw!=="="){const t=this.take(); const operand=this.parseUnary(); return {kind:"UnaryExpr",operator:"not",operand,span:{start:t.start,end:operand.span.end}};}
    if(this.atPunct("{")){const o=this.take(), e=this.parseExpression(); if(this.atPunct("}")){const c=this.take(); return {kind:"GroupedExpr",expression:e,span:{start:o.start,end:c.end}};} this.error("PAR-002","Expected } to close expression group.",this.peek()); return {kind:"GroupedExpr",expression:e,span:{start:o.start,end:e.span.end}};}
    const t=this.peek();
    if(t.kind==="NUMBER") {
      const u=this.peek(1);
      if(u.kind==="UNIT" && t.end.byte===u.start.byte) {
        this.take(); this.take();
        return {kind:"LiteralExpr",value:`${t.value??t.raw}${u.value??u.raw}`,tokenKind:"UNIT",span:{start:t.start,end:u.end}};
      }
      this.take();
      return {kind:"LiteralExpr",value:t.value??t.raw,tokenKind:"NUMBER",span:{start:t.start,end:t.end}};
    }
    if(t.kind==="UNIT"||t.kind==="PERCENT"||t.kind==="COLOR"||t.kind==="BOOL"||t.kind==="TEXT") {this.take(); return {kind:"LiteralExpr",value:t.value??t.raw,tokenKind:t.kind,span:{start:t.start,end:t.end}};}
    if(t.kind==="VALUE_REF"){this.take(); return {kind:"ValueRefExpr",name:String(t.value??t.raw).replace(/^\[|\]$/g,""),span:{start:t.start,end:t.end}};}
    if(t.kind==="ID_LIT"||t.kind==="TYPE_LIT"||t.kind==="PATH_LIT") {this.take(); return {kind:"ReferenceExpr",referenceKind:t.kind.slice(0,-4).toLowerCase() as any,value:String(t.value??""),span:{start:t.start,end:t.end}};}
    if(t.kind==="WORD"){this.take(); return {kind:"LiteralExpr",value:t.raw,tokenKind:"WORD",span:{start:t.start,end:t.end}};}
    this.error("PAR-001","Expected expression.",t); this.take(); return {kind:"ErrorExpr",message:"Expected expression.",span:{start:t.start,end:t.end}};
  }
  private operator():string|undefined {
    const a=this.peek().raw,b=this.peek(1).raw;
    if(a==="not"&&b==="=") return "not =";
    if(["+","-","*","/","=","<",">","<=",">="].includes(a)) return a;
    if(this.peek().kind==="WORD"&&["and","or","nand","nor"].includes(a)) return a;
    return undefined;
  }
  private takeOp(op:string){this.take(); if(op==="not =") this.take();}
  private canStartExpression(){ const k=this.peek().kind; return k==="NUMBER"||k==="UNIT"||k==="PERCENT"||k==="COLOR"||k==="BOOL"||k==="TEXT"||k==="VALUE_REF"||k==="ID_LIT"||k==="TYPE_LIT"||k==="PATH_LIT"||k==="PUNCT"&&this.peek().raw==="{"||(k==="WORD"&&this.peek().raw==="not"); }
  private startsStatement(){return this.at("WORD")||this.at("ERROR")||this.atPunct("}")||this.canStartExpression();}
  private isMarker(s:string){return this.peek().raw===s || (s==="/FROZT"&&this.peek().raw==="/"&&this.peek(1).raw==="FROZT");}
  private at(k:string){return this.peek().kind===k;}
  private atPunct(s:string){return this.peek().kind==="PUNCT"&&this.peek().raw===s;}
  private peek(n=0){return this.tokens[Math.min(this.i+n,this.tokens.length-1)];}
  private take(){return this.tokens[this.i++];}
  private expectPunct(s:string){if(this.atPunct(s)) return this.take(); this.error("PAR-002",`Expected ${s}.`,this.peek()); return this.peek();}
  private error(code:string,message:string,t:Token){this.diagnostics.push({code,severity:"error",message,start:t.start,end:t.end});}
  private errorNode(message:string,t:Token):A.ErrorNode{this.error("PAR-001",message,t); this.recoverTop(); return {kind:"ErrorNode",message,span:{start:t.start,end:t.end}};}
  private recoverTop(){while(!this.at("EOF")&&!this.atPunct("}")&&!this.startsStatement()) this.take();}
}

export function parse(source:string):ParseResult{return Parser.fromSource(source)}
