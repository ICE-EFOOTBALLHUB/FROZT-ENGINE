import { SourcePosition } from "../lexer/token";
export interface ParserDiagnostic { code: string; severity: "error"; message: string; start: SourcePosition; end: SourcePosition; }
