import * as A from "../parser/ast";
import { analyze } from "../semantic";
import { parse } from "../parser";
import { RUNTIME_HOST_POLICY } from "./policy";

export type PrimitiveValue = number | boolean | string | null;
export interface DimensionedValue { kind: "dimensioned"; dimension: "duration" | "percentage" | "distance" | "unknown"; value: number; unit: string; }
export type RuntimeValue = PrimitiveValue | DimensionedValue | RuntimeObjectRef;
export interface RuntimeObjectRef { kind: "object_ref"; instanceId: number; typeName: string; }

export interface RuntimeDiagnostic { code: string; severity: "error" | "warning"; message: string; }
export interface RuntimeTraceEntry { tick: number; event: string; instanceId?: number; detail?: string; }
export interface RuntimeConfig {
  maxInstructionsPerTick?: number;
  maxRepeatIterations?: number;
  maxEventFiringsPerTick?: number;
  maxStepCountPerFrame?: number;
  resourceLimits?: { instances?: number; timers?: number; instructionsPerTick?: number };
}
export interface RuntimeHost {
  seed?: number | bigint;
  diagnostics?: (d: RuntimeDiagnostic) => void;
  onAudioStop?: (instanceId: number) => void;
  onProcessStop?: (instanceId: number) => void;
  loadModule?: (path: string) => string | undefined;
}

interface ObjectDefinition { key: string; name: string; body: A.Statement[]; initialValues: Map<string, RuntimeValue>; }
interface ActionDefinition { key: string; name: string; body: A.Statement[]; }
interface EventDefinition { node: A.CommandNode; condition: A.Statement[]; response: A.Statement[]; ownerType?: string; active: Map<number, boolean>; }
interface TimerState { key: string; name: string; remaining: number; interval: number; repeating: boolean; }
interface RuntimeInstance { id: number; type: ObjectDefinition; values: Map<string, RuntimeValue>; alive: boolean; }

export interface RuntimeStateSnapshot {
  tick: number;
  time: number;
  instances: Array<{ id: number; type: string; alive: boolean; values: Record<string, RuntimeValue> }>;
  timers: Array<{ name: string; remaining: number; interval: number; repeating: boolean }>;
  canbreak: boolean;
}

function key(s: string): string { return s.normalize("NFC").toLowerCase(); }
function cloneValue(v: RuntimeValue): RuntimeValue {
  if (v && typeof v === "object") return { ...v } as RuntimeValue;
  return v;
}
function numberOf(v: RuntimeValue): number | undefined {
  if (typeof v === "number") return v;
  if (v && typeof v === "object" && v.kind === "dimensioned") return v.value;
  return undefined;
}
function boolOf(v: RuntimeValue): boolean {
  return v === true;
}
function parseNumber(s: string): number { const n = Number(s); return Number.isFinite(n) ? n : NaN; }
function literalValue(e: A.LiteralExpr): RuntimeValue {
  if (e.tokenKind === "NUMBER") return parseNumber(String(e.value));
  if (e.tokenKind === "PERCENT") return { kind: "dimensioned", dimension: "percentage", value: parseNumber(String(e.value)), unit: "%" };
  if (e.tokenKind === "UNIT") {
    const raw = String(e.value).toLowerCase();
    const m = raw.match(/^(-?(?:\d+(?:\.\d+)?))([a-z]+)$/);
    if (!m) return NaN;
    const unit = m[2];
    const dimension = unit === "fro" || unit === "px" ? "distance" : unit === "ms" || unit === "s" || unit === "sec" || unit === "min" ? "duration" : "unknown";
    let n = Number(m[1]);
    if (dimension === "duration") {
      if (unit === "ms") n /= 1000;
      else if (unit === "min") n *= 60;
      return { kind: "dimensioned", dimension, value: n, unit: "s" };
    }
    return { kind: "dimensioned", dimension, value: n, unit };
  }
  if (e.tokenKind === "BOOL") return String(e.value) === "true";
  if (e.tokenKind === "TEXT") return String(e.value);
  if (e.tokenKind === "COLOR") return String(e.value);
  return String(e.value ?? "");
}

export class SeededRandom {
  private state: number;
  constructor(seed: number | bigint = 0) {
    const n = typeof seed === "bigint" ? Number(seed & BigInt(0xffffffff)) : Math.trunc(seed);
    this.state = (n >>> 0) || 0x6d2b79f5;
  }
  next(): number {
    let t = this.state += 0x6D2B79F5;
    t = Math.imul(t ^ t >>> 15, t | 1);
    t ^= t + Math.imul(t ^ t >>> 7, t | 61);
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  }
}

export class FroztRuntime {
  readonly diagnostics: RuntimeDiagnostic[] = [];
  readonly trace: RuntimeTraceEntry[] = [];
  private readonly objects = new Map<string, ObjectDefinition>();
  private readonly actions = new Map<string, ActionDefinition>();
  private readonly events: EventDefinition[] = [];
  private readonly instances = new Map<number, RuntimeInstance>();
  private readonly timers = new Map<string, TimerState>();
  private readonly rng: SeededRandom;
  private readonly host: RuntimeHost;
  private readonly config: Required<RuntimeConfig>;
  private nextInstanceId = 1;
  private tickNumber = 0;
  private timeSeconds = 0;
  private accumulator = 0;
  private canbreakFlag = false;
  private instructionCount = 0;
  private eventFirings = 0;
  private inTick = false;

  constructor(host: RuntimeHost = {}, config: RuntimeConfig = {}) {
    this.host = host;
    this.rng = new SeededRandom(host.seed ?? 0);
    this.config = {
      maxInstructionsPerTick: config.maxInstructionsPerTick ?? 10000,
      maxRepeatIterations: config.maxRepeatIterations ?? 1000,
      maxEventFiringsPerTick: config.maxEventFiringsPerTick ?? 1000,
      maxStepCountPerFrame: config.maxStepCountPerFrame ?? 8,
      resourceLimits: config.resourceLimits ?? {}
    };
  }

  load(source: string, moduleKind: "main" | "fetched" = "main"): boolean {
    const parsed = parse(source);
    const sem = analyze(parsed.ast, parsed.diagnostics);
    if (parsed.diagnostics.length || sem.diagnostics.some(d => d.severity === "error")) {
      const failed = moduleKind === "main";
      this.emit({ code: failed ? "RUN-MAIN-PARSE" : "RUN-MODULE-PARSE", severity: "error", message: failed ? "Main module failed parsing/semantic analysis." : "Fetched module failed parsing/semantic analysis." });
      return !failed;
    }
    this.registerProgram(parsed.ast);
    return true;
  }

  private registerProgram(ast: A.Program): void {
    for (const s of ast.body) {
      if (s.kind !== "Command") continue;
      if (s.name === "add") this.registerObject(s);
      else if (s.name === "action") this.registerAction(s);
      else if (s.name === "event") this.registerEvent(s);
      else if (s.name === "fetch") this.registerFetch(s);
    }
  }

  private registerObject(c: A.CommandNode): void {
    const id = this.firstId(c.body) ?? this.firstIdFromArgs(c.args);
    if (!id) return;
    const def: ObjectDefinition = { key: key(id.value), name: id.value, body: c.body?.body ?? [], initialValues: new Map() };
    this.collectInitialValues(def.body, def.initialValues);
    this.objects.set(def.key, def);
  }
  private registerAction(c: A.CommandNode): void {
    const id = this.firstId(c.body) ?? this.firstIdFromArgs(c.args);
    if (!id) return;
    this.actions.set(key(id.value), { key: key(id.value), name: id.value, body: c.body?.body ?? [] });
  }
  private registerEvent(c: A.CommandNode): void {
    const body = c.body?.body ?? [];
    const thenIndex = body.findIndex(s => s.kind === "Command" && s.name === "then");
    const condition = thenIndex < 0 ? body : body.slice(0, thenIndex);
    const response = thenIndex < 0 ? [] : body.slice(thenIndex + 1);
    const owner = condition.flatMap(s => this.idsInStatement(s)).at(0);
    this.events.push({ node: c, condition, response, ownerType: owner, active: new Map() });
  }
  private registerFetch(c: A.CommandNode): void {
    const p = c.args.find(x => x.kind === "ReferenceExpr" && x.referenceKind === "path") as A.ReferenceExpr | undefined;
    if (!p || !this.host.loadModule) return;
    const src = this.host.loadModule(p.value);
    if (src === undefined) { this.emit({ code: "RUN-MODULE-LOAD", severity: "warning", message: `Module not found: ${p.value}.` }); return; }
    this.load(src, "fetched");
  }

  private collectInitialValues(stmts: A.Statement[], out: Map<string, RuntimeValue>): void {
    for (const s of stmts) {
      if (s.kind === "Command" && (s.name === "set" || s.name === "mod")) {
        const m = s.args[0];
        if (m?.kind === "MutationExpr" && m.left.kind === "ValueRefExpr") {
          const v = this.evalExpr(m.right, undefined);
          if (v !== undefined) out.set(key(m.left.name), cloneValue(v));
        }
      }
    }
  }

  loadFetched(source: string): boolean { return this.load(source, "fetched"); }

  spawn(typeName: string): number | undefined {
    const def = this.objects.get(key(typeName));
    if (!def) { this.emit({ code: "RUN-UNDEFINED-OBJECT", severity: "error", message: `Cannot spawn undefined object type: ${typeName}.` }); return undefined; }
    const limit = this.config.resourceLimits.instances;
    if (limit !== undefined && this.instances.size >= limit) { this.emitLimit("instances"); return undefined; }
    const id = this.nextInstanceId++;
    const values = new Map<string, RuntimeValue>();
    for (const [k, v] of def.initialValues) values.set(k, cloneValue(v));
    this.instances.set(id, { id, type: def, values, alive: true });
    this.trace.push({ tick: this.tickNumber, event: "spawn", instanceId: id, detail: def.name });
    return id;
  }

  remove(instanceId: number): boolean {
    const inst = this.instances.get(instanceId);
    if (!inst || !inst.alive) return false;
    inst.alive = false;
    this.host.onAudioStop?.(instanceId);
    this.host.onProcessStop?.(instanceId);
    this.trace.push({ tick: this.tickNumber, event: "remove", instanceId });
    return true;
  }

  setValue(instanceId: number, name: string, value: RuntimeValue): boolean {
    const i = this.instances.get(instanceId);
    if (!i || !i.alive) return false;
    i.values.set(key(name), cloneValue(value));
    return true;
  }
  getValue(instanceId: number, name: string): RuntimeValue | undefined { return this.instances.get(instanceId)?.values.get(key(name)); }

  startTimer(name: string, durationSeconds: number, repeating = false): boolean {
    const k = key(name);
    const limit = this.config.resourceLimits.timers;
    if (!this.timers.has(k) && limit !== undefined && this.timers.size >= limit) { this.emitLimit("timers"); return false; }
    if (!(durationSeconds >= 0) || !Number.isFinite(durationSeconds)) return false;
    this.timers.set(k, { key: k, name, remaining: durationSeconds, interval: durationSeconds, repeating });
    return true;
  }
  cancelTimer(name: string): void { this.timers.delete(key(name)); }
  random(): number { return this.rng.next(); }
  get canbreak(): boolean { return this.canbreakFlag; }
  clearCanbreak(): void { this.canbreakFlag = false; }

  tick(dtSeconds = 1 / 60): RuntimeStateSnapshot {
    if (!(dtSeconds >= 0) || !Number.isFinite(dtSeconds)) throw new Error("dtSeconds must be a finite non-negative number");
    this.inTick = true; this.instructionCount = 0; this.eventFirings = 0;
    this.tickNumber++; this.timeSeconds += dtSeconds;
    this.updateTimers(dtSeconds);
    const instances = [...this.instances.values()].filter(i => i.alive);
    this.processEvents(instances);
    this.inTick = false;
    return this.snapshot();
  }

  stepFrame(frameDtSeconds: number): RuntimeStateSnapshot {
    if (!(frameDtSeconds >= 0) || !Number.isFinite(frameDtSeconds)) throw new Error("frameDtSeconds must be a finite non-negative number");
    this.accumulator += frameDtSeconds;
    let steps = 0;
    const fixed = 1 / 60;
    while (this.accumulator >= fixed && steps < this.config.maxStepCountPerFrame) {
      this.tick(fixed); this.accumulator -= fixed; steps++;
    }
    if (steps === this.config.maxStepCountPerFrame && this.accumulator >= fixed) {
      this.emit({ code: "RUN-STEP-CAP", severity: "warning", message: "Maximum fixed-timestep step count reached; excess accumulated time remains queued." });
    }
    return this.snapshot();
  }

  snapshot(): RuntimeStateSnapshot {
    const instances = [...this.instances.values()].map(i => ({ id: i.id, type: i.type.name, alive: i.alive, values: Object.fromEntries([...i.values.entries()].map(([k,v]) => [k, cloneValue(v)])) }));
    const timers = [...this.timers.values()].map(t => ({ name: t.name, remaining: t.remaining, interval: t.interval, repeating: t.repeating }));
    return { tick: this.tickNumber, time: this.timeSeconds, instances, timers, canbreak: this.canbreakFlag };
  }

  private updateTimers(dt: number): void {
    for (const t of [...this.timers.values()]) {
      t.remaining -= dt;
      if (t.remaining > 0) continue;
      this.trace.push({ tick: this.tickNumber, event: "timer", detail: t.name });
      if (t.repeating && t.interval > 0) {
        while (t.remaining <= 0) t.remaining += t.interval;
      } else this.timers.delete(t.key);
    }
  }

  private processEvents(instances: RuntimeInstance[]): void {
    for (const ev of this.events) {
      for (const inst of instances) {
        if (!inst.alive || (ev.ownerType && key(ev.ownerType) !== key(inst.type.name))) continue;
        const satisfying = this.conditionTrue(ev.condition, inst);
        const wasActive = ev.active.get(inst.id) ?? false;
        if (satisfying && !wasActive) {
          ev.active.set(inst.id, true);
          if (++this.eventFirings > this.config.maxEventFiringsPerTick) { this.emitLimit("eventFirings"); return; }
          this.trace.push({ tick: this.tickNumber, event: "event", instanceId: inst.id });
          this.executeResponse(ev.response, inst);
        } else if (!satisfying) ev.active.set(inst.id, false);
      }
    }
  }

  private conditionTrue(stmts: A.Statement[], inst: RuntimeInstance): boolean {
    const exprs = stmts.filter(s => s.kind === "ExpressionStatement")
      .map(s => (s as A.ExpressionStatement).expression)
      .filter(e => !(e.kind === "ReferenceExpr" && e.referenceKind === "id"));
    if (!exprs.length) return true;
    return exprs.every(e => boolOf(this.evalExpr(e, inst)));
  }

  private executeStatement(s: A.Statement, inst?: RuntimeInstance): void {
    if (++this.instructionCount > this.config.maxInstructionsPerTick) { this.emitLimit("instructionsPerTick"); return; }
    if (s.kind === "ExpressionStatement") { this.evalExpr(s.expression, inst); return; }
    if (s.kind !== "Command") return;
    switch (s.name) {
      case "set": case "mod": {
        const m = s.args[0]; if (m?.kind === "MutationExpr") this.applyMutation(m, inst); break;
      }
      case "do": {
        const r = s.args.find(x => x.kind === "ReferenceExpr" && x.referenceKind === "id") as A.ReferenceExpr | undefined;
        if (r) this.executeAction(r.value, inst);
        else {
          const br = this.firstId(s.body);
          if (br) this.executeAction(br.value, inst);
        }
        break;
      }
      case "spawn": {
        const r = s.args.find(x => x.kind === "ReferenceExpr" && x.referenceKind === "id") as A.ReferenceExpr | undefined;
        if (r) this.spawn(r.value); break;
      }
      case "remove": if (inst) this.remove(inst.id); break;
      case "canbreak": this.canbreakFlag = true; break;
      case "repeat": {
        const countExpr = s.args[0]; const n = countExpr ? numberOf(this.evalExpr(countExpr, inst)) : 0;
        if (n !== undefined) this.executeRepeated(s.body?.body ?? [], Math.max(0, Math.floor(n)), inst); break;
      }
      case "until": {
        const cond = s.args[0]; const body = s.body?.body ?? [];
        let i = 0; while (i++ < this.config.maxRepeatIterations) {
          if (cond && boolOf(this.evalExpr(cond, inst))) break;
          for (const x of body) this.executeStatement(x, inst);
        }
        if (i >= this.config.maxRepeatIterations) this.emitLimit("repeatIterations");
        break;
      }
      case "timer": {
        const id = s.args.find(x => x.kind === "ReferenceExpr" && x.referenceKind === "id") as A.ReferenceExpr | undefined;
        const d = s.args.find(x => x.kind !== "ReferenceExpr");
        const seconds = d ? numberOf(this.evalExpr(d, inst)) : undefined;
        if (id && seconds !== undefined) this.startTimer(id.value, seconds, false);
        break;
      }
      case "if": {
        const cond = s.args[0]; if (!cond || boolOf(this.evalExpr(cond, inst))) for (const x of s.body?.body ?? []) this.executeStatement(x, inst); break;
      }
      default: for (const x of s.body?.body ?? []) this.executeStatement(x, inst);
    }
  }

  /** Execute previously validated statements for a live instance; host/headless runtime entry point. */
  runStatements(statements: A.Statement[], instanceId: number): boolean {
    const inst = this.instances.get(instanceId);
    if (!inst || !inst.alive) return false;
    this.instructionCount = 0;
    for (const statement of statements) this.executeStatement(statement, inst);
    return true;
  }

  /** Execute a previously validated action immediately; intended for headless host/tests. */
  runAction(name: string, instanceId: number): boolean {
    const inst = this.instances.get(instanceId);
    if (!inst || !inst.alive) return false;
    this.executeAction(name, inst);
    return true;
  }

  private executeResponse(stmts: A.Statement[], inst: RuntimeInstance): void {
    for (let i = 0; i < stmts.length; i++) {
      const s = stmts[i];
      if (s.kind === "Command" && s.name === "do") {
        const arg = s.args.find(x => x.kind === "ReferenceExpr" && x.referenceKind === "id") as A.ReferenceExpr | undefined;
        if (arg) this.executeAction(arg.value, inst);
        else {
          const next = stmts[i + 1];
          if (next?.kind === "ExpressionStatement" && next.expression.kind === "ReferenceExpr" && next.expression.referenceKind === "id") {
            this.executeAction(next.expression.value, inst);
            i++;
          }
        }
      } else this.executeStatement(s, inst);
    }
  }

  private executeRepeated(body: A.Statement[], count: number, inst?: RuntimeInstance): void {
    const n = Math.min(count, this.config.maxRepeatIterations);
    for (let i=0;i<n;i++) { for (const s of body) this.executeStatement(s, inst); if (this.instructionCount > this.config.maxInstructionsPerTick) return; }
    if (count > n) this.emitLimit("repeatIterations");
  }
  private executeAction(name: string, inst?: RuntimeInstance): void {
    const a = this.actions.get(key(name));
    if (!a) { this.emit({ code: "RUN-UNDEFINED-ACTION", severity: "error", message: `Undefined action: ${name}.` }); return; }
    for (const s of a.body) this.executeStatement(s, inst);
  }
  private applyMutation(m: A.MutationExpr, inst?: RuntimeInstance): void {
    if (!inst || m.left.kind !== "ValueRefExpr") return;
    const right = this.evalExpr(m.right, inst);
    const name = key(m.left.name);
    if (m.operator === "=") { inst.values.set(name, cloneValue(right)); return; }
    const left = inst.values.get(name);
    const result = this.binary(m.operator.slice(0,1), left, right);
    if (result !== undefined) inst.values.set(name, result);
  }

  private evalExpr(e: A.Expression, inst?: RuntimeInstance): RuntimeValue {
    switch (e.kind) {
      case "LiteralExpr": return literalValue(e);
      case "ValueRefExpr": return inst?.values.get(key(e.name)) ?? null;
      case "ReferenceExpr": return e.referenceKind === "id" ? ({ kind: "object_ref", instanceId: -1, typeName: e.value } as RuntimeObjectRef) : e.value;
      case "GroupedExpr": return this.evalExpr(e.expression, inst);
      case "UnaryExpr": return !boolOf(this.evalExpr(e.operand, inst));
      case "MutationExpr": return this.evalMutationExpr(e, inst);
      case "BinaryExpr": {
        if (e.operator === "and") { const l=boolOf(this.evalExpr(e.left,inst)); return l && boolOf(this.evalExpr(e.right,inst)); }
        if (e.operator === "nand") { const l=boolOf(this.evalExpr(e.left,inst)); return !(l && boolOf(this.evalExpr(e.right,inst))); }
        if (e.operator === "or") { const l=boolOf(this.evalExpr(e.left,inst)); return l || boolOf(this.evalExpr(e.right,inst)); }
        if (e.operator === "nor") { const l=boolOf(this.evalExpr(e.left,inst)); return !(l || boolOf(this.evalExpr(e.right,inst))); }
        return this.binary(e.operator, this.evalExpr(e.left,inst), this.evalExpr(e.right,inst));
      }
      case "ErrorExpr": return null;
    }
  }
  private evalMutationExpr(e:A.MutationExpr, inst?:RuntimeInstance):RuntimeValue { const l=this.evalExpr(e.left,inst), r=this.evalExpr(e.right,inst); return e.operator === "=" ? r : this.binary(e.operator.slice(0,1),l,r); }
  private binary(op:string,l:RuntimeValue|undefined,r:RuntimeValue|undefined):RuntimeValue {
    if (l === undefined || r === undefined) return null;
    if (["+","-","*","/"].includes(op)) {
      const ln=numberOf(l), rn=numberOf(r); if (ln===undefined||rn===undefined) return null;
      const ld=typeof l === "object" && l !== null && "dimension" in l ? l : undefined;
      const rd=typeof r === "object" && r !== null && "dimension" in r ? r : undefined;
      if (op === "+" || op === "-") {
        if (ld && rd && ld.dimension !== rd.dimension) return null;
        if (ld || rd) return { kind:"dimensioned", dimension:(ld ?? rd)!.dimension, value: op === "+" ? ln+rn : ln-rn, unit:(ld ?? rd)!.unit };
        return op === "+" ? ln+rn : ln-rn;
      }
      if (ld && rd) return null;
      if (ld || rd) { const d=ld ?? rd!; return {kind:"dimensioned",dimension:d.dimension,value:op === "*" ? ln*rn : (rn===0?NaN:ln/rn),unit:d.unit}; }
      return op === "*" ? ln*rn : (rn===0?NaN:ln/rn);
    }
    switch(op){
      case "=": return this.equals(l,r);
      case "not =": return !this.equals(l,r);
      case "<": return this.compare(l,r,(a,b)=>a<b);
      case ">": return this.compare(l,r,(a,b)=>a>b);
      case "<=": return this.compare(l,r,(a,b)=>a<=b);
      case ">=": return this.compare(l,r,(a,b)=>a>=b);
      default: return null;
    }
  }
  private equals(l:RuntimeValue,r:RuntimeValue):boolean { if (typeof l === "object" && l && typeof r === "object" && r && "dimension" in l && "dimension" in r) return l.dimension===r.dimension && l.value===r.value; return l===r; }
  private compare(l:RuntimeValue,r:RuntimeValue,p:(a:number,b:number)=>boolean):boolean { const a=numberOf(l),b=numberOf(r); return a!==undefined&&b!==undefined&&p(a,b); }
  private firstId(block?:A.Block):A.ReferenceExpr|undefined { for(const s of block?.body??[]) { if(s.kind==="ExpressionStatement"&&s.expression.kind==="ReferenceExpr"&&s.expression.referenceKind==="id") return s.expression; } return undefined; }
  private firstIdFromArgs(args:A.Expression[]):A.ReferenceExpr|undefined { return args.find(x=>x.kind==="ReferenceExpr"&&x.referenceKind==="id") as A.ReferenceExpr|undefined; }
  private idsInStatement(s:A.Statement):string[]{ const out:string[]=[]; const walk=(e:A.Expression)=>{if(e.kind==="ReferenceExpr"&&e.referenceKind==="id")out.push(e.value); else if(e.kind==="BinaryExpr"){walk(e.left);walk(e.right)} else if(e.kind==="UnaryExpr"){walk(e.operand)} else if(e.kind==="GroupedExpr"){walk(e.expression)} else if(e.kind==="MutationExpr"){walk(e.left);walk(e.right)}}; if(s.kind==="ExpressionStatement")walk(s.expression); else if(s.kind==="Command")for(const a of s.args)walk(a); return out; }
  private emitLimit(which:string):void { this.emit({code:"RUN-RESOURCE-LIMIT",severity:"warning",message:`Runtime resource limit reached: ${which}.`}); }
  private emit(d:RuntimeDiagnostic):void { this.diagnostics.push(d); this.host.diagnostics?.(d); }
}

export function runHeadless(source:string, options:{host?:RuntimeHost;config?:RuntimeConfig;spawns?:string[];ticks?:number;dtSeconds?:number}={}):{runtime:FroztRuntime;snapshot:RuntimeStateSnapshot;ok:boolean}{
  const runtime=new FroztRuntime(options.host,options.config);
  const ok=runtime.load(source,"main");
  if(ok) for(const name of options.spawns??[]) runtime.spawn(name);
  for(let i=0;i<(options.ticks??0)&&ok;i++) runtime.tick(options.dtSeconds??1/60);
  return {runtime,snapshot:runtime.snapshot(),ok};
}

export { RUNTIME_HOST_POLICY };
