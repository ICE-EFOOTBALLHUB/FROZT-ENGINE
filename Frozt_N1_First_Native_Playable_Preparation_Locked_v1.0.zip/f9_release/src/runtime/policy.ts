export type ModuleExeFailure = "noop-with-diagnostic" | "fatal";

export interface ModulePolicy {
  parseAtFetch: true;
  failedFetchedModuleExe: "noop-with-diagnostic";
  failedMainModule: "fatal";
}

export interface RemovalPolicy {
  stopBoundAudio: true;
  stopBoundProcesses: true;
  cameraRemainsValid: true;
}

export interface RandomnessPolicy {
  hostSuppliedSeed: true;
  deterministicGenerator: true;
  algorithm: "runtime-defined-deterministic-generator";
}

export interface TimestepPolicy {
  accumulator: true;
  maxStepCountPerFrame: "configurable";
}

export interface ResourceLimitPolicy {
  configurable: true;
  diagnosticsOnLimit: true;
}

export interface CanbreakPolicy {
  gameDefinedViaEvents: true;
  engineFlagOnly: true;
}

export interface LanguageVersionPolicy {
  prereleaseMajor: 0;
  onePointZeroAfterF4Conformance: true;
  missingVersionComponentsReadAsZero: true;
}

export interface RuntimeHostPolicy {
  module: ModulePolicy;
  removal: RemovalPolicy;
  randomness: RandomnessPolicy;
  timestep: TimestepPolicy;
  resourceLimits: ResourceLimitPolicy;
  canbreak: CanbreakPolicy;
  languageVersion: LanguageVersionPolicy;
}

export const RUNTIME_HOST_POLICY: RuntimeHostPolicy = {
  module: {
    parseAtFetch: true,
    failedFetchedModuleExe: "noop-with-diagnostic",
    failedMainModule: "fatal"
  },
  removal: {
    stopBoundAudio: true,
    stopBoundProcesses: true,
    cameraRemainsValid: true
  },
  randomness: {
    hostSuppliedSeed: true,
    deterministicGenerator: true,
    algorithm: "runtime-defined-deterministic-generator"
  },
  timestep: {
    accumulator: true,
    maxStepCountPerFrame: "configurable"
  },
  resourceLimits: {
    configurable: true,
    diagnosticsOnLimit: true
  },
  canbreak: {
    gameDefinedViaEvents: true,
    engineFlagOnly: true
  },
  languageVersion: {
    prereleaseMajor: 0,
    onePointZeroAfterF4Conformance: true,
    missingVersionComponentsReadAsZero: true
  }
};

export type ExeDecision = "execute" | "noop-with-diagnostic" | "fatal";
export function decideExe(moduleKind: "main" | "fetched", parseFailed: boolean): ExeDecision {
  if (!parseFailed) return "execute";
  return moduleKind === "main" ? "fatal" : "noop-with-diagnostic";
}
