import { readZip, type DeflateDecoder, type ZipArchive } from './zip';
import { normalizePackagePath } from './path';

export const FROZT_RUNTIME_VERSION = '0.9.0';
export const INVALID_GAME_INFO = 'invalid game info';

export interface GameMetadata {
  game_name: string;
  game_version: string;
  frozt_version: string;
  package_id: string;
}

export interface FztPackage {
  readonly meta: GameMetadata;
  readonly mainSource: Uint8Array;
  readonly archive: ZipArchive;
  read(path: string): Uint8Array | undefined;
  has(path: string): boolean;
}

function semver(v: string): [number, number, number] | undefined {
  const m = /^(\d+)\.(\d+)\.(\d+)$/.exec(v.trim());
  return m ? [Number(m[1]), Number(m[2]), Number(m[3])] : undefined;
}
function atLeast(actual: string, minimum: string): boolean {
  const a = semver(actual), b = semver(minimum); if (!a || !b) return false;
  return a[0] > b[0] || (a[0] === b[0] && (a[1] > b[1] || (a[1] === b[1] && a[2] >= b[2])));
}
function parseMeta(bytes: Uint8Array): GameMetadata {
  const text = new TextDecoder().decode(bytes).replace(/^\uFEFF/, '');
  const fields: Record<string, string> = {};
  for (const line of text.split(/\r?\n/)) {
    if (!line.trim() || line.trim().startsWith('#')) continue;
    const i = line.indexOf('='); if (i <= 0) throw new Error(INVALID_GAME_INFO);
    fields[line.slice(0, i).trim()] = line.slice(i + 1).trim();
  }
  const keys: (keyof GameMetadata)[] = ['game_name','game_version','frozt_version','package_id'];
  if (keys.some(k => !fields[k])) throw new Error(INVALID_GAME_INFO);
  if (!/^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$/.test(fields.package_id)) throw new Error(INVALID_GAME_INFO);
  if (!semver(fields.game_version) || !semver(fields.frozt_version) || !atLeast(FROZT_RUNTIME_VERSION, fields.frozt_version)) throw new Error(INVALID_GAME_INFO);
  return { game_name: fields.game_name, game_version: fields.game_version, frozt_version: fields.frozt_version, package_id: fields.package_id };
}

export function loadFzt(bytes: Uint8Array, decodeDeflate?: DeflateDecoder): FztPackage {
  try {
    const archive = readZip(bytes, decodeDeflate);
    const metaBytes = archive.read('metadata/meta.txt');
    const mainSource = archive.read('main.frozt');
    if (!metaBytes || !mainSource) throw new Error(INVALID_GAME_INFO);
    const meta = parseMeta(metaBytes);
    return { meta, mainSource, archive, read: p => archive.read(normalizePackagePath(p) ?? ''), has: p => archive.entries.has(normalizePackagePath(p) ?? '') };
  } catch (e) {
    if (e instanceof Error && (e.message === INVALID_GAME_INFO || e.message.startsWith('unsupported .fzt compression') || e.message === 'deflate decoder unavailable')) throw e;
    throw new Error(INVALID_GAME_INFO);
  }
}
