import { normalizePackagePath } from './path';

export interface ZipEntry { path: string; method: 0 | 8; compressedSize: number; uncompressedSize: number; localHeaderOffset: number; }
export interface ZipArchive { entries: ReadonlyMap<string, ZipEntry>; read(path: string): Uint8Array | undefined; }
export type DeflateDecoder = (compressed: Uint8Array, expectedSize: number) => Uint8Array;

const U16 = (b: Uint8Array, o: number) => b[o] | (b[o + 1] << 8);
const U32 = (b: Uint8Array, o: number) => (b[o] | (b[o + 1] << 8) | (b[o + 2] << 16) | (b[o + 3] << 24)) >>> 0;

function findEOCD(bytes: Uint8Array): number {
  const min = Math.max(0, bytes.length - 0xffff - 22);
  for (let i = bytes.length - 22; i >= min; i--) if (U32(bytes, i) === 0x06054b50) return i;
  return -1;
}

/** In-memory ZIP reader. Store entries are always supported; deflate is injected by the host/runtime. */
export function readZip(bytes: Uint8Array, decodeDeflate?: DeflateDecoder): ZipArchive {
  const eocd = findEOCD(bytes);
  if (eocd < 0) throw new Error('invalid .fzt container');
  const count = U16(bytes, eocd + 10), cdSize = U32(bytes, eocd + 12), cdOffset = U32(bytes, eocd + 16);
  if (cdOffset + cdSize > bytes.length) throw new Error('invalid .fzt container');
  const entries = new Map<string, ZipEntry>();
  let p = cdOffset;
  for (let i = 0; i < count; i++) {
    if (U32(bytes, p) !== 0x02014b50) throw new Error('invalid .fzt container');
    const method = U16(bytes, p + 10);
    const compressedSize = U32(bytes, p + 20), uncompressedSize = U32(bytes, p + 24);
    const nameLen = U16(bytes, p + 28), extraLen = U16(bytes, p + 30), commentLen = U16(bytes, p + 32);
    const nameBytes = bytes.subarray(p + 46, p + 46 + nameLen);
    const path = new TextDecoder().decode(nameBytes);
    if (path.endsWith('/')) { p += 46 + nameLen + extraLen + commentLen; continue; }
    const safe = normalizePackagePath(path);
    if (!safe || safe !== path || entries.has(safe)) throw new Error('invalid .fzt path: ' + JSON.stringify(path));
    if (method !== 0 && method !== 8) throw new Error(`unsupported .fzt compression: ${method}`);
    entries.set(safe, { path: safe, method: method as 0 | 8, compressedSize, uncompressedSize, localHeaderOffset: U32(bytes, p + 42) });
    p += 46 + nameLen + extraLen + commentLen;
  }
  return {
    entries,
    read(path: string) {
      const safe = normalizePackagePath(path); if (!safe || safe !== path) return undefined;
      const e = entries.get(safe); if (!e) return undefined;
      const o = e.localHeaderOffset;
      if (U32(bytes, o) !== 0x04034b50) throw new Error('invalid .fzt local header');
      const nameLen = U16(bytes, o + 26), extraLen = U16(bytes, o + 28);
      const start = o + 30 + nameLen + extraLen, end = start + e.compressedSize;
      if (end > bytes.length) throw new Error('invalid .fzt entry');
      const compressed = bytes.subarray(start, end);
      if (e.method === 0) return new Uint8Array(compressed);
      if (!decodeDeflate) throw new Error('deflate decoder unavailable');
      const out = decodeDeflate(compressed, e.uncompressedSize);
      if (out.byteLength !== e.uncompressedSize) throw new Error('invalid .fzt decompression');
      return new Uint8Array(out);
    }
  };
}
