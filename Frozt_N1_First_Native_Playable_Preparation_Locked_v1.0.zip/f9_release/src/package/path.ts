/** Package-relative paths are normalized and cannot escape the .fzt container. */
export function normalizePackagePath(path: string): string | undefined {
  if (!path || path.includes('\\') || path.startsWith('/') || /^[A-Za-z]:[\\/]/.test(path)) return undefined;
  const parts = path.split('/');
  const out: string[] = [];
  for (const part of parts) {
    if (!part || part === '.') continue;
    if (part === '..') return undefined;
    out.push(part);
  }
  return out.length ? out.join('/') : undefined;
}

export function isSafePackagePath(path: string): boolean {
  return normalizePackagePath(path) === path;
}
