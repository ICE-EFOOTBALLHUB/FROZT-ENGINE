import type { SaveValue } from '../host/api';

export interface SaveEnvelope { schema: 1; packageId: string; gameVersion: string; values: Record<string, SaveValue>; }

export class GameSaveStore {
  private values = new Map<string, SaveValue>();
  private dirty = false;
  constructor(readonly packageId: string, readonly gameVersion: string) {}
  get(key: string): SaveValue | undefined { return this.values.get(key); }
  put(key: string, value: SaveValue): void { if (!key || key.includes('/') || key.includes('\\')) throw new Error('invalid save key'); JSON.stringify(value); this.values.set(key, value); this.dirty = true; }
  delete(key: string): void { if (this.values.delete(key)) this.dirty = true; }
  isDirty(): boolean { return this.dirty; }
  clearDirty(): void { this.dirty = false; }
  exportEnvelope(): SaveEnvelope { return { schema: 1, packageId: this.packageId, gameVersion: this.gameVersion, values: Object.fromEntries([...this.values].sort(([a],[b]) => a.localeCompare(b))) }; }
  importEnvelope(envelope: unknown): boolean {
    if (!envelope || typeof envelope !== 'object') return false;
    const e = envelope as Partial<SaveEnvelope>;
    if (e.schema !== 1 || e.packageId !== this.packageId || e.gameVersion !== this.gameVersion || !e.values || typeof e.values !== 'object' || Array.isArray(e.values)) return false;
    const next = new Map<string, SaveValue>();
    for (const [k,v] of Object.entries(e.values)) { if (!k || k.includes('/') || k.includes('\\')) return false; JSON.stringify(v); next.set(k, v); }
    this.values = next; this.dirty = false; return true;
  }
}
