# F4 Reference Runtime Fixture

A minimal headless runtime reference game using only constructs already representable by the frozen F1/F2 surface.

Expected after spawning `counter` and running one tick:

- one live `counter` instance
- `value = 2`
- one event trace entry
- no runtime diagnostics

The fixture intentionally does not introduce new parser syntax for `repeat`, `until`, or command arguments. Those runtime constructs are implemented at the runtime/AST level and remain outside the frozen F2 grammar until a separately tested grammar decision is made.
