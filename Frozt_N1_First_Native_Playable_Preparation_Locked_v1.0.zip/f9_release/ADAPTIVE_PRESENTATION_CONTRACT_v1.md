# FROZT Adaptive Presentation Contract v1 — LOCKED

## Separation rules

1. Simulation/game state is independent of presentation state.
2. World rendering and screen-space UI are separate domains.
3. Platform identity is not a layout rule.
4. Orientation, aspect ratio, available logical space, DPI, safe area, and input capabilities are environment facts.
5. A presentation may change structure, visibility, sizing, arrangement, and interaction model without changing game state.
6. Input actions remain platform-independent; controls map into those actions.
7. Presentation changes preserve simulation state.

## Environment

The engine may receive:

- logical width/height
- DPI
- safe-area insets
- derived orientation (`portrait`, `landscape`, `square`)
- pointer availability
- input capabilities (`touch`, `mouse`, `keyboard`, `gamepad`, `pointer`)

Physical pixels are not the layout contract.

## Layout model

The foundation is:

`environment -> constraints -> layout containers -> variants -> interaction`

Constraints support min/max sizes and margins/padding. Variants are named by presentation characteristics such as `compact` or `expanded`; those names are not synonyms for Android/desktop.

A single logical UI can therefore have, for example:

- compact: inventory behind a button
- expanded: inventory panel continuously visible

Both presentations bind to the same inventory state.

## Variant selection

Variants have explicit predicates and deterministic priority. If no predicate matches, the `default` presentation is used.

The contract intentionally does not require a variant for every device. A small set of characteristic variants plus a fallback is preferred.

## Deferred expansion

Rich widgets, text measurement, localization, accessibility-specific layout, advanced responsive containers, preview tooling, and transition choreography remain future presentation-system work. The locked contract is the boundary they must obey.
