Machine-readable fixtures for F1.3 will be expanded from these F1.2 smoke cases.
Each fixture will contain source, expected tokens, expected trivia, and expected diagnostics.
