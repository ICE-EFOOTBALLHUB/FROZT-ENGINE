# FROZT F8 — Expanded Game Systems + Adaptive Presentation

Status: LOCKED v1.0

## Locked decisions
- Game state is independent of presentation state.
- Platform identity is not a layout rule; environment capabilities and available space drive presentation.
- Layout uses safe-area-aware logical coordinates and deterministic constraints.
- Presentation may change structure, visibility and interaction model without mutating simulation state.
- Interaction is resolved by enabled hit regions and deterministic z-order.
- World interaction adds triggers and collision pairs while retaining F5 spatial ownership.
- Animation, camera follow and scene transitions are deterministic host-independent systems.
- Audio remains behind Host API; F8 adds an engine-level lifecycle wrapper only.
- Saves support explicit schema migration; incompatible future schemas are rejected.
- The sample game is the acceptance pattern: compact portrait inventory access and expanded desktop inventory presentation share one game state.

## F8 exit gate
- TypeScript build passes.
- F0-F7 regression passes.
- F8 systems pass focused tests.
- Sample-game adaptive composition test passes.
- Native F7 package/save contract remains unchanged.
