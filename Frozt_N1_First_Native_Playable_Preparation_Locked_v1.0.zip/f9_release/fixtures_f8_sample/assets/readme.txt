F8 sample asset placeholder.
